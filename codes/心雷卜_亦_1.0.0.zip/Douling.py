from src.char.BaseChar import SwitchPriority
from src.char.Douling import Douling as NativeDouling


class Douling(NativeDouling):
    """心雷卜(心/雷主·导电/卜灵)里的卜灵。非本队时整套走原版。

    【她不驱动任何一段轴】: 宏体在同目录的 Hsin.py, 她全程由宏按数字键切进切出(一圈上场两次)。
    走到 do_perform 说明宏散了(切人失败/脱战重进), 转给心的 drive()。
    自定义角色文件互相 import 不到, 用 task.chars 里的实例按能力找。

    ================= 卜灵怎么打(用户文字轴 + 技能文本) =================
    第一格 a1 a2 e a跳a: a2 给「艮」(黄), e(遁影牵雷)给「震」(蓝),
                        【e 秒接的那个 a 就是 a4】也给「震」, 跳a(空中攻击)再给「震」
                        -> 艮1 + 震3 = 4 枚卦象。【跳a 结束时人在空中, 雷主就从空中切进来】。
    第二格 zz: 第一次重击 艮+震 -> 少阳(黄), 第二次 震+震 -> 少阴(蓝)。
               4 枚正好够两次。【卦象不足 2 枚硬按重击会卜卦失败, 扣 20% 当前生命值】。
    然后 q(声骸) -> r(大招): 阴阳齐 -> 强化大招 -> 五雷阵立即铺开 24s, 每2s叠电磁效应。
    延奏「役将驱邪」: 下一位每秒回 18% 攻击力生命 16s + 全队 15% 全伤害加深 30s。立即生效, 无延迟。

    ================= 卦象读数(2026-10-08 截图逐像素采样) =================
    - 卦象 = 回路条【上方】那一排发光团: 【黄 = 艮, 蓝 = 震】。
    - 重击转化后在【下方回路条】里分成左右两半: 【黄 = 少阳】, 【蓝 = 少阴】(用户确认)。
    - 【卦象居中排列】: 只有一个时在正中间, 数量变化时位置会动 —— 所以扫一整条带、按列分段数图标,
      不写死单个图标坐标。
    - 【上下两种黄不是一个色】: 卦象的黄 H≈17(偏橙), 少阳的黄 H≈23(偏金)。分开写范围。
    """

    @property
    def is_healer(self):
        """【本队里不把卜灵算作奶妈】: 框架开战前的 switch_healer() 会先切给奶妈, 白切一次人。"""
        try:
            if self.is_in_xlb:
                return False
        except Exception:
            pass  # __init__ 里会先读一次, 那时队伍还没加载
        return super().is_healer

    @property
    def is_in_xlb(self) -> bool:
        """本队 = 心 + 雷主(Rover) + 卜灵。

        【名字带后缀】(2026-10-08 日志): 雷主的 name 是 "Rover: Spectro", 不是裸的 "Rover"。
        所以用前缀匹配, 否则这里数不到雷主、members 永远只有 1、判定恒为 False。
        """
        members = 0
        for char in self.task.chars:
            if char is None:
                continue
            name = char.name or ''
            if name == 'Hsin' or name.startswith('Hsin:'):
                members += 1
            elif name == 'Rover' or name.startswith('Rover:'):
                members += 1
        return members == 2

    def macro(self):
        """持宏的心。心那份自定义没启用时返回 None, 走原版。"""
        for char in self.task.chars:
            if char is None or char is self:
                continue
            if hasattr(char, 'drive') and hasattr(char, 'quick_switch'):
                return char
        return None

    def reset_state(self):
        super().reset_state()
        # 【必须写在 reset_state 里】: 换类时内置实例的字段会整体拷过来, 改过的值被打回内置值。
        # _segment 是内置卜灵"分两次上场"的状态机, 本队由宏驱动, 留着只会在退回内置逻辑时切一半
        self._segment = 1
        self.check_f_on_switch = False

    def do_perform(self):
        if not self.is_in_xlb:
            return super().do_perform()
        self.check_f_on_switch = False
        macro = self.macro()
        if macro is None:
            self.logger.warning('xlb: Hsin custom code is off, falling back to the native rotation')
            return super().do_perform()
        macro.drive(self)

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """启动轴待跑时返回 NO(宏自己切人)。"""
        if self.is_in_xlb:
            macro = self.macro()
            if macro is not None and macro.opener_pending():
                return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)
