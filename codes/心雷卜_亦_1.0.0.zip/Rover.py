from src.char.BaseChar import SwitchPriority
from src.char.Rover import Rover as NativeRover


class Rover(NativeRover):
    """心雷卜(心/雷主·导电/卜灵)里的雷主(漂泊者·导电)。非本队时整套走原版。

    【他不驱动任何一段轴】: 宏体在同目录的 Hsin.py, 他全程由宏按数字键切进切出。
    走到 do_perform 说明宏散了(切人失败/脱战重进), 转给心的 drive()。

    ================= 雷主在这条轴里的三格 =================
    1. 起手 a1 —— 只打一下平a, 【不按 E】(仅启动轴有这一格)
    2. 空中切进来 -> 落地 aa —— 卜灵跳a 时切人, 雷主空中登场, 落地打平a, 【不按 E】
    3. 变奏进来 q r e 下落a 强e —— Q(声骸) -> R(大招) -> E(雷引, 把人拉上去)
       -> 空中 A(下落) -> 强E(超负荷)。循环轴没有第 1 格, 其余相同。

    ================= 为什么这么打(技能文本) =================
    - 电涌(上限 120)由变奏/普攻/雷引/克敌攒, 满了 E 换成超负荷。
      短按 = 队伍攻击 +10% + 怪 10 层电磁效应; 长按 = 扣 60 协奏进临界共鸣(心就吃不到变奏了)。
      延奏给下一个登场的(心)电髓: 挂上异常后全伤害加深 25%。
    - 心固有: 雷主放【变奏技能】时心和雷主导电伤害 +20%, 所以雷主第三格一定要变奏进来。
    - 【能量提前满了就放强化E, 没关系】: 用户 2026-10-08 —— 提前放就放了, 但宏不能因此卡住。

    ================= 这一队跟心雷穗的差别 =================
    - 【删掉了 LEI2_LEAVE_MIN(卡 6.3s 等翾舞)】: 那是穗穗独有的。卜灵延奏立即生效 30s。
    - 【雷主第二格不再放 E】: 穗穗那版是雷主自己按 E(雷引)把人拉上去打下落;
      这队是卜灵跳a 时【空中切人】, 雷主落地就是下落 —— 不需要雷引。
    - 【落地判据改成读 E 图标】(用户 2026-10-08 确认): 人在空中时 E 图标整个变灰, 落地恢复。
    """

    @property
    def is_in_xlb(self) -> bool:
        """本队 = 心 + 雷主(Rover) + 卜灵。

        【名字带后缀】(2026-10-08 日志): 雷主自己的 name 是 "Rover: Spectro", 不是裸的 "Rover"。
        这里数的是【另外两个】(心 + 卜灵), 两个都能前缀匹配上才算本队。
        """
        members = 0
        for char in self.task.chars:
            if char is None:
                continue
            name = char.name or ''
            if name == 'Hsin' or name.startswith('Hsin:'):
                members += 1
            elif name == 'Douling' or name.startswith('Douling:'):
                members += 1
        return members == 2

    def macro(self):
        """持宏的心。心那份自定义没启用时返回 None, 走原版。"""
        for char in self.task.chars:
            if char is None or char is self:
                continue
            if hasattr(char, 'drive') and hasattr(char, 'quick_switch'):
                return char
        return None

    def reset_state(self):
        super().reset_state()
        # 【必须写在 reset_state 里】: 换类时内置实例的字段会整体拷过来, 改过的值被打回内置值
        self.check_f_on_switch = False

    def do_perform(self):
        if not self.is_in_xlb:
            return super().do_perform()
        self.check_f_on_switch = False
        macro = self.macro()
        if macro is None:
            self.logger.warning('xlb: Hsin custom code is off, falling back to the native rotation')
            return super().do_perform()
        macro.drive(self)

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """启动轴待跑时返回 NO(宏自己切人)。"""
        if self.is_in_xlb:
            macro = self.macro()
            if macro is not None and macro.opener_pending():
                return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)
