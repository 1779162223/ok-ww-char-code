import time
from src.char.BaseChar import BaseChar, SwitchPriority


class Phrolova(BaseChar):
    # 在場上限（秒），從進場起算；BOSS 沒死時滿了就切維里奈回血
    STAY_LIMIT: float = 6.0
    # 指定切人時的輪詢上限（秒），超過就交給框架預設選人
    SWITCH_TIMEOUT: float = 6.0

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_liberation = -1
        self.sp = False

    def skip_combat_check(self):
        return self.time_elapsed_accounting_for_freeze(self.last_liberation) < 2

    def do_perform(self):
        self.last_liberation = -1
        self.sp = False
        self.has_intro = False          # 不使用變奏分支，順便清掉殘留值
        enter_time = time.time()
        timed_out = False
        heavy_done = False
        heavy_retried = False

        forte_full = self.is_mouse_forte_full()
        self.logger.info(f'Phrolova enter flying={self.flying()} forte_full={forte_full}')
        try:
            # 1. 能量滿 → 落地後重擊（之後最多等 3 秒大招，由外部開關決定）
            if forte_full:
                heavy_done = self.heavy_on_ground()

            # 2. 檢查戰鬥：BOSS 死了會在這裡（或之後任何 sleep）拋例外 → finally 切白芷
            self.check_combat()

            # 3. BOSS 沒死：E → 聲骸
            self.click_resonance(time_out=0)
            self.sleep(0.5)
            self.click_echo()
            self.sleep(0.5)

            # 4. 連點普攻 0.5 秒 → 閃避，重複到在場滿 STAY_LIMIT
            while True:
                if self.time_elapsed_accounting_for_freeze(enter_time) >= self.STAY_LIMIT:
                    timed_out = True
                    break
                # 進場時能量沒滿、或重擊被吃掉：能量滿了就補一次重擊（只補一次）
                if not heavy_done and not heavy_retried and self.is_mouse_forte_full():
                    heavy_retried = True
                    heavy_done = self.heavy_on_ground()
                    continue
                start = time.time()
                while time.time() - start < 0.5:
                    self.task.click()
                    self.sleep(0.1)
                self.continues_right_click(0.1)
        finally:
            self.logger.info(
                f'Phrolova stay {time.time() - enter_time:.1f}s '
                f'heavy={heavy_done} timed_out={timed_out}')
            from src.char.Baizhi import Baizhi
            from src.char.Verina import Verina
            # 超時（BOSS 沒死）→ 維里奈回血；戰鬥結束 → 白芷準備下一回合
            target_cls = Verina if timed_out else Baizhi
            if not self._switch_to(target_cls):
                # 目標不在隊伍 / 陣亡 / 切換失敗 → 框架預設選人
                self.switch_next_char()

    def _switch_to(self, char_cls):
        """按數字鍵切到指定角色，成功回傳 True，失敗回傳 False。"""
        target_index = None
        for char in self.task.chars:
            if isinstance(char, char_cls):
                target_index = char.index
                break

        if target_index is None or target_index == self.index:
            return False

        switch_key = str(target_index + 1)
        start = time.time()
        while time.time() - start < self.SWITCH_TIMEOUT:
            in_team, current_index, _ = self.task.in_team()
            if in_team and current_index == target_index:
                for char in self.task.chars:
                    if char:
                        char.is_current_char = (char.index == current_index)
                return True
            self.task.send_key(switch_key)
            self.sleep(0.2, False)

        self.logger.info(f'Phrolova switch to {char_cls.__name__} failed')
        return False

    def heavy_on_ground(self):
        """在空中就先等落地，再重擊。"""
        if self.flying():
            self.wait_down()
        return bool(self.heavy_and_liber())

    def heavy_and_liber(self):
        if self.heavy_click_forte(check_fun=self.is_mouse_forte_full):
            self.logger.debug('Phrolova heavy_click_forte')
            self.task.wait_until(lambda: self.click_liberation(wait_if_cd_ready=0), time_out=3)
            return True

    def _cantarella_outro_ready(self, current_char, has_intro):
        return self.time_elapsed_accounting_for_freeze(
            self.last_liberation) > 14 and has_intro and current_char and current_char.char_name in {'char_cantarella'}

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        self.logger.debug(f'Phrolova last_liberation {self.time_elapsed_accounting_for_freeze(self.last_liberation)}')
        if self._cantarella_outro_ready(current_char, has_intro):
            return SwitchPriority.MUST
        if self.time_elapsed_accounting_for_freeze(self.last_liberation) < 24:
            return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def resonance_available(self):
        if self.sp:
            return not (self.flying() or self.has_cd('resonance'))
        return super().resonance_available()