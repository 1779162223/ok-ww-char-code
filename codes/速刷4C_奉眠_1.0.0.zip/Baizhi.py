from src.char.BaseChar import BaseChar


class Baizhi(BaseChar):
    INTRO_ATTACK_SEC = 1.2  # 入場後普攻秒數

    def do_perform(self):
        self._intro_attack()
        self.click_echo()
        self.switch_next_char()

    def _intro_attack(self):
        if not self.has_intro:
            return
        self.logger.debug(f'Baizhi intro: normal attack {self.INTRO_ATTACK_SEC}s')  # 白芷入場：普攻指定秒數
        self.continues_normal_attack(self.INTRO_ATTACK_SEC)