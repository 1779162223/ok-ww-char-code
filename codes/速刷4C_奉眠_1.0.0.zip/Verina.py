import time
from src.char.BaseChar import BaseChar, SwitchPriority

class Verina(BaseChar):
    """維里奈自動戰鬥(輔助/治療)：E→Q→重擊→(E補協奏/跳躍空中普攻)；前2階段強制走完，3階段先檢測滿協奏直接切，4階段打滿協奏再切。"""
    HEAVY_ATTACK_DURATION: float = 2
    HEAVY_ATTACK_INTERVAL: float = 8.0
    # ========== 可直接修改參數 ==========
    # 階段4最少持續時間（秒）
    NORMAL_ATTACK_MIN_TIME: float = 0.1
    # 滿協奏後穩定延遲（秒），兼顧觸發成功率與切人速度
    CON_FULL_STABLE_DELAY: float = 0.15
    # 跳躍鍵
    JUMP_KEY: str = 'space'
    # 起跳後等待多久再出手（確保判定為空中攻擊）
    JUMP_RISE_DELAY: float = 0.15
    # 空中普攻段數（遊戲上限3下，設超過3也只打3下）
    AIR_ATTACK_COUNT: int = 3
    # 空中普攻間隔（秒）
    AIR_ATTACK_GAP: float = 0.2
    # 空中3下打完後等待落地的時間（秒），落地後才能重新起跳
    LAND_DELAY: float = 0.3
    # ==================================

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_heavy = -1

    def do_perform(self):
        self.perform_combat()
        self.switch_next_char()

    def perform_combat(self):
        """單輪連招：前2階段強制走完，3階段入口先檢測滿協奏直接切，不滿才打重擊；4階段E補協奏/跳躍空中普攻直到協奏滿"""
        # 階段1：普攻2下 + 共鳴(E) - 強制執行
        self.normal_attack()
        self.sleep(0.23)
        self.normal_attack()
        self.sleep(0.23)
        self.cast_resonance()

        # 階段2：聲骸(Q) - 強制執行
        self.cast_echo()

        # 階段3：入口先檢測協奏，滿了直接切人
        if self.is_con_full():
            self.sleep(self.CON_FULL_STABLE_DELAY)
            return
        # 協奏未滿才打重擊
        if self.can_heavy_attack():
            self.heavy_attack(self.HEAVY_ATTACK_DURATION)
            self.last_heavy = time.time()
            # 重擊後再檢查一次，滿了不用進階段4
            if self.is_con_full():
                self.sleep(self.CON_FULL_STABLE_DELAY)
                return

        # 階段4：E可用先放E補協奏 → 不可用或放完仍未滿 → 跳躍+空中普攻3下 → 落地 → 循環
        start_attack = time.time()
        while True:
            if self.resonance_available():
                self.click_resonance(send_click=True, time_out=0)

            if not self.is_con_full():
                self.jump_attack()

            elapsed = self.time_elapsed_accounting_for_freeze(start_attack)
            if elapsed >= self.NORMAL_ATTACK_MIN_TIME and self.is_con_full():
                self.sleep(self.CON_FULL_STABLE_DELAY)
                break

    def jump_attack(self):
        """起跳一次 + 空中普攻最多3下（遊戲上限），打完等落地；中途協奏滿立即停止。下一次需重新起跳。"""
        self.task.send_key(self.JUMP_KEY)
        self.sleep(self.JUMP_RISE_DELAY)
        for _ in range(min(self.AIR_ATTACK_COUNT, 3)):
            self.normal_attack()
            self.sleep(self.AIR_ATTACK_GAP)
            if self.is_con_full():
                return
        # 3下打完會掉落，等落地後才能重新起跳
        self.sleep(self.LAND_DELAY)

    def cast_resonance(self):
        """共鳴(E)可用則放。"""
        if self.resonance_available():
            self.click_resonance(send_click=True, time_out=0)

    def cast_echo(self):
        """聲骸(Q)可用則放。"""
        if self.echo_available():
            self.click_echo(time_out=0)

    def can_heavy_attack(self):
        """距上次重擊是否已超過最小間隔(扣除凍結時間)。"""
        return self.time_elapsed_accounting_for_freeze(self.last_heavy) >= self.HEAVY_ATTACK_INTERVAL

    def switch_next_char(self, post_action=None, free_intro=False, target_low_con=False):
        """滿協奏時優先切換到弗洛洛(char_phrolova)，切換失敗則回退預設邏輯。"""
        # 切換前通用狀態預處理
        self.is_forte_full()
        self.has_intro = False
        self.has_sub_dps_intro = False
        self._liberation_available = self.liberation_available()
        self.use_tool_box()

        # 尋找隊伍中的弗洛洛
        target_char = None
        for char in self.task.chars:
            if char is not None and char.char_name == "char_phrolova":
                target_char = char
                break

        if target_char is not None:
            switch_key = str(target_char.index + 1)
            start = time.time()
            first_send = True
            switched = False
            while time.time() - start < 6:
                in_team, current_index, count = self.task.in_team()
                if in_team and current_index != self.index:
                    for char in self.task.chars:
                        if char:
                            char.is_current_char = (char.index == current_index)
                    switched = True
                    break
                down_time = 0.05 if first_send else 0.02
                self.task.send_key(switch_key, down_time=down_time)
                sleep_time = 0.2 if first_send else 0.12
                self.sleep(sleep_time, False)
                first_send = False

            if switched:
                # 標記滿協奏下場並更新buff時間
                self.switch_out(con_full=True)
                if post_action is not None:
                    post_action()
                return
            # 切弗洛洛失敗（陣亡/按鍵無效）→ 回退預設切換

        # 未找到目標角色或切換失敗時回退到預設切換邏輯
        super().switch_next_char(
            post_action=post_action,
            free_intro=free_intro,
            target_low_con=target_low_con
        )

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if has_intro and current_char and current_char.char_name in {'char_hiyuki'}:
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)