import time
from src.char.BaseChar import BaseChar, SwitchPriority


class Phrolova(BaseChar):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_liberation = -1
        self.sp = False
        self.res_ready = False

    def skip_combat_check(self):
        return self.time_elapsed_accounting_for_freeze(self.last_liberation) < 2

    def do_perform(self):
        self.last_liberation = -1
        self.sp = False
        self.res_ready = False
        if self.has_intro:
            self.res_ready = False
            if self.check_outro() in {'char_cantarella'}:
                self.sp = True
            self.continues_normal_attack(1.7)
            self.continues_right_click(0.1)
        if self.flying():
            self.wait_down()
        try:
            start = time.time()
            # 总时长控制：1.6秒
            while time.time() - start < 1.21:
                self.task.click()
                self.sleep(0.10) # 每次点击间隔，越小点得越快
            self.continues_right_click(0.1)
            # 普攻A
            start = time.time()
            # 总时长控制：1.6秒
            while time.time() - start < 0.5:
                self.task.click()
                self.sleep(0.1) # 每次点击间隔，越小点得越快

            # 放Q
            self.click_echo()
            self.sleep(0.1)
            
            # 固定起手连招：重击
            self.heavy_and_liber()
            # 放E
            self.sleep(0.1)
            self.click_resonance(time_out=0)
            self.sleep(0.5)
            self.normal_attack()
            # 闪避
            self.continues_right_click(0.1)
            # 循环输出
            while True:
                self.check_combat()
                if self.flying():
                    self.shorekeeper_auto_dodge()
                    self.task.next_frame()
                    continue
                # 持续1.8秒普攻
                self.continues_normal_attack(1.8)
                # 闪避
                self.continues_right_click(0.1)
                self.sleep(0.1)
                # 一次普攻
                self.normal_attack()
                self.sleep(0.23)
                # 闪避
                self.continues_right_click(0.1)
                self.task.next_frame()
        finally:
            from src.char.Baizhi import Baizhi
            target_index = None
            for char in self.task.chars:
                if isinstance(char, Baizhi):
                    target_index = char.index
                    break

            if target_index is not None and target_index != self.index:
                switch_key = str(target_index + 1)
                start = time.time()
                while time.time() - start < 6:
                    in_team, current_index, _ = self.task.in_team()
                    if in_team and current_index == target_index:
                        for char in self.task.chars:
                            if char:
                                char.is_current_char = (char.index == current_index)
                        break
                    self.task.send_key(switch_key)
                    self.sleep(0.2, False)
            else:
                self.switch_next_char()

    def _cantarella_outro_ready(self, current_char, has_intro):
        return self.time_elapsed_accounting_for_freeze(
            self.last_liberation) > 14 and has_intro and current_char and current_char.char_name in {'char_cantarella'}

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        self.logger.debug(f'Phrolova last_liberation {self.time_elapsed_accounting_for_freeze(self.last_liberation)}')
        if self._cantarella_outro_ready(current_char, has_intro):
            return SwitchPriority.MUST
        if self.time_elapsed_accounting_for_freeze(self.last_liberation) < 24:
            return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def resonance_available(self):
        if self.sp:
            return not (self.flying() or self.has_cd('resonance'))
        return super().resonance_available()

    def heavy_and_liber(self):
        if self.heavy_click_forte(check_fun=self.is_mouse_forte_full):
            self.logger.debug('Phrolova heavy_click_forte')
            self.task.wait_until(lambda: self.click_liberation(wait_if_cd_ready=0), time_out=3)
            return True

    def shorekeeper_auto_dodge(self):
        from src.char.ShoreKeeper import ShoreKeeper
        for i, char in enumerate(self.task.chars):
            if isinstance(char, ShoreKeeper):
                return char.auto_dodge(condition=self.flying)
