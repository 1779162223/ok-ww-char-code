from src.char.BaseChar import BaseChar


class Baizhi(BaseChar):
    def do_perform(self):
        if self.has_intro:
            self.logger.debug('has_intro wait click 1.2 sec')
            self.continues_normal_attack(1.2)
        self.click_echo()
        self.switch_next_char()
