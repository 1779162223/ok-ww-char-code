import time
from src.char.BaseChar import BaseChar, SwitchPriority

class Verina(BaseChar):
    """Verina 自动战斗(辅助/治疗): E→Q→重击→普攻；前2阶段强制走完，3阶段先检测满协奏直接切，4阶段必须打满条件再切。"""
    HEAVY_ATTACK_DURATION: float = 2
    HEAVY_ATTACK_INTERVAL: float = 8.0
    # ========== 可直接修改参数 ==========
    # 普攻阶段最少持续时间（秒），改这里就能调整阶段4普攻时长
    NORMAL_ATTACK_MIN_TIME: float = 0.1
    # 满协奏后稳定延迟（秒），兼顾触发成功率与切人速度
    CON_FULL_STABLE_DELAY: float = 0.15
    # ==================================

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_heavy = -1

    def do_perform(self):
        self.perform_combat()
        self.switch_next_char()
        
    def perform_combat(self):
        """单轮连招：前2阶段强制走完，3阶段入口先检测满协奏直接切，不满才打重击；4阶段必须打满条件再结束"""
        # 阶段1：释放共鸣(E) - 强制执行，不提前切人
        self.normal_attack()
        self.sleep(0.23)
        self.normal_attack()
        self.sleep(0.23)
        self.cast_resonance()
        
        # 阶段2：释放声骸(Q) - 强制执行，不提前切人
        self.cast_echo()
        
        # 阶段3：入口先检测协奏，满了直接切人，不打重击
        if self.is_con_full():
            self.sleep(self.CON_FULL_STABLE_DELAY)
            return
        # 协奏未打满，才释放重击
        if self.can_heavy_attack():
            self.heavy_attack(self.HEAVY_ATTACK_DURATION)
            self.last_heavy = time.time()
        
        # 阶段4：普攻阶段 - 必须打满最小时间且协奏满后才结束
        start_attack = time.time()
        while True:
            self.normal_attack()
            self.sleep(0.1)
            elapsed = time.time() - start_attack
            if elapsed >= self.NORMAL_ATTACK_MIN_TIME and self.is_con_full():
                self.sleep(self.CON_FULL_STABLE_DELAY)
                break

    def cast_resonance(self):
        """共鸣(E)可用则放。"""
        if self.resonance_available():
            self.click_resonance(send_click=True, time_out=0)

    def cast_echo(self):
        """声骸(Q)可用则放。"""
        if self.echo_available():
            self.click_echo(time_out=0)

    def can_heavy_attack(self):
        """距上次重击是否已超过最小间隔(扣除冻结时间)。"""
        return self.time_elapsed_accounting_for_freeze(self.last_heavy) >= self.HEAVY_ATTACK_INTERVAL

    def switch_next_char(self, post_action=None, free_intro=False, target_low_con=False):
        """满协奏时优先切换到弗洛洛(char_phrolova)，加快切人响应速度。"""
        # 切换前通用状态预处理
        self.is_forte_full()
        self.has_intro = False
        self.has_sub_dps_intro = False
        self._liberation_available = self.liberation_available()
        self.use_tool_box()

        # 查找队伍中的弗洛洛
        target_char = None
        for char in self.task.chars:
            if char is not None and char.char_name == "char_phrolova":
                target_char = char
                break

        if target_char is not None:
            switch_key = str(target_char.index + 1)
            # 加快轮询频率，缩短切人耗时
            start = time.time()
            first_send = True
            while time.time() - start < 6:
                in_team, current_index, count = self.task.in_team()
                if in_team and current_index != self.index:
                    for char in self.task.chars:
                        if char:
                            char.is_current_char = (char.index == current_index)
                    break
                # 保持按键按下时长确保触发，缩短轮询间隔
                down_time = 0.05 if first_send else 0.02
                self.task.send_key(switch_key, down_time=down_time)
                sleep_time = 0.2 if first_send else 0.12
                self.sleep(sleep_time, False)
                first_send = False
            # 标记满协奏下场并更新buff时间
            self.switch_out(con_full=True)
            if post_action is not None:
                post_action()
            return

        # 未找到目标角色时回退到默认切换逻辑
        super().switch_next_char(
            post_action=post_action,
            free_intro=free_intro,
            target_low_con=target_low_con
        )

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if has_intro and current_char and current_char.char_name in {'char_hiyuki'}:
            return SwitchPriority.MUST
        return super().get_switch_priority(current_char, has_intro, target_low_con)
