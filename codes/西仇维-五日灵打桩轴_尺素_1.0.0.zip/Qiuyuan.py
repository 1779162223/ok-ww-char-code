# ============================================================================
# Qiuyuan.py —— 西仇维(维里奈 / 仇远 / 西格莉卡)第二棒：仇远
# ============================================================================
import time

from src.char.Qiuyuan import Qiuyuan as NativeQiuyuan
from src.char.Xigelika import Xigelika as NativeXigelika


class Qiuyuan(NativeQiuyuan):
    """仇远 —— 西仇维第二棒: 长按E -> R -> 2A + 回路重击*3 -> 攒满协奏切西格莉卡。"""

    # ================================================================ 固定顺序切人 (公共段)
    SWITCH_TIMEOUT: float = 2.0
    SWITCH_KEY_INTERVAL: float = 0.12
    SWITCH_SETTLE: float = 0.55
    SETTLE_ATTACK_INTERVAL: float = 0.42
    HANDOFF_CON_WAIT: float = 0.8
    HANDOFF_CON_POLL: float = 0.1
    HOLD_POLL: float = 0.1
    F_BREAK_ON_HANDOFF: bool = False

    intro_pending = False
    switch_confirmed_at = 0.0

    def note_intro_handoff(self):
        self.intro_pending = True

    def take_intro(self):
        intro = self.has_intro or self.intro_pending
        self.intro_pending = False
        return intro

    def reset_fixed_rotation(self):
        self.intro_pending = False

    def direct_switch(self, slot=None, assume_intro=False):
        """按数字键切到指定队伍位置, 并补上框架的交接记账。"""
        slot = self.NEXT_SLOT if slot is None else slot
        if slot is None:
            return False
        target = self.char_at_slot(slot)
        if target is None or target is self:
            return False
        has_intro = True if assume_intro else self.wait_con_full()
        if not self.switch_to_index(target.index):
            self.logger.warning(f'direct switch to slot {slot} failed')
            return False
        self.logger.info(f'direct switched to slot {slot} '
                         f'({target.char_name}, intro={has_intro})')
        self.handoff_to(target, has_intro)
        return True

    def switch_to_index(self, index):
        """按数字键切人直到 in_team 确认; 等待期间保持点普攻。"""
        start = time.time()
        while time.time() - start < self.SWITCH_TIMEOUT:
            in_team, current_index, _ = self.task.in_team()
            if in_team and current_index == index:
                self.switch_confirmed_at = time.time()
                self.settle_with_attack(self.SWITCH_SETTLE)
                return True
            self.task.send_key(index + 1)
            self.click()
            self.sleep(self.SWITCH_KEY_INTERVAL, check_combat=False)
        return False

    def settle_with_attack(self, duration):
        end = time.time() + duration
        while time.time() < end:
            self.click()
            self.sleep(min(self.SETTLE_ATTACK_INTERVAL, max(0.0, end - time.time())),
                       check_combat=False)

    def handoff_to(self, target, has_intro):
        """复刻 switch_next_char() 的交接记账。"""
        if self.F_BREAK_ON_HANDOFF:
            self.f_break(check_f_on_switch=True)
        self.task.in_liberation = False
        self.switch_out(con_full=has_intro)
        target.is_current_char = True
        target.has_intro = has_intro
        if has_intro and hasattr(target, 'note_intro_handoff'):
            target.note_intro_handoff()
        target.last_switch_in_time = self.switch_confirmed_at or time.time()
        self.switch_confirmed_at = 0.0
        if has_intro:
            now = time.time()
            self.task.add_freeze_duration(now, target.intro_motion_freeze_duration, -100)
            self.last_outro_time = now

    def wait_con_full(self):
        """短暂轮询协奏是否满。"""
        start = time.time()
        while time.time() - start < self.HANDOFF_CON_WAIT:
            if self.is_con_full():
                return True
            self.sleep(self.HANDOFF_CON_POLL, check_combat=False)
        self.logger.info(f'con not full before switch (con={self.get_current_con()}), '
                         f'next char gets no intro')
        return False

    def char_at_slot(self, slot):
        index = slot - 1
        for char in self.task.chars:
            if char is not None and char.index == index:
                return char
        return None

    def attack_chain(self, count, interval, last_interval=None):
        for i in range(count):
            self.click()
            if i == count - 1 and last_interval is not None:
                self.sleep(last_interval)
            else:
                self.sleep(interval)

    def hold_until(self, cond, timeout, name):
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < timeout:
            if cond():
                return True
            self.sleep(self.HOLD_POLL)
        self.logger.info(f'timed out waiting for {name} ({timeout:.1f}s)')
        return False

    # ---------------------------------------------- 硬 gate
    GATE_POLL: float = 0.12
    GATE_LOG_EVERY: float = 3.0

    def require(self, name, cond, action=None, timeout=0):
        """留场直到 cond() 成立; 到 timeout 放弃并返回 False。"""
        start = time.time()
        last_log = 0.0
        while True:
            if cond():
                return True
            self.check_combat()
            if action is not None:
                action()
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            if timeout > 0 and elapsed >= timeout:
                self.logger.warning(f'gate [{name}] gave up after {elapsed:.1f}s')
                return False
            if elapsed - last_log >= self.GATE_LOG_EVERY:
                last_log = elapsed
                self.logger.warning(f'gate [{name}] not satisfied after {elapsed:.1f}s')
            self.sleep(self.GATE_POLL)

    # ============================================================ 公共段结束

    # ---- 时间常量 ----
    INTRO_ANIM = 0.75
    E_HOLD_MIN = 0.35
    E_HOLD_MAX = 1.6
    E_TO_LIB = 0.05
    LIB_TO_A = 0.20
    A_INTERVAL = 0.42
    A_TO_HEAVY = 0.30
    ECHO_TRIES = 4
    ECHO_RETRY = 0.22
    HEAVY_MAX = 4.5
    LIB_WINDOW = 3.0
    LIB_RETRY = 0.12
    FORTE_WAIT = 2.5
    CON_GATE_TIMEOUT = 12.0
    CON_LOG_EVERY = 3.0
    SWITCH_ANCHOR_MAX = 1.5

    @property
    def NEXT_SLOT(self):
        for char in self.task.chars:
            if isinstance(char, NativeXigelika):
                return char.index + 1
        return None

    def reset_state(self):
        super().reset_state()
        self.check_f_on_switch = False

    def on_combat_end(self, chars):
        self.reset_fixed_rotation()
        super().on_combat_end(chars)

    # ------------------------------------------------------------------ 轴

    def do_perform(self):
        intro = self.take_intro()
        self.check_f_on_switch = False
        anchor = self.switch_in_anchor()
        if intro:
            self.sleep(max(0.0, anchor + self.INTRO_ANIM - time.time()), check_combat=False)
        if self.flying():
            self.wait_down()
        self.logger.info(f'qiuyuan axis start (intro={intro})')

        self.hold_resonance()
        self.sleep(self.E_TO_LIB)
        self.fire_liberation()
        self.sleep(self.LIB_TO_A)
        self.attack_chain(2, self.A_INTERVAL, last_interval=self.A_TO_HEAVY)
        self.forte_heavy()

        self.leave()

    # ------------------------------------------------------------------ 动作

    def hold_resonance(self):
        """长按 E 直到图标进冷却。E_HOLD_MIN 防止读数抖动导致只按一下。"""
        key = self.get_resonance_key()
        self.task.send_key_down(key)
        try:
            self.sleep(self.E_HOLD_MIN, check_combat=False)
            landed = self.task.wait_until(lambda: self.has_cd('resonance'),
                                          time_out=self.E_HOLD_MAX - self.E_HOLD_MIN)
        finally:
            self.task.send_key_up(key)
        self.record_resonance_use()
        if not landed:
            self.logger.warning(f'qiuyuan: E cd not seen within {self.E_HOLD_MAX}s')
        self.sleep(0.05)
        return landed

    def fire_liberation(self):
        """R —— 在 LIB_WINDOW 秒内反复试, 一边补普攻一边等能量攒够。"""
        self.task.in_liberation = False
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < self.LIB_WINDOW:
            self.task.next_frame()
            if self.liberation_available():
                waited = self.time_elapsed_accounting_for_freeze(start)
                if self.click_liberation(wait_if_cd_ready=0.3, click_f=False):
                    self.logger.info(f'qiuyuan: liberation fired after {waited:.2f}s')
                    return True
            self.check_combat()
            self.click()
            self.sleep(self.LIB_RETRY)
        self.logger.warning(f'qiuyuan: liberation never lit within {self.LIB_WINDOW}s')
        return self.click_liberation(wait_if_cd_ready=0.5, click_f=False)

    def forte_heavy(self):
        """回路重击*3: 按住普攻直到回路耗尽。按住期间不发任何键。"""
        if not self.require('仇远 回路满', self.is_mouse_forte_full,
                            action=self.click, timeout=self.FORTE_WAIT):
            self.logger.warning('qiuyuan: forte not ready, firing echo without the heavy')
            self.fire_echo()
            return False
        self.task.mouse_down()
        try:
            self.hold_until(lambda: not self.is_mouse_forte_full(),
                            self.HEAVY_MAX, '仇远 回路重击打完')
        finally:
            self.task.mouse_up()
        self.sleep(0.05)
        return True

    def fire_echo(self):
        """Q —— 连发 ECHO_TRIES 次; 进来时可用、中途读到冷却即收手。"""
        was_available = self.echo_available()
        if not was_available:
            self.logger.info('qiuyuan: echo reads on-cd, sending once anyway')
        for i in range(self.ECHO_TRIES):
            self.send_echo_key()
            self.record_echo_use()
            self.sleep(self.ECHO_RETRY, check_combat=False)
            if not was_available:
                return False
            if not self.echo_available():
                if i:
                    self.logger.info(f'qiuyuan: echo landed on try {i + 1}')
                return True
        return False

    # ------------------------------------------------------------------ 离场

    def leave(self):
        """协奏满后 Q + 切西格莉卡。"""
        con_ok = self.fill_con()
        self.fire_echo()
        if not self.direct_switch(assume_intro=con_ok):
            self.logger.warning('qiuyuan: direct switch failed, falling back')
            self.switch_next_char()

    def fill_con(self):
        """等协奏满 —— 期间盯着回路, 满了就补一发重击。"""
        start = time.time()
        last_log = 0.0
        while True:
            if self.is_con_full():
                return True
            elapsed = self.time_elapsed_accounting_for_freeze(start)
            left = self.CON_GATE_TIMEOUT - elapsed
            if left <= 0:
                self.logger.warning(f'qiuyuan: con not full at timeout '
                                    f'(con={self.get_current_con():.2f})')
                return False
            if elapsed - last_log >= self.CON_LOG_EVERY:
                last_log = elapsed
                self.logger.warning(f'qiuyuan: waiting con ({elapsed:.1f}s, '
                                    f'con={self.get_current_con():.2f})')
            if self.is_mouse_forte_full():
                self.task.mouse_down()
                try:
                    self.hold_until(lambda: not self.is_mouse_forte_full(),
                                    min(self.HEAVY_MAX, left), '仇远 补的回路重击')
                finally:
                    self.task.mouse_up()
                self.sleep(0.05)
                continue
            self.check_combat()
            self.click()
            self.sleep(self.A_INTERVAL)

    # ------------------------------------------------------------------ 小工具

    def switch_in_anchor(self):
        now = time.time()
        anchored = self.last_switch_in_time
        gap = now - anchored if anchored > 0 else -1
        if 0 <= gap <= self.SWITCH_ANCHOR_MAX:
            return anchored
        return now
