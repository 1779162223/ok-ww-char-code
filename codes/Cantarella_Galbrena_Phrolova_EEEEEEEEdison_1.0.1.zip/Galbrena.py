import logging
import time

from src.char.BaseChar import BaseChar, SwitchPriority

# ---------------- 模块级日志部件（三个文件各带一份，内容保持一致） ----------------
_RATIO_FIELDS = ('con', 'res_pct')
_FILTERED_SWITCH_LINES = (
    'BaseCombatTask:switch selection result',
    'BaseCombatTask:switch_next_char end',
)


def _fmt_value(key, v):
    if isinstance(v, float):
        return f'{v:.3f}' if key in _RATIO_FIELDS else f'{v:.2f}'
    return str(v)


class _InfoAsDebug:
    """Per-instance logger: framework info lines become debug; everything else passes through."""

    def __init__(self, inner):
        self._inner = inner

    def info(self, message):
        self._inner.debug(message)

    def __getattr__(self, name):
        return getattr(self._inner, name)


class _AxisSwitchFilter(logging.Filter):
    """Drops the task-level switch info lines while the running task's team has an axis char."""

    okww_axis_switch_filter = True

    def __init__(self, executor):
        super().__init__()
        self._executor = executor

    def filter(self, record):
        try:
            if record.levelno != logging.INFO or not record.getMessage().startswith(_FILTERED_SWITCH_LINES):
                return True
            chars = getattr(self._executor.current_task, 'chars', None) or []
            return not any(getattr(char, '_axis_char', False) for char in chars)
        except Exception:
            return True


def _install_axis_switch_filter(task):
    try:
        ok_logger = logging.getLogger('ok')
        if not any(getattr(f, 'okww_axis_switch_filter', False) for f in ok_logger.filters):
            ok_logger.addFilter(_AxisSwitchFilter(task.executor))
    except Exception:
        pass


class Galbrena(BaseChar):
    """弗坎嘉 30 秒轮椅轴（BV1nAC6BRETp）：嘉贝莉娜，循环轴从 Galbrena.s1 开始。

    启动轴 Cantarella.f1 -> Galbrena.f1 -> Phrolova.f1 -> 循环轴
    循环轴 Galbrena.s1 -> Cantarella.s1 -> Galbrena.s2 -> Cantarella.s2 -> Phrolova.s1 -> Galbrena.s1
    """

    _axis_char = True

    # 视频实测（0-75s）；A 段待专题：普攻段数，暂按视频时长
    # 从 cast echo: ok 起算，ok 比按 Q 晚约 0.25s、exit 到切人约 0.13s，按视频“按 Q 到切人”反推。
    # v6 实测 test_1513：f1 用 1.6 时按 Q 到切人 1.88–2.11s；s2 用 1.9 时 2.31s（游戏计时 2.59 / 2.61，视频 2.19）
    F1_AAA = 1.3  # f1 按 Q 5.3 到切人 7.0 共 1.7s
    S2_AAA = 1.55  # s2 按 Q 41.95 到切人 43.9 共 1.95s
    # s1 ZZ：变奏入场后一次长按连出 2 段重击（攻略 BV1oox6zdE8w@98.5–102s，用户 2026-10-09 指出）；
    # 时长取上游 Galbrena.do_perform 有变奏时按住的 86F（1.44s）。v11 及以前是两次各按 0.5s
    Z_HOLD = 1.44
    # 入场到回路满：v4/v5/v6 实测 +2.1–3.8s（不含 R 之后才满的 +7.1、+8.0）；ZZ闪A 后约 +1.1 开始等，余下 2.7s × 1.5。
    # 原 2.3s：v6 实测 test_1445 v35.0 回路刚满就超时 skip_e2（v5 231.39 晚 0.39s），普通形态放 R、无爆发离场，连锁
    E2_WAIT = 4.0
    # 入场这么久后才按 E2：入场时回路已满、ZZ闪A 后约 +1.3s 立即按，5 次全被吞、空等 E2_CONFIRM 后重试才放出
    # （v4 182.4、355.5，v5 68.37、145.95、264.28）；+2.2–3.1s 按的 9 次都一次成功；参考视频 +3.0
    E2_EARLIEST = 2.2
    # 回路满须持续这么久才算：boss 白闪只有单帧（v2 实测 test_0854 run1 55.45 白占比 0.108 > 0.08，条实际约 3/4，按成普通 E）
    E2_SETTLE = 0.1
    E2_CONFIRM = 2.0  # 按 E2 到爆发图标出现：实测 run3' 超过 1.07s（v1 等 1.0s 误报失败）
    E2_TO_R = 0.2  # 爆发图标出现到 R：24.2->24.4、64.9->65.05；简介④ E2R 连按太快会吞 E2
    # 爆发 4A闪3A闪A 每组连点多久，组间朝敌人滑步，最后一组打完就切人。R 后从强化 A2 起、A5 后接 A3、滑步不重置段数
    # （作者 BV1rPChBAEda 简介②⑤⑦，攻略 BV1oox6zdE8w@929–952s 流程条），即 A2–A5 闪 A3–A5 闪 A3，最后的 A3 可脱手。
    # 作者两次滑步的 666 在 HUD 恢复后 +4.2、+7.5 出现（BV1rPChBAEda 35.0、38.3），滑步约早 0.2s，即 +4.0、+7.3。
    # v9 按每段 0.5s 推算，+2.0 就闪，A3 刚出手就被打断
    BURST_GROUPS = (4.0, 3.3, 0.5)
    # 图标连续消失这么久才算爆发结束：v5 实测 test_1413 v202.3 单帧漏检（图标实际亮到切人 203.58），
    # 提前收手、协奏 0.81 无变奏离场，连锁约 46s
    BURST_END_SETTLE = 0.3

    # A property, not an __init__ assignment: CharFactory copies the built-in instance's __dict__
    # over this one on team load, and a data descriptor wins over the instance __dict__.
    @property
    def logger(self):
        return self._quiet_logger

    @logger.setter
    def logger(self, value):
        self._raw_logger = value
        self._quiet_logger = _InfoAsDebug(value)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _install_axis_switch_filter(self.task)
        self._force_switch_me = False
        self._entry_mode = None
        self._node = None
        self.started = False
        self._startup_done = False

    def reset_state(self):
        super().reset_state()
        self.started = False
        self._startup_done = False
        self._entry_mode = None

    def f_break(self, check_f_on_switch=False, force=False):
        # s1 离场切坎时框架不按 F，击破改在坎 s1 开局（用户 2026-10-09）：有变奏时框架在切人键之前按 F，
        # 击破打断最后强化 A3 的合轴（v12 实测 test_0043）。f1、s2 离场照旧
        if check_f_on_switch and self._node == 's1':
            return False
        return super().f_break(check_f_on_switch, force)

    # ---------------- 强切协议（队里每个类都带同一份） ----------------
    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if self._force_switch_me:
            return SwitchPriority.MUST
        for char in self.task.chars:
            if char is not None and char is not self and getattr(char, '_force_switch_me', False):
                return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def _find_teammate(self, class_name):
        # Workshop classes are loaded standalone, so isinstance() against src.char.* never matches.
        for char in self.task.chars:
            if char is not None and char.__class__.__name__ == class_name:
                return char
        return None

    def _force_switch_to(self, target, mode):
        if target is None:
            self._raw_logger.warning(f'[{self._node.upper()}] fallback: framework_switch reason=teammate_missing')
            return self.switch_next_char()
        target._entry_mode = mode
        for char in self.task.chars:
            if char is not None:
                char._force_switch_me = char is target
        try:
            return self.switch_next_char()
        finally:
            for char in self.task.chars:
                if char is not None:
                    char._force_switch_me = False

    # ---------------- 分发器 ----------------
    def _mark_startup_done(self):
        for char in self.task.chars:
            if char is not None:
                char._startup_done = True

    def do_perform(self):
        mode = self._entry_mode
        self._entry_mode = None
        if mode is None:
            if not self.started:
                mode = 'f1'
            elif self._startup_done:
                mode = 's1'
            else:
                self._trace(None, 'interrupt', reason='startup_in_progress', next='framework')
                return self.switch_next_char()
            entry = 'intro' if self.has_intro else 'natural'
        else:
            entry = 'forced'
        if mode.startswith('s'):
            self._mark_startup_done()
        self.started = True
        func = getattr(self, f'perform_{mode}', None)
        if func is None:
            self._trace(mode, 'interrupt', reason='unknown_mode', next='framework')
            return self.switch_next_char()
        self._node = mode
        self._trace(mode, 'enter', mode=entry)
        return func()

    # ---------------- 日志 ----------------
    def _trace(self, tag, event, ok=None, reason=None, **data):
        """Write one template line: [TAG] event[: ok|fail] [reason=code] [key=value ...]."""
        try:
            line = f'[{tag.upper()}] {event}' if tag else event
            if ok is not None:
                line += ': ok' if ok else ': fail'
            if reason:
                line += f' reason={reason}'
            for key, value in data.items():
                line += f' {key}={_fmt_value(key, value)}'
            self._raw_logger.info(line)
        except Exception:
            pass

    # ---------------- 动作 helper（三个文件各带一份，内容保持一致） ----------------
    def _ready_or_skip(self, tag, skill, ready, time_out, settle_time=-1):
        """Normal-attack until ready() holds (for settle_time seconds when given); on timeout log a fallback
        warning and return False."""
        if self.task.wait_until(ready, pre_action=self.check_combat if time_out > 1 else None,
                                post_action=self.click_with_interval, time_out=time_out, settle_time=settle_time):
            return True
        self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_{skill} reason=not_ready')
        return False

    def _cast_e(self, tag, ready_time_out=1.0, time_out=1.0, skill=None, settle_time=-1):
        """E that shows a CD after the cast: press until the CD appears (1-6).
        skill names which E it is when one key casts several (fallback name and log field)."""
        if not self._ready_or_skip(tag, skill or 'e', self.resonance_available, ready_time_out, settle_time):
            return False
        ok = bool(self.task.wait_until(lambda: not self.resonance_available(),
                                       pre_action=self.check_combat if time_out > 1 else None,
                                       post_action=self.send_resonance_key, time_out=time_out))
        if ok:
            self.record_resonance_use()
        data = {'skill': skill} if skill else {}
        self._trace(tag, 'cast E', ok=ok, reason=None if ok else 'icon_still_lit', **data)
        return ok

    def _cast_echo(self, tag, ready_time_out=1.0, time_out=1.0):
        if not self._ready_or_skip(tag, 'echo', self.echo_available, ready_time_out):
            return False
        ok = self.click_echo(time_out=time_out)
        self._trace(tag, 'cast echo', ok=ok, reason=None if ok else 'icon_still_lit')
        return ok

    def _cast_r(self, tag, ready_time_out=1.0, click_f=True):
        if not self._ready_or_skip(tag, 'r', self.liberation_available, ready_time_out):
            return False
        ok = self.click_liberation(click_f=click_f)
        self._trace(tag, 'cast R', ok=ok, reason=None if ok else 'no_animation')
        return ok

    def _dodge(self):
        self.task.send_key(self.task.key_config.get('Dodge Key'))

    def _dodge_forward(self):
        # 爆发中的滑步要朝敌人（用户回答 2026-10-08）：按住前进再闪避
        self.task.send_key_down('w')
        try:
            self.task.next_frame()
            self._dodge()
        finally:
            # next_frame 在任务暂停或停止时会抛异常，前进键不能留在按下状态
            self.task.send_key_up('w')

    def _outro(self, tag, time_out):
        """↓: leave at full concerto; otherwise attack until it fills, and leave anyway on timeout."""
        if self.task.wait_until(self.is_con_full, pre_action=self.check_combat if time_out > 1 else None,
                                post_action=self.click_with_interval, time_out=time_out):
            self._trace(tag, 'decide: outro', con_full=True)
            return True
        self._raw_logger.warning(f'[{tag.upper()}] fallback: switch_without_outro reason=timeout con_full=False')
        return False

    # ---------------- 节点：f = 启动轴，s = 循环轴（薄包装，最后一句保持字面写法） ----------------
    def perform_f1(self):
        self._action_qaaa('f1', 'Phrolova.f1', self.F1_AAA)
        self._force_switch_to(self._find_teammate('Phrolova'), 'f1')

    def perform_s1(self):
        self._action_s1('s1', 'Cantarella.s1')
        self._force_switch_to(self._find_teammate('Cantarella'), 's1')

    def perform_s2(self):
        self._action_qaaa('s2', 'Cantarella.s2', self.S2_AAA)
        self._force_switch_to(self._find_teammate('Cantarella'), 's2')

    # ---------------- 动作体（tag = 日志节点，nxt = exit 行去向） ----------------
    # “嘉 QAAA”：启动轴视频 5.1-7.0，循环轴 41.7-43.9（都是坎强切、无变奏）；入场即 Q
    def _action_qaaa(self, tag, nxt, aaa):
        self._cast_echo(tag)
        self.continues_normal_attack(aaa)
        self._trace(tag, 'exit', reason='done', next=nxt)

    # 循环轴“嘉 ZZ闪A【E】R爆发↓”，视频 21.1-35.7（第 2 遍 61.9-74.6；弗 ↓ 带变奏切入）
    def _action_s1(self, tag, nxt):
        entered = time.time()
        # ZZ闪A：切入即按住重击（简介⑧：预输入重击，切入后从 Z1 开始），一次按住打出两段
        self.heavy_attack(self.Z_HOLD)
        self._trace(tag, 'cast heavy')
        self._dodge()
        self.normal_attack()
        self._cast_e2(tag, entered)
        # 爆发分组按真实时间计时，R 演出里不按 F：click_liberation 默认每 0.1s 按 F，R 一结束就触发击破，
        # 全局时停 1.3–1.5s 吃掉爆发时间（v10 test_2142 c3 145.6–147.1、v11 首版 test_2257 c3 138.6–139.9），
        # 能量打不完、协奏不满。击破留给坎 s1 开局（v13，见本类 f_break）
        self._cast_r(tag, click_f=False)
        self._burst(tag)
        self._outro(tag, 1.0)
        self._trace(tag, 'exit', reason='done', next=nxt)

    def _burst_shown(self):
        # 同上游 Galbrena.check_res：左格爆发图标，用项目自带的 has_target / no_target 模板
        if not self.task.in_team_and_world():
            return False
        return self.task.find_best_match_in_box(self.task.get_box_by_name('box_target_enemy_long'),
                                                ['has_target', 'no_target'], threshold=0.6)

    def _cast_e2(self, tag, entered):
        """【E】: E2 never shows a CD, so click_resonance would keep pressing until its timeout.
        Wait for the forte bar (upstream Galbrena's E2 condition) and E2_EARLIEST after entering, press once,
        confirm by the burst icon (5-3)."""
        if not self._ready_or_skip(tag, 'e2',
                                   lambda: time.time() - entered >= self.E2_EARLIEST and self.is_forte_full(),
                                   self.E2_WAIT, settle_time=self.E2_SETTLE):
            return False
        for attempt in (1, 2):
            self.send_resonance_key()
            ok = bool(self.task.wait_until(self._burst_shown, time_out=self.E2_CONFIRM))
            self._trace(tag, 'cast E' if attempt == 1 else 'retry E', ok=ok, reason=None if ok else 'timeout',
                        attempt=attempt)
            if ok:
                self.record_resonance_use()
                self.sleep(self.E2_TO_R)
                return True
            # 回路已不满：E2 已放出、只是没确认到爆发图标，不再补按
            if attempt == 2 or not self.is_forte_full():
                return False

    def _burst(self, tag):
        """爆发：按 BURST_GROUPS 打一遍 AAAA闪AAA闪A 就走；左格爆发图标连续 BURST_END_SETTLE 消失则提前收手。"""
        # 不在 click_liberation 返回的那一帧上判：v7 实测 test_1621 v40.233 HUD 还在淡入（队伍编号已过 0.8、
        # 爆发图标 0.62），单帧判成没进爆发，两场第 1 轮都一下没打就无延奏离场
        if not self.task.wait_until(self._burst_shown, post_action=self.click_with_interval,
                                    time_out=self.BURST_END_SETTLE):
            self._trace(tag, 'attack', group=0)
            return True
        for group, time_out in enumerate(self.BURST_GROUPS, 1):
            if group > 1:
                self._dodge_forward()
            # 组内也每帧查图标，爆发一结束就收手（v1 只在段间查，实测最多晚 1.6s）；结束只认连续消失
            if self.task.wait_until(lambda: not self._burst_shown(), pre_action=self.check_combat,
                                    post_action=self.click_with_interval, time_out=time_out,
                                    settle_time=self.BURST_END_SETTLE):
                self._trace(tag, 'attack', group=group, ended=True)
                return True
        # 打完最后的 A3 爆发图标还亮：净炼火命中才消耗（简介⑤），记下来供下一版校每组时长
        self._trace(tag, 'attack', group=len(self.BURST_GROUPS), ended=False)
        return True
