import logging

import numpy as np

from src.char.BaseChar import BaseChar, SwitchPriority

# ---------------- 模块级日志部件（三个文件各带一份，内容保持一致） ----------------
_RATIO_FIELDS = ('con', 'res_pct')
_FILTERED_SWITCH_LINES = (
    'BaseCombatTask:switch selection result',
    'BaseCombatTask:switch_next_char end',
)


def _fmt_value(key, v):
    if isinstance(v, float):
        return f'{v:.3f}' if key in _RATIO_FIELDS else f'{v:.2f}'
    return str(v)


class _InfoAsDebug:
    """Per-instance logger: framework info lines become debug; everything else passes through."""

    def __init__(self, inner):
        self._inner = inner

    def info(self, message):
        self._inner.debug(message)

    def __getattr__(self, name):
        return getattr(self._inner, name)


class _AxisSwitchFilter(logging.Filter):
    """Drops the task-level switch info lines while the running task's team has an axis char."""

    okww_axis_switch_filter = True

    def __init__(self, executor):
        super().__init__()
        self._executor = executor

    def filter(self, record):
        try:
            if record.levelno != logging.INFO or not record.getMessage().startswith(_FILTERED_SWITCH_LINES):
                return True
            chars = getattr(self._executor.current_task, 'chars', None) or []
            return not any(getattr(char, '_axis_char', False) for char in chars)
        except Exception:
            return True


def _install_axis_switch_filter(task):
    try:
        ok_logger = logging.getLogger('ok')
        if not any(getattr(f, 'okww_axis_switch_filter', False) for f in ok_logger.filters):
            ok_logger.addFilter(_AxisSwitchFilter(task.executor))
    except Exception:
        pass


class Phrolova(BaseChar):
    """弗坎嘉 30 秒轮椅轴（BV1nAC6BRETp）：弗洛洛，启动轴最后一个节点接循环轴。

    启动轴 Cantarella.f1 -> Galbrena.f1 -> Phrolova.f1 -> 循环轴
    循环轴 Galbrena.s1 -> Cantarella.s1 -> Galbrena.s2 -> Cantarella.s2 -> Phrolova.s1 -> Galbrena.s1
    """

    _axis_char = True

    # 视频实测 f1 7.0-21.1 / s1 47.9-61.9（两遍间隔一致）；A 段待专题：普攻段数，暂按视频时长
    #   open    开头 A 段：f1 AA 7.0-8.7；s1 A 48.0-50.2（含变奏入场）
    #   enh_a1  Q 后【A】：f1 8.8-9.6；s1 50.4-51.0
    #   e       【A】到 E 的间隔 × 1.5，E 连按到进冷却的时限：f1 9.6->10.3；s1 51.0->51.9
    #   enh_a2  E 后【A】：f1 10.4-11.0；s1 52.0-52.6
    #   outro   R 动画结束到 ↓ 的间隔 × 1.5，最少 1s：f1 20.2->21.1；s1 61.2->61.9
    F1 = {'open': 1.7, 'enh_a1': 0.8, 'e': 1.1, 'enh_a2': 0.6, 'outro': 1.4}
    S1 = {'open': 2.2, 'enh_a1': 0.6, 'e': 1.4, 'enh_a2': 0.6, 'outro': 1.1}
    # 两次闪避之间的 AAA 打到强化提示亮再闪：E 格冷却数字被星形图标盖住，resonance_available() 变真
    # 视频 闪 11.1 -> 提示 12.5；s1 闪 52.7 -> 提示 54.2；v2 实测 test_0854 run2 闪后 1.6s 才亮
    AAA_TO_HINT = 3.0
    # 提示亮时第 3 段还没出伤，马上闪会打断、音符收不全（用户确认）。视频 提示 12.6 -> 命中 13.0 -> 闪 13.1；
    # s1 提示 54.2 -> 命中 54.6；v2 实测 test_1002 提示后 0.1-0.3s 就闪，提示后只得 1 个音符、停在 5 个。
    # v14 固定再普攻 0.5s 就闪，实测 test_2354 s1 第 3 次第 3 段音符没拿到、多打一整轮约 5s（v11 test_2257 s1 c2 同样），
    # 改为普攻到第 5 音符亮起再闪，等不到就到时照闪。4 段录屏 24 圈：提示亮 -> 第 5 音符 20 圈 0.48-0.83s，
    # 其余 4 圈 1.1-4.8s（含上面 test_2354 那次）
    HINT_TO_NOTE = 1.5
    # 第 5 音符格（1920x1080 录屏量的框）：格内高饱和像素（max-min >= 100 且 max >= 150）占比，空格约 0、有音符 0.12-0.20；
    # 特效会冲到 0.8-1.0，但都是单帧到 0.2s 的尖峰，所以要求落在区间内并持续 NOTE_SETTLE。
    # 24 圈离线评估：提示亮到音符亮之间 0 次误报，判定比音符显形晚 0.08s（中位）、最多 0.45s
    NOTE5_BOX = (1019, 980, 1045, 1014)
    NOTE_SAT_RANGE = (0.08, 0.40)
    NOTE_SETTLE = 0.1
    # 第二次闪避后【A】打到 6 音符（mouse_forte）再【Z】：视频 闪 13.1 -> 14.0。何时重击由 mouse_forte 决定，这里只是上限：
    # 攒音符时被 boss 打断要多打一轮（用户确认），v3 实测 test_1053 s1 第 2 轮第 6 音符 146.9 比 3.0s 上限晚 0.3s
    HINT_TO_HEAVY = 6.0
    HEAVY_TO_R = 3.0  # 同上游 Phrolova.heavy_and_liber；视频【Z】14.0-16.8 -> R 16.9
    # 满 6 音符后按住左键一段时间才进重击，进了以后松手不打断、伤害不丢；重击打完 R 才亮（用户 2026-10-09）。
    # 上游 heavy_click_forte 认不到 mouse_forte 就松手，v13 实测 test_0110 按住只有 0.1-0.2s（第 6 音符 → cast heavy 0.14-0.28s），
    # 之后到 R 演出开始 2.44-3.10s 不等，用户看到进重击时快时慢（377s）。改为至少按住 HEAVY_HOLD：
    # 远长于进重击要的时长，又远短于重击动作（到 R 2.4s 以上），不会按到重击打完再起一次重击
    HEAVY_HOLD = 1.0
    HEAVY_HOLD_MAX = 2.0  # 同 heavy_click_forte 的上限：到这时鼠标图标还亮就算没放出

    # A property, not an __init__ assignment: CharFactory copies the built-in instance's __dict__
    # over this one on team load, and a data descriptor wins over the instance __dict__.
    @property
    def logger(self):
        return self._quiet_logger

    @logger.setter
    def logger(self, value):
        self._raw_logger = value
        self._quiet_logger = _InfoAsDebug(value)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _install_axis_switch_filter(self.task)
        self._force_switch_me = False
        self._entry_mode = None
        self._node = None
        self.started = False
        self._startup_done = False

    def reset_state(self):
        super().reset_state()
        self.started = False
        self._startup_done = False
        self._entry_mode = None

    def f_break(self, check_f_on_switch=False, force=False):
        # 只放行显式 force（okww-charcode-dev workshop.md 9b），弗洛洛离场时框架不再按 F。v4 实测 test_1208 三场：
        # boss 2 击破圈恰在 s1 R 后亮起，弗在 R 状态离 boss 远、F 按不出，框架连按 F 不切人，
        # 拖过 2s 不查战斗窗口后被判脱战、重走启动轴。击破留给在 boss 身边的嘉贝莉娜、坎特蕾拉打（v13 嘉 s1 的挪到坎 s1 开局）
        if force:
            return self.task.f_break()
        return False

    def skip_combat_check(self):
        # 同上游 Phrolova：R 后赫卡忒视角抬高、锁定丢失，2s 内不查战斗
        # （v2 实测 test_1002 两遍 s1 都在 R 后约 3s target_enemy failed，被判脱战、回到启动轴）
        return self.time_elapsed_accounting_for_freeze(self.last_liberation) < 2

    # ---------------- 强切协议（队里每个类都带同一份） ----------------
    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if self._force_switch_me:
            return SwitchPriority.MUST
        for char in self.task.chars:
            if char is not None and char is not self and getattr(char, '_force_switch_me', False):
                return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def _find_teammate(self, class_name):
        # Workshop classes are loaded standalone, so isinstance() against src.char.* never matches.
        for char in self.task.chars:
            if char is not None and char.__class__.__name__ == class_name:
                return char
        return None

    def _force_switch_to(self, target, mode):
        if target is None:
            self._raw_logger.warning(f'[{self._node.upper()}] fallback: framework_switch reason=teammate_missing')
            return self.switch_next_char()
        target._entry_mode = mode
        for char in self.task.chars:
            if char is not None:
                char._force_switch_me = char is target
        try:
            return self.switch_next_char()
        finally:
            for char in self.task.chars:
                if char is not None:
                    char._force_switch_me = False

    # ---------------- 分发器 ----------------
    def _mark_startup_done(self):
        for char in self.task.chars:
            if char is not None:
                char._startup_done = True

    def do_perform(self):
        mode = self._entry_mode
        self._entry_mode = None
        if mode is None:
            if not self.started:
                mode = 'f1'
            elif self._startup_done:
                mode = 's1'
            else:
                self._trace(None, 'interrupt', reason='startup_in_progress', next='framework')
                return self.switch_next_char()
            entry = 'intro' if self.has_intro else 'natural'
        else:
            entry = 'forced'
        if mode.startswith('s'):
            self._mark_startup_done()
        self.started = True
        func = getattr(self, f'perform_{mode}', None)
        if func is None:
            self._trace(mode, 'interrupt', reason='unknown_mode', next='framework')
            return self.switch_next_char()
        self._node = mode
        self._trace(mode, 'enter', mode=entry)
        return func()

    # ---------------- 日志 ----------------
    def _trace(self, tag, event, ok=None, reason=None, **data):
        """Write one template line: [TAG] event[: ok|fail] [reason=code] [key=value ...]."""
        try:
            line = f'[{tag.upper()}] {event}' if tag else event
            if ok is not None:
                line += ': ok' if ok else ': fail'
            if reason:
                line += f' reason={reason}'
            for key, value in data.items():
                line += f' {key}={_fmt_value(key, value)}'
            self._raw_logger.info(line)
        except Exception:
            pass

    # ---------------- 动作 helper（三个文件各带一份，内容保持一致） ----------------
    def _ready_or_skip(self, tag, skill, ready, time_out, settle_time=-1):
        """Normal-attack until ready() holds (for settle_time seconds when given); on timeout log a fallback
        warning and return False."""
        if self.task.wait_until(ready, pre_action=self.check_combat if time_out > 1 else None,
                                post_action=self.click_with_interval, time_out=time_out, settle_time=settle_time):
            return True
        self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_{skill} reason=not_ready')
        return False

    def _cast_e(self, tag, ready_time_out=1.0, time_out=1.0, skill=None, settle_time=-1):
        """E that shows a CD after the cast: press until the CD appears (1-6).
        skill names which E it is when one key casts several (fallback name and log field)."""
        if not self._ready_or_skip(tag, skill or 'e', self.resonance_available, ready_time_out, settle_time):
            return False
        ok = bool(self.task.wait_until(lambda: not self.resonance_available(),
                                       pre_action=self.check_combat if time_out > 1 else None,
                                       post_action=self.send_resonance_key, time_out=time_out))
        if ok:
            self.record_resonance_use()
        data = {'skill': skill} if skill else {}
        self._trace(tag, 'cast E', ok=ok, reason=None if ok else 'icon_still_lit', **data)
        return ok

    def _cast_echo(self, tag, ready_time_out=1.0, time_out=1.0):
        if not self._ready_or_skip(tag, 'echo', self.echo_available, ready_time_out):
            return False
        ok = self.click_echo(time_out=time_out)
        self._trace(tag, 'cast echo', ok=ok, reason=None if ok else 'icon_still_lit')
        return ok

    def _cast_r(self, tag, ready_time_out=1.0, click_f=True):
        if not self._ready_or_skip(tag, 'r', self.liberation_available, ready_time_out):
            return False
        ok = self.click_liberation(click_f=click_f)
        self._trace(tag, 'cast R', ok=ok, reason=None if ok else 'no_animation')
        return ok

    def _dodge(self):
        self.task.send_key(self.task.key_config.get('Dodge Key'))

    def _outro(self, tag, time_out):
        """↓: leave at full concerto; otherwise attack until it fills, and leave anyway on timeout."""
        if self.task.wait_until(self.is_con_full, pre_action=self.check_combat if time_out > 1 else None,
                                post_action=self.click_with_interval, time_out=time_out):
            self._trace(tag, 'decide: outro', con_full=True)
            return True
        self._raw_logger.warning(f'[{tag.upper()}] fallback: switch_without_outro reason=timeout con_full=False')
        return False

    # ---------------- 节点：f = 启动轴，s = 循环轴（薄包装，最后一句保持字面写法） ----------------
    def perform_f1(self):
        self._action_main('f1', 'Galbrena.s1', self.F1)
        self._force_switch_to(self._find_teammate('Galbrena'), 's1')

    def perform_s1(self):
        self._action_main('s1', 'Galbrena.s1', self.S1)
        self._force_switch_to(self._find_teammate('Galbrena'), 's1')

    # ---------------- 动作体（tag = 日志节点，nxt = exit 行去向） ----------------
    # 启动轴“弗 AAQ【A】E【A】闪 / 弗 AAA闪【AZ】R↓”，视频 7.0-21.1（嘉强切、无变奏）
    # 循环轴“弗 AQ【A】E【A】闪 / 弗 AAA闪【AZ】R↓”，视频 47.9-61.9（坎 ↓ 带变奏切入）
    # 两行是同一次上场；【A】是强化左键，强化期间的普攻即强化 A
    def _action_main(self, tag, nxt, t):
        self.last_liberation = -1  # 同上游 do_perform：只认本次上场的 R
        self.continues_normal_attack(t['open'])
        self._cast_echo(tag)
        self.continues_normal_attack(t['enh_a1'])
        self._cast_e(tag, time_out=t['e'])
        self.continues_normal_attack(t['enh_a2'])
        self._dodge()
        # 闪早了连段会重置、出不了强化提示（v1 固定 1.4s，实测 run2 101.9-106.0 卡在 4 音符）
        if self._ready_or_skip(tag, 'enh_hint', self.resonance_available, self.AAA_TO_HINT):
            if self._ready_or_skip(tag, 'note5', self.is_note5_lit, self.HINT_TO_NOTE, settle_time=self.NOTE_SETTLE):
                self._trace(tag, 'decide: dodge', note5=True)
        self._dodge()
        if self._cast_heavy(tag):
            self._cast_r_after_heavy(tag)
        else:
            # R 在强化重击之后才解锁（卡片），不再空等 3s（v2 实测 test_1002 f1 两遍 cast R: fail）
            self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_r reason=not_ready')
        self._outro(tag, t['outro'])
        self._trace(tag, 'exit', reason='done', next=nxt)

    def is_note5_lit(self):
        """五线谱左起第 5 个音符格亮着。"""
        box = self.task.box_of_screen_scaled(1920, 1080, *self.NOTE5_BOX, name='phrolova_note5', hcenter=True)
        crop = box.crop_frame(self.task.frame)[:, :, :3].astype(np.int16)
        top = crop.max(axis=2)
        ratio = np.count_nonzero((top >= 150) & (top - crop.min(axis=2) >= 100)) / max(top.size, 1)
        self.logger.debug(f'note5 ratio={ratio:.3f}')
        return self.NOTE_SAT_RANGE[0] <= ratio <= self.NOTE_SAT_RANGE[1]

    def _cast_heavy(self, tag):
        """【A】【Z】: attack until the 6th note, then hold heavy for at least HEAVY_HOLD and until the
        mouse_forte icon is gone (HEAVY_HOLD_MAX at most)."""
        if not self._ready_or_skip(tag, 'heavy', self.is_mouse_forte_full, self.HINT_TO_HEAVY):
            return False
        self.task.mouse_down()
        try:
            self.sleep(self.HEAVY_HOLD)
            ok = bool(self.task.wait_until(lambda: not self.is_mouse_forte_full(),
                                           time_out=self.HEAVY_HOLD_MAX - self.HEAVY_HOLD))
        finally:
            self.task.mouse_up()
        self._trace(tag, 'cast heavy', ok=ok, reason=None if ok else 'not_consumed')
        return ok

    def _cast_r_after_heavy(self, tag):
        # 重击收招前按 R 不出：同上游，不另设就绪门槛，反复 click_liberation 直到放出
        # （v1 先等 liberation_available 1s，实测 run3' 151.73 Z 后 152.74 跳过 R）
        ok = bool(self.task.wait_until(lambda: self.click_liberation(wait_if_cd_ready=0),
                                       pre_action=self.check_combat, time_out=self.HEAVY_TO_R))
        self._trace(tag, 'cast R', ok=ok, reason=None if ok else 'no_animation')
        return ok
