import logging
import time

from src.char.BaseChar import BaseChar, SwitchPriority

# ---------------- 模块级日志部件（三个文件各带一份，内容保持一致） ----------------
_RATIO_FIELDS = ('con', 'res_pct')
_FILTERED_SWITCH_LINES = (
    'BaseCombatTask:switch selection result',
    'BaseCombatTask:switch_next_char end',
)


def _fmt_value(key, v):
    if isinstance(v, float):
        return f'{v:.3f}' if key in _RATIO_FIELDS else f'{v:.2f}'
    return str(v)


class _InfoAsDebug:
    """Per-instance logger: framework info lines become debug; everything else passes through."""

    def __init__(self, inner):
        self._inner = inner

    def info(self, message):
        self._inner.debug(message)

    def __getattr__(self, name):
        return getattr(self._inner, name)


class _AxisSwitchFilter(logging.Filter):
    """Drops the task-level switch info lines while the running task's team has an axis char."""

    okww_axis_switch_filter = True

    def __init__(self, executor):
        super().__init__()
        self._executor = executor

    def filter(self, record):
        try:
            if record.levelno != logging.INFO or not record.getMessage().startswith(_FILTERED_SWITCH_LINES):
                return True
            chars = getattr(self._executor.current_task, 'chars', None) or []
            return not any(getattr(char, '_axis_char', False) for char in chars)
        except Exception:
            return True


def _install_axis_switch_filter(task):
    try:
        ok_logger = logging.getLogger('ok')
        if not any(getattr(f, 'okww_axis_switch_filter', False) for f in ok_logger.filters):
            ok_logger.addFilter(_AxisSwitchFilter(task.executor))
    except Exception:
        pass


class Cantarella(BaseChar):
    """弗坎嘉 30 秒轮椅轴（BV1nAC6BRETp）：坎特蕾拉开启动轴。

    启动轴 Cantarella.f1 -> Galbrena.f1 -> Phrolova.f1 -> 循环轴
    循环轴 Galbrena.s1 -> Cantarella.s1 -> Galbrena.s2 -> Cantarella.s2 -> Phrolova.s1 -> Galbrena.s1
    """

    _axis_char = True

    # 视频实测（0-75s）；A 段待专题：普攻段数，暂按视频时长
    # s1 重击按住到进湿身就松手，Z_HOLD 只是上限：v11 实测 test_2357 固定按 2.1s，c2、c3 按住 1.0 / 0.87s 就进了湿身，
    # 多按的 1.1–1.2s 让结晶提前满，第一下 E 放成终结技能，伞形 E 之后白等 2s 粉圈（c1 有变奏 1.73s 才进湿身）
    Z_HOLD = 2.1
    # 进湿身的判据：鼠标图标外框（带小三角）消失，和进湿身同一帧（test_2357 c1 53.8 -> 53.9、c3 149.1 -> 149.2），
    # 即上游 Cantarella 的 heavy_click_forte(check_fun=self.is_mouse_forte_full)；连续消失这么久才松手，防单帧漏检
    WET_SETTLE = 0.1
    # Z 收招后连按伞形 E 到进冷却：v2 实测 test_0854 run2 0.78s 才按出；run3' 被 boss 打出硬直，1.0s 内没按出
    UMBRELLA_E = 2.0
    TO_VORTEX = 2.0  # 伞形 E 后普攻到粉圈漩涡（结晶满）：视频 38.5 -> 39.8；实测 run2 130.75 -> 131.6
    # 粉圈 E 只认连续无冷却数字：v3 实测 test_1053 第 3 轮 171.4 冷却数字单帧漏读，没有粉圈却记成按出
    VORTEX_SETTLE = 0.2

    # A property, not an __init__ assignment: CharFactory copies the built-in instance's __dict__
    # over this one on team load, and a data descriptor wins over the instance __dict__.
    @property
    def logger(self):
        return self._quiet_logger

    @logger.setter
    def logger(self, value):
        self._raw_logger = value
        self._quiet_logger = _InfoAsDebug(value)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        _install_axis_switch_filter(self.task)
        self._force_switch_me = False
        self._entry_mode = None
        self._node = None
        self.started = False
        self._startup_done = False

    def reset_state(self):
        super().reset_state()
        self.started = False
        self._startup_done = False
        self._entry_mode = None

    # ---------------- 强切协议（队里每个类都带同一份） ----------------
    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        if self._force_switch_me:
            return SwitchPriority.MUST
        for char in self.task.chars:
            if char is not None and char is not self and getattr(char, '_force_switch_me', False):
                return SwitchPriority.NO
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def healer_full_con_switch_locked(self):
        # 轴强切坎时不受满协奏离场 16s 锁定：_choose_switch_target 先查锁再查优先级，MUST 绕不过。
        # v5 实测 test_1413 v90.7 坎 s1 满协奏离场，嘉 s2 强切坎 can't find next char，嘉连跑两遍 s1 到 v113.8，
        # 坎 s2、弗 s1 全丢，boss 1 击破圈 102–115 无人切人打。框架自行切人时锁定照旧
        return not self._force_switch_me and super().healer_full_con_switch_locked()

    def _find_teammate(self, class_name):
        # Workshop classes are loaded standalone, so isinstance() against src.char.* never matches.
        for char in self.task.chars:
            if char is not None and char.__class__.__name__ == class_name:
                return char
        return None

    def _force_switch_to(self, target, mode):
        if target is None:
            self._raw_logger.warning(f'[{self._node.upper()}] fallback: framework_switch reason=teammate_missing')
            return self.switch_next_char()
        target._entry_mode = mode
        for char in self.task.chars:
            if char is not None:
                char._force_switch_me = char is target
        try:
            return self.switch_next_char()
        finally:
            for char in self.task.chars:
                if char is not None:
                    char._force_switch_me = False

    # ---------------- 分发器 ----------------
    def _mark_startup_done(self):
        for char in self.task.chars:
            if char is not None:
                char._startup_done = True

    def do_perform(self):
        mode = self._entry_mode
        self._entry_mode = None
        if mode is None:
            if not self.started:
                mode = 'f1'
            elif self._startup_done:
                mode = 's1'
            else:
                self._trace(None, 'interrupt', reason='startup_in_progress', next='framework')
                return self.switch_next_char()
            entry = 'intro' if self.has_intro else 'natural'
        else:
            entry = 'forced'
        if mode.startswith('s'):
            self._mark_startup_done()
        self.started = True
        func = getattr(self, f'perform_{mode}', None)
        if func is None:
            self._trace(mode, 'interrupt', reason='unknown_mode', next='framework')
            return self.switch_next_char()
        self._node = mode
        self._trace(mode, 'enter', mode=entry)
        return func()

    # ---------------- 日志 ----------------
    def _trace(self, tag, event, ok=None, reason=None, **data):
        """Write one template line: [TAG] event[: ok|fail] [reason=code] [key=value ...]."""
        try:
            line = f'[{tag.upper()}] {event}' if tag else event
            if ok is not None:
                line += ': ok' if ok else ': fail'
            if reason:
                line += f' reason={reason}'
            for key, value in data.items():
                line += f' {key}={_fmt_value(key, value)}'
            self._raw_logger.info(line)
        except Exception:
            pass

    # ---------------- 动作 helper（三个文件各带一份，内容保持一致） ----------------
    def _ready_or_skip(self, tag, skill, ready, time_out, settle_time=-1):
        """Normal-attack until ready() holds (for settle_time seconds when given); on timeout log a fallback
        warning and return False."""
        if self.task.wait_until(ready, pre_action=self.check_combat if time_out > 1 else None,
                                post_action=self.click_with_interval, time_out=time_out, settle_time=settle_time):
            return True
        self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_{skill} reason=not_ready')
        return False

    def _cast_e(self, tag, ready_time_out=1.0, time_out=1.0, skill=None, settle_time=-1):
        """E that shows a CD after the cast: press until the CD appears (1-6).
        skill names which E it is when one key casts several (fallback name and log field)."""
        if not self._ready_or_skip(tag, skill or 'e', self.resonance_available, ready_time_out, settle_time):
            return False
        ok = bool(self.task.wait_until(lambda: not self.resonance_available(),
                                       pre_action=self.check_combat if time_out > 1 else None,
                                       post_action=self.send_resonance_key, time_out=time_out))
        if ok:
            self.record_resonance_use()
        data = {'skill': skill} if skill else {}
        self._trace(tag, 'cast E', ok=ok, reason=None if ok else 'icon_still_lit', **data)
        return ok

    def _cast_echo(self, tag, ready_time_out=1.0, time_out=1.0):
        if not self._ready_or_skip(tag, 'echo', self.echo_available, ready_time_out):
            return False
        ok = self.click_echo(time_out=time_out)
        self._trace(tag, 'cast echo', ok=ok, reason=None if ok else 'icon_still_lit')
        return ok

    def _cast_r(self, tag, ready_time_out=1.0, click_f=True):
        if not self._ready_or_skip(tag, 'r', self.liberation_available, ready_time_out):
            return False
        ok = self.click_liberation(click_f=click_f)
        self._trace(tag, 'cast R', ok=ok, reason=None if ok else 'no_animation')
        return ok

    def _dodge(self):
        self.task.send_key(self.task.key_config.get('Dodge Key'))

    def _outro(self, tag, time_out):
        """↓: leave at full concerto; otherwise attack until it fills, and leave anyway on timeout."""
        if self.task.wait_until(self.is_con_full, pre_action=self.check_combat if time_out > 1 else None,
                                post_action=self.click_with_interval, time_out=time_out):
            self._trace(tag, 'decide: outro', con_full=True)
            return True
        self._raw_logger.warning(f'[{tag.upper()}] fallback: switch_without_outro reason=timeout con_full=False')
        return False

    # ---------------- 节点：f = 启动轴，s = 循环轴（薄包装，最后一句保持字面写法） ----------------
    def perform_f1(self):
        self._action_f1('f1', 'Galbrena.f1')
        self._force_switch_to(self._find_teammate('Galbrena'), 'f1')

    def perform_s1(self):
        self._action_s1('s1', 'Galbrena.s2')
        self._force_switch_to(self._find_teammate('Galbrena'), 's2')

    def perform_s2(self):
        self._action_s2('s2', 'Phrolova.s1')
        self._force_switch_to(self._find_teammate('Phrolova'), 's1')

    # ---------------- 动作体（tag = 日志节点，nxt = exit 行去向） ----------------
    # 启动轴“坎 RQ”，视频 0.0-5.1：开场 1.1s 放 R，大招动画结束 4.7 后马上 Q
    def _action_f1(self, tag, nxt):
        self._cast_r(tag, ready_time_out=1.7)
        self._cast_echo(tag)
        self._trace(tag, 'exit', reason='done', next=nxt)

    # 循环轴“坎 ZEAAA【E】Q”，视频 35.7-41.7（嘉 ↓ 带变奏切入）
    def _action_s1(self, tag, nxt):
        # 击破：嘉 s1 离场不按 F（免得打断最后强化 A3 的合轴），挪到这里开局按（用户 2026-10-09）；没有击破图标时直接返回。
        # task.f_break 一直按到图标消失，返回时时停演出已结束（v12 test_0043 49.17–50.6 / 140.1–141.7 停走，切人在 50.67 / 141.79；
        # v11 test_2357 c1 坎入场即击破，52.1 恢复走动、52.07 进 s1），下面 Z 的实时上限不会被时停吃掉。
        # 先清掉框架的 can_break：它认到一次就一直留着，只有按过 F 才清。v13 test_0110 t2/t3 第一个 boss 的击破环在嘉 s1 期间满了、
        # 没被击破就先死了，坎 s1 开局对着空环的新 boss 空按 F 约 0.7s（break_check/ring_t2.png、ring_t3.png）。
        # 清掉后 f_break 只认当下的图标；真击破时图标一直实时认得到（同录像 6 次真击破，F 都从入场连按到时停快结束）
        self.task.can_break = False
        if self.f_break():
            self._trace(tag, 'decide: break')
        # Z：切入即按住，变奏入场包含在这一下重击里；进湿身就松手
        self._heavy_until_wet(tag)
        # E：湿身状态下是伞形 E（语义卡称强化技能）
        if self._cast_e(tag, time_out=self.UMBRELLA_E, skill='umbrella'):
            # AAA【E】：普攻到粉圈漩涡盖住冷却数字（resonance_available() 变真），立即连按到进冷却（39.8 漩涡，40.1 按下）；
            # 放出后直接 Q 切人，不等终结技能出伤（用户 2026-10-09）
            self._cast_e(tag, ready_time_out=self.TO_VORTEX, skill='vortex', settle_time=self.VORTEX_SETTLE)
        else:
            # 没有伞形 E 就出不了粉圈 E（v1 实测 run1 第二下 E 放成普通 E，run3' 第二下才放出伞形 E）
            self._raw_logger.warning(f'[{tag.upper()}] fallback: skip_vortex reason=not_ready')
        self._cast_echo(tag)
        self._trace(tag, 'exit', reason='done', next=nxt)

    def _heavy_until_wet(self, tag):
        """Z: hold until the mouse-icon outline shows and then stays gone for WET_SETTLE (entered wet), at most Z_HOLD.
        The outline may still be dark right after switching in, so wait for it to show first."""
        self.check_combat()
        start = time.time()
        self.task.mouse_down()
        try:
            wet = bool(self.task.wait_until(self.is_mouse_forte_full, time_out=self.Z_HOLD)) and bool(
                self.task.wait_until(lambda: not self.is_mouse_forte_full(),
                                     time_out=max(self.Z_HOLD - (time.time() - start), 0.01),
                                     settle_time=self.WET_SETTLE))
        finally:
            # wait_until 在任务暂停或停止时会抛异常，左键不能留在按下状态
            self.task.mouse_up()
        self._trace(tag, 'cast heavy', ok=wet, reason=None if wet else 'timeout')

    # 循环轴“坎 R↓”，视频 43.9-47.9：入场即放 R，动画结束 47.4 到 ↓ 47.9
    def _action_s2(self, tag, nxt):
        self._cast_r(tag)
        self._outro(tag, 1.0)
        self._trace(tag, 'exit', reason='done', next=nxt)
