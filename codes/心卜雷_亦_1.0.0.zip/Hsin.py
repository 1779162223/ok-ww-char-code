import base64
import ctypes
import threading
import time

import cv2
import numpy as np

from src import text_white_color
from src.char.BaseChar import SwitchPriority, forte_white_color
from src.Labels import Labels
from src.char.Hsin import Hsin as NativeHsin

# ==================== 物理 F 键监视 ====================
# 跟 Iuno__JingRan__ShoreKeeper/JingRan.py 里那份逐字相同。
F_VK = 0x46              # 'F'
F_POLL_INTERVAL = 0.05   # 一次按键按住的时间远大于这个, 不会漏采
F_LOG_DEBOUNCE = 1.0     # 按住不放时别刷日志
F_TASK_NAME = 'FStartCombatTask'


def f_settings(task):
    """读界面上的(开关, F 之后等待秒数)。没装那张卡片就返回默认值(开, 0 秒)。"""
    executor = getattr(task, 'executor', None)
    for group in ('trigger_tasks', 'onetime_tasks'):
        for other in getattr(executor, group, None) or ():
            if type(other).__name__ == F_TASK_NAME:
                try:
                    return bool(other.enabled), float(getattr(other, 'f_start_delay', 0) or 0)
                except Exception:
                    return True, 0.0
    return True, 0.0


# ==================== 自动战斗开关监视 ====================
ENABLE_POLL_INTERVAL = 0.2


def start_enable_watch(task, logger=None):
    """盯 task.enabled 的 False->True 跳变, 把时刻记到 task._ww_task_restarted_at。每个 task 只启一次。"""
    if getattr(task, '_ww_enable_watch_started', False):
        return
    task._ww_enable_watch_started = True
    if not hasattr(task, '_ww_task_restarted_at'):
        task._ww_task_restarted_at = -1

    def watch():
        was_on = None
        while True:
            try:
                now_on = bool(getattr(task, 'enabled', False))
                if was_on is False and now_on:
                    task._ww_task_restarted_at = time.time()
                    if logger:
                        logger.info('auto combat re-enabled -> opener re-armed')
                was_on = now_on
                time.sleep(ENABLE_POLL_INTERVAL)
            except Exception:
                return

    threading.Thread(target=watch, name='ok_ww_enable_watch', daemon=True).start()


def start_f_watch(task, logger=None):
    """把【物理】F 键按下的墙钟时间记到 task._f_last_press。每个 task 只启一次。"""
    if getattr(task, '_f_watch_started', False):
        return
    task._f_watch_started = True
    if not hasattr(task, '_f_last_press'):
        # -1 = 从没按过, 跟 last_opener 的"没跑过"对齐
        task._f_last_press = -1

    def watch():
        try:
            user32 = ctypes.windll.user32
            user32.GetAsyncKeyState.restype = ctypes.c_short
        except Exception as e:
            task._f_watch_started = False
            if logger:
                logger.error(f'f watch: GetAsyncKeyState unavailable ({e}), '
                             f'the "press F to re-arm the opener" shortcut stays off')
            return
        last_log = 0
        was_down = False
        while True:
            try:
                down = bool(user32.GetAsyncKeyState(F_VK) & 0x8000)
                if down and not was_down and f_settings(task)[0]:
                    now = time.time()
                    # 宏正在跑 = 正在战斗, 这下 F 是玩家手动处决, 不是重开副本
                    if (getattr(task, '_three_fire_macro_busy', False)
                            or getattr(task, '_ww_macro_busy', False)):
                        if logger and now - last_log >= F_LOG_DEBOUNCE:
                            last_log = now
                            logger.info('physical F pressed while the macro is running '
                                        '(manual execution) - opener NOT re-armed')
                        was_down = down
                        time.sleep(F_POLL_INTERVAL)
                        continue
                    task._f_last_press = now
                    task._f_pressed_at = now
                    if logger and now - last_log >= F_LOG_DEBOUNCE:
                        last_log = now
                        logger.info('physical F pressed, opener re-armed')
                was_down = down
                time.sleep(F_POLL_INTERVAL)
            except Exception:
                return

    threading.Thread(target=watch, name='ok_ww_f_watch', daemon=True).start()


# ==================== SendInput 左键(心的两段长按用) ====================
_INPUT_MOUSE = 0
_MOUSEEVENTF_LEFTDOWN = 0x0002
_MOUSEEVENTF_LEFTUP = 0x0004


class _KEYBDINPUT(ctypes.Structure):
    _fields_ = [('wVk', ctypes.c_ushort), ('wScan', ctypes.c_ushort), ('dwFlags', ctypes.c_ulong),
                ('time', ctypes.c_ulong), ('dwExtraInfo', ctypes.c_size_t)]


class _MOUSEINPUT(ctypes.Structure):
    _fields_ = [('dx', ctypes.c_long), ('dy', ctypes.c_long), ('mouseData', ctypes.c_ulong),
                ('dwFlags', ctypes.c_ulong), ('time', ctypes.c_ulong), ('dwExtraInfo', ctypes.c_size_t)]


class _HARDWAREINPUT(ctypes.Structure):
    _fields_ = [('uMsg', ctypes.c_ulong), ('wParamH', ctypes.c_ushort), ('wParamL', ctypes.c_ushort)]


class _INPUTUNION(ctypes.Union):
    _fields_ = [('ki', _KEYBDINPUT), ('mi', _MOUSEINPUT), ('hi', _HARDWAREINPUT)]


class _INPUT(ctypes.Structure):
    _fields_ = [('type', ctypes.c_ulong), ('u', _INPUTUNION)]


def send_input_left(up):
    """系统级左键按下/抬起。返回是否发出去了(发不出去调用方退回 PostMessage)。"""
    try:
        inp = _INPUT(type=_INPUT_MOUSE)
        inp.u.mi = _MOUSEINPUT(0, 0, 0, _MOUSEEVENTF_LEFTUP if up else _MOUSEEVENTF_LEFTDOWN, 0, 0)
        return ctypes.windll.user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(_INPUT)) == 1
    except Exception:
        return False


class MacroBroken(Exception):
    """某一步切人没成功 / HUD 长时间不在, 后面的按键会落在错的人身上 —— 整圈放弃, 交回框架。"""


class Hsin(NativeHsin):
    """心。心雷卜(心/雷主·导电/卜灵)里她兼任【整条轴的持宏者】, 三个人的 do_perform 都转到 drive()。

    ================= 轴的出处 =================
    玩家文字轴(2026-10-08)。骨架跟心雷穗同构, 穗穗换成卜灵, 雷主按新轴重排。
    启动轴: 雷a1 | 卜a1a2ea跳a | 雷(空中切进来)落地aa | 卜zz | 雷a1a2a3 | 卜qr
            | 变奏雷qre下落a强e | 变奏心 a1zqr a1ee a1a2a3处决/闪 a1a2zr
    循环轴: 卜a1a2ea跳a | 雷(空中切进来)落地aa | 卜zz | 雷a1a2a3 | 卜qr
            | 变奏雷qre下落a强e | 变奏心 a1zqr a1ee a1a2a3处决/闪 a1a2zr
    【启动轴比循环轴多最前面那一格「雷a1」】: 只打一下平a, 不按 E。
    代码【按角色切人】, 编队随意。雷主在框架里就是 Rover(漂泊者·导电)。【心要用共鸣模态·电磁】。

    ================= 卜灵两格 =================
    第一格 卜a1a2ea跳a: 攒 4 枚卦象(a2 艮 + e 震 + e后秒接的a4 震 + 跳a 震)。
                        【跳a 结束时人在空中】—— 雷主就从空中切进来打下落, 所以这一格末尾不能等落地。
    第二格 卜zz: 第一次重击 艮+震 -> 少阳(黄), 第二次 震+震 -> 少阴(蓝)。
                 【卦象不足 2 枚硬按重击会卜卦失败, 扣 20% 生命值】—— 按之前要够。
                 然后 q(声骸) -> r(大招) -> 阴阳齐 -> 强化大招 -> 五雷阵立即铺开 24s。

    ================= 雷主三格 =================
    1. 【仅启动轴】a1: 只打一下平a, 不按 E。
    2. 空中切进来 -> 落地 aa: 卜灵跳a 时切人, 落地打平a。【不按 E】。
    3. 变奏进来 q r e 下落a 强e: Q(声骸) -> R(大招) -> E(雷引) -> 空中A(下落) -> 强E(超负荷)。

    ================= 2026-10-08 实机日志修的三件事 =================
    【1】崩溃: run_cycle 里写了 self.LEI2_A_EVERY, 但那个常量在重写时被 LEI2_AIR_TAP_EVERY 取代了
         -> AttributeError, 宏当场停(用户看到的"雷主罚站")。已修。
    【2】切人撞大招演出: 卜灵 R 演出期间 HUD 被盖住, seg_bl2 末尾却立刻切人 ->
         日志里 >RovFAIL@15.80 trace 全是 x(2.5s 读不到 HUD) -> switch_retry 重试才成功。
         每圈白花 2 秒多。现在【切人之前先等 HUD 回来】(switch_after_anim)。
    【3】lei_wait_ready 白等 6.09s: 用户实机上雷主进场前能量就满了、强化E 提前放了,
         框的显示状态跟预期不符, 白等满 6.5s 上限。现在【先读 CD】: E 已经在 CD(>=12s)
         说明超负荷已就绪, 直接跳过等待。用户: "提前放就放了, 但我不希望卡住"。
    【4】跳a 落地才打(2026-10-08 实机): bl_wait_air 空等满 1.2s 才点那一下, 人早落地了 ——
         "跳起来没接a, 落地以后才a", 还少一枚「震」。现在【跳完 0.05s 立刻点】, 不查 flying(),
         并且【跳之前就把读数打完】, 跳完立刻切雷主(趁还在空中, 他才有下落)。
    【5】卦象不足硬按重击被电(2026-10-08 实机): 日志里重击2前只剩 1 枚卦象, 还是"照按" ->
         卜卦失败扣 20% 血。现在改成【读游戏自己的提示】: 右下角鼠标图标的左键亮 = 能按,
         不亮 = 卦象不够 -> 跳过(跳过只是少少阳/少阴, 按下去是白扣血); 只有读屏真的坏了才盲按。
    【6】那 3.7 秒"无意义的平a"(2026-10-08 实机): seg_bl3 里原本有个"大招前协奏不够就点平a补",
         实测 18 下平a 只把协奏从 0.51 推到 0.62, 纯浪费。用户文字轴里 卜qr 就是 q 然后 r,
         【没有平a】, 所以删掉了, 现在只读一次记日志。
    【7】切人不看图像确认了(用户 2026-10-08: "卜灵zz后不切人……只要没被打断在一个差不多的时间后
         强制切人, 背景太乱了感觉图像抓取不太灵敏")。日志证据:
             switch to Rover slot 2 timed out after 3.0s
             trace: 0.11:2 0.17:2 ... 2.34:2     <- HUD 从头到尾同一个 index, 按 3 秒也没"读到"
         所以卜灵切走这件事改成 switch_or_force: 先正常切, 失败【不抛 MacroBroken】(抛了整圈重来,
         重开时人还在卜灵身上 -> 又攒卦又重击 -> 卦象不够被电), 而是【按时间强切】后继续。
    【8】锁不到敌就停手(用户 2026-10-08: "能不能再加一个锁不到敌就自动停止的机制, 不然我打完怪后
         角色还在一直a")。原因: macro_enter 把 task.skip_combat_check 设成了 True, 框架那套战斗
         检查被关掉了。现在自己补一个: macro_mark 里定期调框架的 check_combat(), 判到脱战就整圈放弃。
     【9】战斗中断 -> 轴重新开始(用户 2026-10-09: "能不能加一个战斗中断轴就重新开始, 比如说我刷本
          点了右上角退出重新开始这类的")。原设计是"一场战斗只跑一次启动轴"; 中途退出副本/过场/
          长时间脱战之后再进战斗, 人是从半截状态接上的, 循环轴第一格对不上。现在见
          maybe_rearm_after_interrupt(): HUD 断档 >= REARM_HUD_GONE 或 离上一圈 >= REARM_IDLE_GAP
          就自动把启动轴重新武装(连 OPENER_MIN_GAP 的 60s 防重入一起清掉), 下一场从雷主起手重跑。

    ================= 判据(2026-10-08 截图逐像素采样) =================
    - 卜灵卦象: 【黄 = 艮, 蓝 = 震】; 重击转化后【黄 = 少阳, 蓝 = 少阴】(用户确认)。
      【上下两种黄不是一个色】: 卦象黄 H≈17(偏橙), 少阳黄 H≈23(偏金), 分开写。
      卦象居中排列, 数量变时位置会动 —— 扫条带按列分段数, 不写死单个坐标。
    - 雷主: 电涌满 = 回路条右边两个 [E] 小框亮(lei_ready_white); 超负荷 = E 进 CD 且 CD > 12s;
            在空中 = 【E 图标】整个变灰(lei_e_white)。
    - 心: 应世心满 = hsin_h1(花) / 转相解锁 = 步红尘清空 + 2.06s / 万阙垂天 = hsin_lib2。

    ================= 改这个文件之前先读 =================
    - 引擎(macro_* / quick_switch / fire_r / wait_hud_back ...)逐字抄自心雷穗定稿, 没改。
    - 【自定义 __init__ 里跟内置版不同的字段会被打回内置值】, 要保住就在 reset_state() 里重申。
    - 普攻一律走 tap()(按住 A_TAP 秒): task.click() 只按 10ms, 打不出来。
    - 长按期间不调 click()/mouse_down()/send_key() —— 它们先投 WM_ACTIVATE, 会把按住打断。
    """

    # ==================== 全局节奏(引擎用) ====================
    A_INTERVAL = 0.12
    KEY_INTERVAL = 0.10
    A_TAP = 0.06                 # 普攻按住这么久才算一下; task.click() 的 10ms 会被吞

    # ---- 切人 ----
    SWITCH_TIME_OUT = 2.5
    SWITCH_KEY_DOWN_TIME = 0.02
    SWITCH_KEY_INTERVAL = 0.0
    UNTRUSTED_CONFIRM = 3
    TRACE_SWITCH = True
    # 【切人前等演出结束】: 卜灵 R 演出期间 HUD 被盖住, 这时切人必然超时(2026-10-08 日志)。
    SWITCH_AFTER_ANIM_CAP = 3.00   # 切人前等 HUD 回来的上限; 到了照切(不能无限等)
    # ---- 强切(不看图像确认) ----
    # 【用户 2026-10-08】: "卜灵zz后不切人……只要没被打断在一个差不多的时间后强制切人,
    # 背景太乱了感觉图像抓取不太灵敏"。日志: "switch to Rover slot 2 timed out after 3.0s,
    # trace: 0.11:2 ... 2.34:2" —— HUD 从头到尾同一个 index, 按 3 秒数字键也没"读到"切过去。
    FORCE_SWITCH_WAIT = 0.90       # 强切: 发键之后等这么久(够游戏过完切人动画/锁定)
    FORCE_SWITCH_RESEND = 0.10     # 期间每隔这么久再发一次键
    # ---- 战斗判定结束时强制切雷主 ----
    # 【用户 2026-10-08】: "现在其他不变，在战斗判定结束时强制切到雷主"。
    # 【只挂两处, 都不在循环里】: (1) macro_mark 里"锁不到敌"看门狗判到脱战那一刻;
    # (2) 框架的 on_combat_end。循环轴每圈末尾要切的是卜灵(下一圈从卜1开始), 放循环里会把轴打断。
    LEI_MAIN_ON_COMBAT_END = True
    LEI_MAIN_WAIT = 1.20           # 强切发键的时长。脱战那一下游戏可能还在收招, 比平时的 0.90 长一点
    # ---- 锁敌监视 ----
    # 【用户 2026-10-08】: "能不能再加一个锁不到敌就自动停止的机制, 不然我打完怪后角色还在一直a"。
    # 因为 macro_enter 把 task.skip_combat_check 设成了 True, 框架那套战斗检查被关掉了,
    # 所以这里自己定期调框架的 check_combat() 补一刀。
    COMBAT_POLL = 0.60             # 每隔这么久查一次(查太勤会拖慢每一步)
    COMBAT_GONE_CONFIRM = 2        # 连读这么多回才算真脱战(防抖动)

    # ---- 大招 / 演出 ----
    LIB_KEY_INTERVAL = 0.03
    LIB_ANIM_TIME_OUT = 8.0
    HUD_NO_ANIM_GRACE = 0.35
    LIB_GONE_CONFIRM = 3         # HUD 连续这么多帧不在 = 演出真的开始了
    HUD_UP_CAP = 1.0             # 按 R 之前等 HUD 在场的上限(防假成功)
    HUD_BACK_CONFIRM = 2         # 演出中途 HUD 会闪一两帧, 回来要连读这么多帧

    # ---- 杂项 ----
    CON_SAMPLE_MAX = 24
    FIELD_SETTLE_TIME_OUT = 1.5
    E_RESEND_STEP = 0.06
    SKILL_BAR_SETTLE = 0.40      # 刚切进来多久没见过技能亮就当它在 CD 上
    M_E_KEY_DOWN = 0.05
    CON_ENOUGH = 1.0
    CON_FULL_CONFIRM = 3
    CON_POLL = 0.03

    # ==================== 防重入 ====================
    OPENER_MIN_GAP = 60.0

    # ---- 战斗中断 -> 轴重新开始 ----
    # 【用户 2026-10-09】: "能不能加一个战斗中断轴就重新开始, 比如说我刷本点了右上角退出重新开始
    # 这类的"。原设计是"一场战斗只跑一次启动轴"(跑完 opener_armed 就置 False, 之后全是循环轴),
    # 一旦中途退出副本/过场/长时间脱战, 人是"半截状态"进来的, 循环轴的第一格对不上。
    # 命中下面任一信号就自动重新武装启动轴, 并把 last_opener 清掉(那是 OPENER_MIN_GAP 的 60s
    # 防重入计时, 不清的话就算重新武装了也跑不了启动轴):
    #   (1) 队伍 HUD 刚断过 >= REARM_HUD_GONE 秒 = 过场/结算/退出重开/窗口没了
    #   (2) 离上一圈交回框架 >= REARM_IDLE_GAP 秒 = 重开副本的读条+跑图时间
    # 【不想自动重开就把 REARM_ON_INTERRUPT 改成 False】
    REARM_ON_INTERRUPT = True
    REARM_HUD_GONE = 3.0           # HUD 断这么久就算"中断过"
    REARM_IDLE_GAP = 8.0           # 离上一圈这么久(同一场战斗里波次间歇只要 1~3s, 不会误判)

    # ==================== 保底 ====================
    SWITCH_RETRIES = 2
    SWITCH_RETRY_TIME_OUT = 3.00
    HUD_LOST_ABORT = 12.00       # 队伍 HUD 连续这么久没见过 = 关卡结束/过场/窗口没了, 整圈放弃
                                 # (穗穗那版是 9.0; 卜灵 R + 切人重试会连着两段没 HUD, 放宽一点)
    DRIVE_HUD_CAP = 1.50         # 框架调进来时 HUD 这么久都不在就什么都不做
    R_TRIES = 3
    R_BLIND_EVERY = 3
    R_BLIND_WINDOW = 0.40
    R_BUILD_SLICE = 0.60

    # ==================== 卜灵(卦象 / 重击) ====================
    # ---- 卦象带(4K, hcenter)。2026-10-08 截图实测 2560x1440 ×1.5 ----
    # 四个图标(1440p): 黄艮 x1110~1160 / 蓝震 x1200~1250, 1290~1340, 1375~1425; y 1180~1230
    # 间距 ≈90(1440p)=135(4K)。整带 1440p x1100~1440 y1175~1235 -> 4K 如下。
    BL_GUA_BAND = (1650, 1763, 2160, 1853)
    BL_GUA_GAP = 0.05
    BL_GUA_MIN_COLS = 5
    BL_GUA_PIX_MIN = 0.03
    # 【实际采样的色相】: 黄 p10=14 med=17 p90=19; 蓝 p10=106 med=108~112 p90=115
    BL_GUA_HUE_YELLOW = (9, 25)      # 艮(偏橙)
    BL_GUA_HUE_BLUE = (100, 122)     # 震
    BL_GUA_SAT_MIN = 95
    BL_GUA_VAL_MIN = 110
    # 【判据不用"数图标", 用"带头亮不亮"】(2026-10-08 实机): 按列分段数图标数不准 ——
    # 同一状态下三次读数分别是 艮1震0 / 艮2震2 / 艮1震1。
    # 【而且"刚切回卜灵"那一下读数一定是低的】: 回路条刚切过来、图标还在渐显 ——
    #   接a4后(在场站了2秒) 黄 = 0.1158 0.0932 0.0420 0.0828
    #   重击1前(刚切回来)   黄 = 0.0133 0.0285 0.0188 0.0000
    # 所以 1) 进这一格先等 BL2_ENTER_SETTLE 让 UI 渲染完; 2) 阈值压到很低,
    # 只在【明确什么都没有】时才跳过, 免得把好好的重击跳掉。
    BL_GUA_SHARE_MIN = 0.02

    # ---- 重击就绪提示(右下角鼠标图标的左键高亮)【用户 2026-10-08 给的判据】----
    # 卦象够的时候, 右下角那个【鼠标图标的左键会亮】: 亮黄 = 少阳(艮+震), 亮蓝 = 少阴(震+震),
    # 不亮 = 卦象不够(按了就是卜卦失败, 扣 20% 血)。这是游戏自己算好的, 比数卦象发光团靠谱得多。
    #
    # 【量怎么选的】: 不能按"黄/蓝"判 —— 图2(无卦象)那一小块背景是亮蓝城市, 蓝占比 100%, 全被污染。
    # 用"又亮又饱和"的像素占比(OpenCV: V>=204 且 S>=140), 四张实拍截图实测:
    #   b676(4卦象,该亮) 2.00%    fig1(艮+震,该亮) 2.29%
    #   c6b6(打完zz,该不亮) 0.00%  fig2(无卦象,该不亮) 0.00%
    # 亮/不亮分得干干净净, 而且黄、蓝两种高亮都算数。
    BL_HEAVY_BOX = (2691, 1983, 2745, 2029)   # 4K hcenter (1440p: 1794,1322,1830,1353)
    BL_HEAVY_MIN = 0.006        # 亮 >= 1.21% / 不亮 = 0.00%, 取 0.6%
    BL_HEAVY_VAL_MIN = 204      # OpenCV V(0-255), 相当于 0.80
    BL_HEAVY_SAT_MIN = 140      # OpenCV S(0-255), 相当于 0.55

    # ---- 阴阳条(4K): 回路条本体分左右两半, 左黄 = 少阳, 右蓝 = 少阴 ----
    # 1440p: 左半 x1085~1245 / 右半 x1290~1450, y 1290~1355
    BL_YY_L = (1628, 1935, 1868, 2033)
    BL_YY_R = (1935, 1935, 2175, 2033)
    # 【少阳的黄跟卦象的黄不是一个色】: 采样 H p10=21 med=23 p90=25(更偏金)
    BL_YY_HUE_YELLOW = (18, 30)
    BL_YY_SAT_MIN = 85
    BL_YY_VAL_MIN = 120
    BL_YY_PIX_MIN = 0.10

    # ---- 第一格: a1a2 攒「艮」-> e -> e后秒接 a4 -> 跳a -> 【人在空中, 直接切雷主】----
    BL1_A_BEFORE_E = 1.20
    BL1_A_AFTER_E = 1.00
    BL1_E_TIME_OUT = 0.50
    BL1_E_SETTLE = 0.20
    # 【跳之后立刻点这一下, 不能等 flying()】: 2026-10-08 实机日志 ——
    #   op卜1跳a(没读到离地, 照点)@5.81
    # 意思是 bl_wait_air 空等满了 1.2s 上限才点, 那时人已经落地, 于是变成
    # "跳起来没接a, 落地以后才a"。照内置 Douling._do_segment2 的形状: jump -> 很短一停 -> 立刻 click。
    BL1_AIR_TAP_DELAY = 0.05
    BL1_AIR_TAP_GAP = 0.05
    BL1_CYCLE_SLEEP = 0.10
    BL1_TO_AIR_CAP = 1.20
    BL_WAIT_DOWN_CAP = 2.00

    # ---- 第三格: zz(一次少阳 + 一次少阴) ----
    BL2_HOLD = 2.50
    # 【不要重按】(2026-10-08 实机): 内置 _heavy_attack_hold 被打断(离地)会把整套长按【重来一遍】,
    # 每重来一次就是【又按了一下重击、又吃掉 2 枚卦象】—— 这里两次重击一共只有 4 枚,
    # 多按那一下就让第二次没卦象 -> 卜卦失败被电。所以这里只按一次, 被打断就认了。
    BL2_HOLD_RETRIES = 1
    BL2_HOLD_POLL = 0.10
    BL2_HOLD_SETTLE = 0.01
    BL2_HOLD_GAP = 0.35          # 【要标定】两次重击之间的缝
    # 【重击完先等动作走完再切人】(2026-10-08 实机): 长按松手后角色还在重击动画里,
    # 这时按数字键会被吃掉 —— 日志里 >RovFAIL(切雷主超时)就是这么来的。切人失败会整圈重来,
    # 重开时人还在卜灵身上 -> 跳过切人直接攒卦平a -> 又去重击 -> 卦象不够被电。
    BL2_LEAVE_SETTLE = 0.55
    BL2_GUA_MIN = 2
    BL2_FILL_CAP = 2.50          # 【已不用】留个名
    # 【提示没亮时补卦象】(用户 2026-10-08 第二次反馈): 日志实测 —— 重击1 前提示亮(yang),
    # 打完重击1 后重击2 前提示就没亮了(第一格只攒到 2 枚), 于是只出少阳没有少阴、五雷阵也没了。
    # 所以提示没亮时点几下平a(普攻第2段给艮、第4段给震), 【一亮就停手按重击】。
    # 【长按到"提示灭"就松手】(用户 2026-10-08 说"很短时间内把两段重击都打出去"):
    # 一次长按里游戏自己会连着打完两段, 打完卦象就没了 -> 右下角那个鼠标提示会【灭】。
    # 所以可以不等满 BL2_HOLD, 提示一灭就松手。默认【关】—— 动画期间技能栏有可能整个变暗,
    # 那会被误当成"打完了"而提前松手(只出一段)。想更快就把它打开, 并把 MIN 调大一点。
    BL2_HOLD_EARLY_DARK = False   # True = 提示灭就提前松手
    BL2_HOLD_DARK_MIN = 0.80      # 至少先按这么久才允许提前松手(防动画把界面压暗误判)
    BL2_HOLD_DARK_EVERY = 0.20    # 每隔这么久读一次提示(读太勤会拖慢)
    BL2_HOLD_DARK_CONFIRM = 2     # 提示连续灭这么多回才算真打完
    BL2_TOPUP_CAP = 1.60         # 最多补这么久, 到了还亮不了就跳过
    BL2_TOPUP_EVERY = 0.20       # 每点一下之间隔这么久, 给卦象图标更新的时间
    BL2_JUMP_SETTLE = 0.01
    # 【切进卜灵后先等 UI 渲染】(2026-10-08 实机): 回路条刚切过来, 卦象图标还在渐显,
    # 这时读卦象一定读成"没有"(黄 0.0000~0.0285; 而在场站 2 秒后是 0.0420~0.1158)。
    # 等一下再读、再按重击, 免得把本来就够的卦象判成不够。
    BL2_ENTER_SETTLE = 0.40

    # ---- 第四格: q -> r(五雷阵立即铺开) -> 协奏满 -> 变奏雷主 ----
    BL2_ECHO_TIME_OUT = 0.0
    BL_R_WINDOW = 1.50
    BL_R_CAP = 5.00
    BL_R_ANIM_MIN = 3.60
    BL_R_ANIM_CAP = 7.00
    BL_R_CON_MIN = 0.82
    BL_R_CON_CAP = 4.00

    # ==================== 雷主(漂泊者·导电, 框架类名 Rover) ====================
    # ---- 起手格(【仅启动轴】): a1, 只打一下平a, 不按 E ----
    LEI0_A = 0.15

    # ---- 第二格: 卜灵跳a 时【空中】切进来 -> 下落 -> a1a2a3 -> 切卜灵 ----
    # 【不按 E】: 人已经在空中了, 不需要雷引拉人。
    # 【落地判据】: 读 E 图标 白 -> 灰(空中) -> 白(落地)。框名未知, 读不到就按时间走。
    LEI1_E_BOX = None
    LEI1_E_BOX_NAME = 'box_resonance'   # 【要标定】我猜的名字, 读不到不影响流程
    LEI1_ECHO_WHITE = 0.04
    LEI1_ECHO_CONFIRM = 2
    # 【这一格的时长】: 下落窗口 + a1a2a3 一小段, 然后立刻切卜灵。
    # E 图标判据基本读不出来(日志里全是"读不出"), 所以一般是刷满 LEI1_AIR_WINDOW 才走。
    # 想让它更快/更稳就调这两个数: 太小下落打不全, 太大就是白站。
    LEI1_AIR_WINDOW = 1.20       # 【硬上限】下落阶段最长时间(读不到落地时按它走)
    LEI1_A_AFTER_LAND = 0.50     # 落地后 a1a2a3 的时长
    LEI1_A_EVERY = 0.15
    LEI1_SWITCH_TIME_OUT = 3.00

    # ---- 第三格: 普通切进来, 只打 a1a2a3 -> 切卜灵 ----
    LEI2_A3_WINDOW = 1.00
    LEI2_A_EVERY = 0.15

    # ---- 第四格(变奏进来): q r e 下落a 强e -> 变奏心 ----
    LEI3_Q_AT = 0.35
    LEI3_Q_WINDOW = 0.15
    LEI3_R_WINDOW = 3.50
    LEI3_R_CAP = 6.00
    LEI3_R_ANIM_MIN = 2.80
    LEI3_R_ANIM_CAP = 6.50
    LEI3_E_CAP = 1.20
    LEI3_AIR_CAP = 2.00          # 【硬上限】下落阶段
    LEI3_AIR_TAP_EVERY = 0.15
    LEI3_READY_CAP = 2.50
    LEI_READY_BOX = (2251, 1993, 2311, 2016)
    LEI_READY_MIN = 0.03
    LEI_READY_MAX = 0.70
    LEI_READY_CONFIRM = 2
    # 【能量满了就不等】: 2026-10-08 日志里 lei_wait_ready 白等 6.09s —— 用户实机是进场前能量就满、
    # 强化E 提前放了。先读 CD: E 已在 CD(超负荷 25s) 就跳过。用户: "提前放就放了, 但我不希望卡住"。
    LEI_SKIP_WAIT_CD = 12.0
    # 【保底用】(用户 2026-10-08): 等电涌期间每隔这么久重读一次 E 的 CD ——
    # 强化E(超负荷)真打出去了的话 E 的 CD 会跳到 25s(雷引只有 10s), 一眼能认出来, 不用干等电涌指示。
    LEI_CD_POLL = 0.30
    LEI_E_CAP = 1.00
    LEI_E_CD_MIN = 12.0          # 超负荷 CD 25s, 雷引 10s
    LEI_E_TRIES = 2
    LEI_E_RETRY_A = 2.50
    LEI_CON_CAP = 3.00
    # ==================== 心 ====================
    XN_GAUGE_L = (1627, 1999, 1837, 2011)
    XN_GAUGE_R = (1965, 1999, 2175, 2011)
    XN_GAUGE_VALID = 0.50
    XN_YING_READY = 0.70
    XN_CONSUMED = 0.15
    XN_FULL_THRESHOLD = 0.70
    XN_HOLD_SENDINPUT = True

    XN1_Q_AT = 0.30
    XN1_Q_WINDOW = 0.15
    XN_FORM_CAP = 0.40
    XN_FORM_READS = 4
    XN1_A_FROM = 0.45
    XN1_A_EVERY = 0.17
    XN1_A_HOLD = 0.08
    XN1_GATE_CONFIRM = 2
    XN1_HOLD_AT_MIN = 1.90
    XN1_A_CAP = 4.50
    XN1_LAST_A_GAP = 0.12
    XN1_HOLD = 1.80
    XN1_RETRIES = 2
    XN1_RETRY_A = 2
    XN1_FILL_EVERY = 0.40
    XN1_R1_UNLOCK = 2.06
    XN1_R1_POLL_FROM = 1.85
    XN1_R1_MARGIN = 0.08
    XN1_R1_LIT_CAP = 3.00
    XN1_R1_READS = 2
    XN1_R1_BLIND_AT = 2.60
    XN_R_WINDOW = 1.50
    XN1_R1_RESCUE_CAP = 8.00
    XN1_R1_RESCUE_A = 0.80
    XN1_R1_LOST_ROUNDS = 3
    XN_R_ANIM_MIN = 3.90
    XN_R_ANIM_CAP = 8.00

    XN2_A_EVERY = 0.15
    XN2_3A = 1.55
    XN2_2A = 0.85
    XN2_E_FULL = 1.45
    XN2_E1_CAP = 1.20
    XN2_E_MASH = 0.15
    XN2_LIANHENG_CAP = 3.00
    XN2_LIANHENG_POKE_AT = 1.80
    XN2_LIANHENG_A_EVERY = 0.20
    XN2_RESCUE_CAP = 3.00
    XN2_RESCUE_A = 0.80
    XN2_RESCUE_E = 0.80
    XN2_TY_CONFIRM = 2
    XN_TY_MIN = 0.60
    XN_TY_GLYPH = (
        'AAAAAAAMJCEsJBYBAAAAAAAAABiR1cJ40tzbpyYAAAAAABK+4+Pt2unk48BaJAAAAAhQg6aMnN1/l6RzUVEbAAAzV3Dw9crHyvngXlFQRQIJ'
        'VFqs8dbtovLV8JdRUFAdIlmK7ZPT7IT7v6Dtbk9bOzdhj5en/O2E/PmHoXdelTpIsV1Xrv3thPz7iE9XwJuUJsCvW6797YX9+4dTsfjxriWy'
        '9KGQ++2E/fqGnvfU33sBpvjsmt/thPzfmeylk9cPADOnpLzM7IT4tc54Y+FhAAAASGKt+eyD5uiKUbyiBQAAAAAkjf3tg/j6h3aCCQAAAAAA'
        'AAZbpFvGrUwKAAAAAA=='
    )
    XN_TY_SLOT = (2826, 1893, 82, 79)
    XN_READY_MIN = 0.80
    XN_READY_GLYPH = (
        'AAAAAAAGGDxjHgwAAAAAAAAAABQoWcH31Vg3Jg0AAAAAACGmh+r9+X82NzlcMgAAAAZ47tD9/c06R2NGZ2cWAAA32P38/f2+N0xtaDY3MQIa'
        '3/v9/v3x4DhNbFk2OEcVYf39/f34yMM4RGJWQjmCKmH9+vW6sa2FPT09WGFLyjZ5/c7E4fWaQD0/UHOX0POeYfmXotjqXz09PkBvmojMUTfc'
        'vZnUhD08PDw9mcfbvzMBauG+pJZJREA9P9L05XAFACb1+/38refMZD3D+oQjAAAAbfn9/tDY/LQ7tOMxAgAAAABU2f7is/y+QMd0AgAAAAAA'
        'AAhcpG3GgygPAAAAAA=='
    )
    XN2_READY_CONFIRM = 2
    XN2_TY_A_EVERY = 0.18
    XN2_TY_DODGE_COUNT = 4
    XN2_TY_DODGE_MIN = 2.50
    XN2_TY_DODGE_CAP = 5.00
    XN2_TY_PROMPT_KEEP = 3.00
    XN_STATUE_XS = (1647, 1719, 1794, 1866, 1938, 2013, 2085, 2160)
    XN_STATUE_Y = 1980
    XN_STATUE_UP_Y = 1953
    XN_STATUE_HW = 9
    XN_STATUE_RED = 0.08
    XN_STATUE_GLOW = 0.30
    XN_STATUE_CONFIRM = 2
    XN2_DODGE_HOLD = 0.07
    XN2_DODGE_TO_A = 0.12
    XN2_TY_CAP = 10.0
    XN2_HOLD_CAP = 1.20
    XN2_BLIND_HOLD = 2.00
    XN2_RELEASE_AFTER_GONE = 0.30
    XN2_RETRIES = 2
    XN2_RETRY_CAP = 3.00
    XN2_ANIM_MIN = 1.40
    XN2_ANIM_CAP = 4.00
    # 【万阙垂天: 图标没出来就平a补能量】(用户 2026-10-08):
    # "心最后一段大招能量老是差一点放不出来, 能不能加点保底机制, 放不出来就平a补能量"。
    # 这里原来只是干等 1.5s 什么都不做, 所以能量差一点就整轮放弃。现在一边点平a攒共鸣能量
    # 一边读图标, 图标(万阙垂天解锁)一亮立刻停手去按 R。上限到了还不亮就不按(按了会放成借相)。
    XN2_LIB2_CAP = 4.00          # 原来是 1.50 —— 太短, 补能量根本来不及
    XN2_LIB2_POKE = 0.25         # 补能量时两下平a之间隔这么久, 给图标刷新的时间
    XN2_LIB2_READS = 2
    XN2_PRE_R2_CON = 0.80
    XN2_PRE_R2_CAP = 2.00
    XN2_CON_CAP = 3.00
    XN_BREAK = True
    XN_BREAK_FROM = 0.80
    XN_BREAK_CONFIRM = 2
    XN_BREAK_PRESSES = 3
    XN_BREAK_ANIM = 1.40
    XN_BREAK_CENTER_MIN = 0.90

    # ==================== 宏状态 ====================

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.opener_armed = True
        self.last_opener = -1
        self.macro_t0 = 0.0
        self.macro_marks = []
        self.cur = None
        self.holding_attack = False
        self.si_holding = False
        self.switch_press_at = 0.0
        self.lib_press_at = 0.0
        self.loop_count = 0
        self.lei2_t0 = 0.0
        self.lei2_pause = 0.0
        self.xn_broke = False
        self.hud_seen_at = 0.0
        self.hud_watch = False
        self.drive_log_at = 0.0
        self.timeline_logged = True
        self.bl_gua_last = (0, 0)      # 最近一次读到的 (艮, 震), 调试用
        self._gua_ok = False           # 卦象读屏可用吗(False = 读崩了, 只能盲按)
        self.combat_watch = False      # 宏跑着的时候才查锁敌
        self.combat_checked_at = 0.0   # 上次查锁敌的时刻
        self.combat_gone_hits = 0      # 连续判到脱战的次数(要连读 COMBAT_GONE_CONFIRM 回)
        # 【战斗中断 -> 轴重新开始】用的时间戳(见 REARM_* 常量)
        self.last_cycle_end = -1.0     # 上一次整圈(启动/循环)交回框架的时刻
        self.hud_gone_since = 0.0      # HUD 从什么时候开始不在(0 = 现在在场)
        self.hud_outage_last = 0.0     # 刚过去的这次 HUD 断档持续了多久
        # reset_state() 只在 load_chars() 时跑, 而角色对象会被粘性复用 —— 这里也要启一次
        try:
            start_enable_watch(self.task, self.logger)
        except Exception:
            pass

    def reset_state(self):
        super().reset_state()
        self.opener_armed = True
        # 内置非治疗角色默认 True, 换类时会被打回, 所以在这里重申
        self.check_f_on_switch = False
        start_f_watch(self.task, self.logger)
        start_enable_watch(self.task, self.logger)

    # ==================== 队伍判定 ====================
    # 【名字带后缀】(2026-10-08 日志铁证): 框架给雷主的 name 是 "Rover: Spectro"(带谐律属性),
    # 不是裸的 "Rover"。日志: loaded chars success Hsin / Rover: Spectro / Douling。
    # 所以一律用【前缀匹配】: name == base 或 name.startswith(base + ':')。
    # 【上一版就是栽在这】: teammate('Rover') 找不着人 -> macro_enter 返回 None ->
    # perform_opener 直接 return False, 一个日志都不打, 表现就是"不触发战斗"。

    TEAM_BASES = ('Hsin', 'Rover', 'Douling')

    @staticmethod
    def name_is(char, base):
        """char 的 name 是不是 base(允许 'Base: 后缀' 这种带谐律属性的写法)。"""
        name = getattr(char, 'name', None) or ''
        return name == base or name.startswith(base + ':')

    @property
    def is_in_xlb(self) -> bool:
        """本队 = 心 + 雷主(Rover) + 卜灵。按【名字前缀】判, 三个都要在。"""
        found = set()
        for char in self.task.chars:
            if char is None:
                continue
            for base in self.TEAM_BASES:
                if self.name_is(char, base):
                    found.add(base)
        return len(found) == len(self.TEAM_BASES)

    def teammate(self, base):
        """按名字前缀找队友(雷主的 name 带 ': Spectro' 后缀)。找不到返回 None。"""
        for char in self.task.chars:
            if char is not None and self.name_is(char, base):
                return char
        return None

    def opener_pending(self):
        return self.opener_blocked_by() is None

    def opener_blocked_by(self):
        """启动轴不跑的原因; 返回 None 表示该跑。不查任何技能可用性(场下读数是旧的)。"""
        if not self.is_in_xlb:
            return 'team is not hsin/rover/douling'
        if not self.opener_armed:
            restarted = getattr(self.task, '_ww_task_restarted_at', -1)
            if restarted > self.last_opener:
                self.logger.info('auto combat 重开过 — 启动轴重新武装, 从头跑')
                self.opener_armed = True
                return None
            return 'already armed-down (ran once this combat)'
        f_press = getattr(self.task, '_f_last_press', -1)
        if f_press > self.last_opener:
            waited = time.time() - f_press
            delay = f_settings(self.task)[1]
            if waited < delay:
                return f'F pressed {waited:.2f}s ago, waiting {delay:.2f}s for the mobs'
            return None
        if self.last_opener >= 0 and time.time() - self.last_opener < self.OPENER_MIN_GAP:
            return f'ran {time.time() - self.last_opener:.1f}s ago (< {self.OPENER_MIN_GAP:.0f}s)'
        if not self.task.use_liberation:
            return 'task.use_liberation is off'
        return None

    def maybe_rearm_after_interrupt(self):
        """【战斗中断 -> 轴重新开始】(用户 2026-10-09, 见 REARM_* 常量)。

        只在【启动轴不是待跑状态】的时候判(待跑就说明本来就是从头跑, 不用管)。
        命中信号(HUD 刚断很久了 / 离上一圈很久了)就把启动轴重新武装, 并且
        【把 last_opener 清成 -1】—— 那是 OPENER_MIN_GAP(60s)防重入的计时,
        不清的话重新武装了也会被它挡回去, 下一场还是只跑循环轴。
        返回命中的原因(日志/排查用); 没命中返回 ''。
        """
        if not self.REARM_ON_INTERRUPT or self.opener_armed:
            return ''
        now = time.time()
        reason = ''
        if self.hud_outage_last >= self.REARM_HUD_GONE:
            reason = f'HUD 刚断了 {self.hud_outage_last:.1f}s(过场/结算/退出副本?)'
        elif self.last_cycle_end > 0 and now - self.last_cycle_end >= self.REARM_IDLE_GAP:
            reason = f'离上一圈 {now - self.last_cycle_end:.1f}s(重开副本/长时间脱战?)'
        if not reason:
            return ''
        self.opener_armed = True
        self.last_opener = -1
        self.loop_count = 0
        self.logger.info(f'xlb: 战斗中断({reason}) — 启动轴重新武装, 这一场从 op 雷主起手重跑')
        return reason

    # ==================== 宏原语(引擎) ====================
    # 【这一段逐字抄自心雷穗定稿, 一个字没改】

    def macro_wait(self, sec):
        """精确等待, 【不点击】。切成 0.1 秒一片, 片间检查任务是否被停用。"""
        if sec <= 0:
            self.task.executor.check_enabled(check_pause=False)
            return
        end = time.time() + sec
        while True:
            left = end - time.time()
            if left <= 0:
                return
            time.sleep(min(0.1, left))
            self.task.executor.check_enabled(check_pause=False)

    def wait_until_time(self, deadline):
        self.macro_wait(deadline - time.time())

    def macro_start(self):
        self.macro_t0 = time.time()
        self.macro_marks = []

    def macro_mark(self, name):
        self.macro_marks.append(f'{name}@{time.time() - self.macro_t0:.2f}')
        now = time.time()
        # 【看门狗1】HUD 很久没出现 = 关卡结束/过场/窗口没了
        if self.hud_watch and now - self.hud_seen_at > self.HUD_LOST_ABORT:
            self.hud_watch = False
            raise MacroBroken(f'队伍 HUD {now - self.hud_seen_at:.1f}s 没出现(关卡结束/过场/窗口没了?)')
        # 【看门狗2】锁不到敌 = 怪死了/脱战, 停手
        # (用户 2026-10-08: "打完怪后角色还在一直a" —— 因为 skip_combat_check 把框架的检查关了)
        # 【只在队伍 HUD 在场时查】: 大招演出期间 HUD 被盖住、怪也被锁住, 那时判脱战是误判,
        # 会把整圈掐掉。HUD 不在的帧直接跳过, 顺便还喂了 hud_seen_at。
        if self.combat_watch and now - self.combat_checked_at >= self.COMBAT_POLL:
            self.combat_checked_at = now
            if self.hud_ok():
                if self.combat_gone():
                    self.combat_gone_hits += 1
                    if self.combat_gone_hits >= self.COMBAT_GONE_CONFIRM:
                        self.combat_watch = False
                        # 【战斗判定结束 -> 强制切雷主】(用户 2026-10-08)
                        # 放在 raise 之前: 抛出后整圈就交回框架了, 那之后再切就晚了。
                        self.lei_force_main('战斗判定结束')
                        raise MacroBroken('锁不到敌(怪死了/脱战?), 停手')
                else:
                    self.combat_gone_hits = 0

    def hud_ok(self):
        """队伍 HUD 在不在(读当前帧)。见到就记下时刻, 给看门狗和"中断重开"判定用。"""
        ok = bool(self.task.in_team()[0])
        now = time.time()
        if ok:
            if self.hud_gone_since > 0:
                # HUD 刚回来: 记下这次断档有多久(过场/退出副本/结算都靠它认出来)
                self.hud_outage_last = now - self.hud_gone_since
                self.hud_gone_since = 0.0
            self.hud_seen_at = now
        elif self.hud_gone_since <= 0:
            self.hud_gone_since = now
        return ok

    def macro_timeline(self, since=0):
        return ' '.join(self.macro_marks[since:])

    def macro_spam(self, window, interval=None, tag='A'):
        """连点一个窗口。打出几段由 window 决定(动画期间的点击被丢掉, 连点保证总有一下落在动画刚结束时)。"""
        interval = self.A_INTERVAL if interval is None else interval
        start = time.time()
        n = 0
        cap = int(window / max(interval, 0.01)) + 2
        while time.time() - start < window and n < cap:
            self.click()
            n += 1
            remaining = window - (time.time() - start)
            if remaining <= 0:
                break
            self.macro_wait(min(max(0.0, interval - self.A_TAP), remaining))
        self.macro_mark(f'{tag}(x{n})')
        return n

    def spam_key(self, send, window, interval=None, tag='key', poke=None, presses=None,
                 click_interval=None, stop_when=None):
        """在一个窗口里反复发同一个技能键, 用来盖住动画那一段。"""
        interval = self.KEY_INTERVAL if interval is None else interval
        poke = bool(poke)
        click_interval = self.A_INTERVAL if click_interval is None else click_interval
        if presses is not None and presses > 0:
            interval = max(interval, window / presses)
        start = time.time()
        n = 0
        clicks = 0
        next_click = 0.0
        while True:
            send()
            n += 1
            if stop_when is not None and stop_when():
                break
            if presses is not None:
                if n >= presses:
                    break
                left = interval
            else:
                left = window - (time.time() - start)
                if left <= 0:
                    break
            step_end = time.time() + min(interval, left)
            while True:
                now = time.time()
                if now >= step_end:
                    break
                if poke and now >= next_click:
                    self.click()
                    clicks += 1
                    next_click = now + click_interval
                self.macro_wait(min(0.02, step_end - time.time()))
        self.macro_mark(f'{tag}(x{n},A x{clicks})')
        return n

    def game_foreground(self):
        try:
            return bool(self.task.executor.interaction.hwnd_window.is_foreground())
        except Exception:
            return False

    def attack_down(self, direct):
        """按下左键。direct = 走 SendInput(失败自动退回 PostMessage)。返回实际走没走 SendInput。"""
        if direct and send_input_left(False):
            self.si_holding = True
        else:
            direct = False
            self.task.mouse_down()
        self.holding_attack = True
        return direct

    def release_attack(self):
        # 【SendInput 按下的必须 SendInput 松开】: PostMessage 的 mouse_up 只进游戏窗口的消息队列
        if self.si_holding:
            if not send_input_left(True):
                self.logger.warning('SendInput 左键松开没发出去 — 如果左键卡住, 手动点一下')
            self.si_holding = False
            self.holding_attack = False
        elif self.holding_attack:
            self.task.mouse_up()
            self.holding_attack = False

    def tap(self, hold=None):
        """点一下普攻, 【真的按住 hold 秒】。"""
        hold = self.A_TAP if hold is None else hold
        self.task.mouse_down()
        self.holding_attack = True
        try:
            self.macro_wait(hold)
        finally:
            self.task.mouse_up()
            self.holding_attack = False

    def click(self, *args, **kwargs):
        """本队里所有的 self.click() 都改成按住 A_TAP(BaseChar.click 强制 10ms, 等于没点)。不在本队走原版。"""
        if not self.is_in_xlb:
            return super().click(*args, **kwargs)
        self.tap()

    def quick_switch(self, target, click_during=False, time_out=None, read_con=False, assume_con=False):
        """按数字键直切给指定角色(不走 switch_next_char 选人)。"""
        if target is None:
            return False
        if target is self.cur:
            self.macro_mark(f'>{target.name[:3]}(already)')
            return True
        entry = time.time()
        time_out = self.SWITCH_TIME_OUT if time_out is None else time_out
        source = self.cur if self.cur is not None else self
        slot = target.index + 1
        self.switch_press_at = time.time()
        self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
        if assume_con:
            con_full = True
        elif read_con:
            try:
                con_full = float(self.task.get_current_con()) >= 1.0
            except Exception:
                con_full = False
        else:
            con_full = False
        con_cost = time.time() - entry

        start = time.time()
        last = start
        next_click = 0.0
        trace = [] if self.TRACE_SWITCH else None
        team_size = len([c for c in self.task.chars if c is not None])
        untrusted_hits = 0
        clicks = 0
        while time.time() - start < time_out:
            now = time.time()
            if now - last >= self.SWITCH_KEY_INTERVAL:
                self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
                last = now
            if click_during and now >= next_click:
                self.click()
                clicks += 1
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            in_team, index, count = self.task.in_team()
            if in_team:
                self.hud_seen_at = time.time()
            hit = in_team and index == target.index
            trusted = in_team and count >= team_size
            untrusted_hits = untrusted_hits + 1 if (hit and not trusted) else 0
            if trace is not None:
                trace.append(f'{time.time() - start:.2f}:'
                             f'{(index if trusted else f"?{index}") if in_team else "x"}')
            if hit and (trusted or untrusted_hits >= self.UNTRUSTED_CONFIRM):
                self.handoff(source, target, con_full)
                self.macro_mark(f'>{target.name[:3]}{"^" if con_full else ""}'
                                f'({time.time() - entry:.2f}|con{con_cost:.2f}|A x{clicks})')
                if trace and time.time() - entry > 0.4:
                    self.logger.info(f'slow switch trace -> {target.name}: {" ".join(trace)}')
                return True
        self.logger.warning(f'switch to {target.name} slot {slot} timed out '
                            f'after {time_out:.1f}s (stuck in an animation?)'
                            + (f' trace: {" ".join(trace)}' if trace else ''))
        self.macro_mark(f'>{target.name[:3]}FAIL')
        return False

    def handoff(self, from_char, to_char, con_full):
        """复刻 switch_next_char() 尾部那套交接记账。不补的话 get_current_char() 返回 None, 主循环当场崩。"""
        self.task.in_liberation = False
        from_char.switch_out(con_full=con_full)
        to_char.is_current_char = True
        to_char.has_intro = con_full
        to_char.has_sub_dps_intro = con_full and from_char.is_sub_dps
        to_char.last_switch_in_time = time.time()
        if con_full:
            now = time.time()
            self.task.add_freeze_duration(now, to_char.intro_motion_freeze_duration, -100)
            from_char.last_outro_time = now
        self.cur = to_char

    def switch_after_anim(self, target, tag, **kw):
        """【切人之前先等 HUD 回来】。

        2026-10-08 日志: 卜灵 R 演出期间 HUD 被盖住, 紧接着切雷主 -> 2.5s 超时(trace 全 x)
        -> switch_retry 再试一次才成功, 每圈白花 2 秒多。演出刚过 HUD 就回来了, 先等一下再切。

        等不到也照切(有 SWITCH_AFTER_ANIM_CAP 硬上限) —— 绝不能在这卡住。
        """
        self.wait_hud_up(cap=self.SWITCH_AFTER_ANIM_CAP, tag=f'{tag}切人前HUD')
        return self.switch_retry(target, tag, **kw)

    def switch_retry(self, target, tag, **kw):
        """quick_switch, 超时了先等 HUD 回来再切, 最多再试 SWITCH_RETRIES 次。只花时间。"""
        if self.quick_switch(target, **kw):
            return True
        for i in range(self.SWITCH_RETRIES):
            self.wait_hud_up(cap=2.0, tag=f'{tag}重切前HUD')
            self.macro_mark(f'{tag}切{target.name[:3]}重试#{i + 1}')
            kw2 = dict(kw)
            kw2['time_out'] = self.SWITCH_RETRY_TIME_OUT
            if self.quick_switch(target, **kw2):
                return True
        return False

    def lei_force_main(self, tag='战斗结束'):
        """【战斗判定结束时强制切到雷主】(用户 2026-10-08)。

        - 用 force_switch: 发键 -> 等固定时间 -> 走人, 【不看 HUD 确认】。
          脱战那一刻 HUD 往往正在消失, 靠确认必然超时。
        - 先用当前帧看一眼: 人已经在雷主身上就什么都不做(不然白按 1.2 秒)。
        - 【绝不抛异常】: 有一半是从 macro_mark 的看门狗里调的, 抛了会把"停手"那一步吃掉。
        """
        try:
            if not self.LEI_MAIN_ON_COMBAT_END:
                return False
            lei = self.teammate('Rover')
            if lei is None:
                return False
            try:
                in_team, index, _count = self.task.in_team()
                if in_team and index == lei.index:
                    self.cur = lei
                    return True
            except Exception:
                pass
            self.macro_mark(f'{tag}强制切雷主')
            self.logger.info(f'{tag}: 强制切雷主做主控')
            return self.force_switch(lei, tag, wait=self.LEI_MAIN_WAIT)
        except Exception as e:
            self.logger.warning(f'{tag}: 强制切雷主失败 {e}')
            return False

    def force_switch(self, target, tag, wait=None):
        """【不看 HUD 确认】的强切: 发键 -> 等固定时间 -> 走人。

        【用户 2026-10-08 的要求】: "只要没被打断在一个差不多的时间后强制切人, 背景太乱了"。
        实战里 HUD 读数会整段读不出来(日志: trace 全是同一个 index, 按 3 秒数字键也没变),
        靠它确认就会卡死、失败还会让整圈重来。这里改成按时间走。
        切完顺手读一帧核对, 【只记日志, 不影响流程】。
        """
        if target is None:
            return False
        if target is self.cur:
            return True
        slot = target.index + 1
        wait = self.FORCE_SWITCH_WAIT if wait is None else wait
        source = self.cur if self.cur is not None else self
        start = time.time()
        n = 0
        while time.time() - start < wait:
            self.task.send_key(slot, down_time=self.SWITCH_KEY_DOWN_TIME)
            n += 1
            self.macro_wait(self.FORCE_SWITCH_RESEND)
        self.handoff(source, target, False)
        self.macro_mark(f'>{target.name[:3]}强切({time.time() - start:.2f}s,x{n})')
        # 只核对一下, 不据此改变流程
        try:
            self.task.next_frame()
            in_team, index, _count = self.task.in_team()
            if not in_team:
                self.logger.warning(f'{tag}: 强切后读不到队伍 HUD, 后面可能打在错的人身上')
            elif index != target.index:
                self.logger.warning(f'{tag}: 强切后 HUD 显示 index={index}(想要 {target.index}), '
                                    f'后面可能打在错的人身上')
        except Exception:
            pass
        return True

    def switch_or_force(self, target, tag, **kw):
        """先按正常流程切(带 HUD 确认); 失败【不放弃】, 改成按时间强切继续往下走。

        【为什么不抛 MacroBroken】(用户 2026-10-08 的连锁问题): 切人失败抛出去 = 放弃整圈,
        框架下一帧又调进来重开一圈; 重开时人还在卜灵身上 -> seg_bl1 跳过切人直接攒卦平a ->
        又去重击 -> 卦象是上一次的残渣 -> 卜卦失败被电。
        所以这里宁可"强切 + 继续", 也不要整圈重来。
        """
        if self.switch_retry(target, tag, **kw):
            return True
        self.logger.warning(f'{tag}: 正常切 {getattr(target, "name", target)} 没确认成功, '
                            f'改成按时间强切(不让整圈重来)')
        return self.force_switch(target, tag)

    def combat_gone(self):
        """锁不到敌了(= 怪死了 / 脱战)。读不出来一律当"还在打"。

        check_combat() 是框架自己的判据(内置角色都用它)。有的实现是抛异常, 有的返回 False,
        所以两种都认。

        【两道防误伤】(不然会把好好的战斗掐掉):
          1) 框架没这个方法 -> 直接当"还在打", 不判脱战;
          2) 抛异常时, 必须【之前见过一次成功调用】才算脱战 —— 万一 check_combat() 在这套
             环境里根本不能用、每次都抛, 那不能一直说脱战, 否则宏会次次停手。
        """
        if not hasattr(self, 'check_combat'):
            return False
        try:
            r = self.check_combat()
            self._combat_ok_seen = True
            return r is False
        except Exception:
            return bool(getattr(self, '_combat_ok_seen', False))

    def wait_hud_back(self, tag='anim', time_out=None, min_gone=0.0, tail=0.0):
        """等演出结束(队伍 HUD 回来), 【期间一下都不点】。先确认消失过。"""
        time_out = self.LIB_ANIM_TIME_OUT if time_out is None else time_out
        start = time.time()
        gone_at = None
        back_hits = 0
        back = False
        while time.time() - start < time_out:
            self.task.next_frame()
            if not self.hud_ok():
                if gone_at is None:
                    gone_at = time.time()
                back_hits = 0
            elif gone_at is not None:
                if time.time() - gone_at >= min_gone:
                    back_hits += 1
                    if back_hits >= self.HUD_BACK_CONFIRM:
                        back = True
                        break
            elif time.time() - start >= self.HUD_NO_ANIM_GRACE:
                back = True
                break
            self.macro_wait(0.01)
        if gone_at is not None:
            self.add_freeze_duration(gone_at, time.time() - gone_at)
        self.macro_mark(f'{tag}({"ok" if back else "timeout"},'
                        f'{"anim" if gone_at is not None else "NOANIM"},{time.time() - start:.2f}s)')
        self.macro_wait(tail)
        return back

    def wait_hud_up(self, cap=None, tag='HUD'):
        """等队伍 HUD 【现在】在场。按 R 之前用 —— HUD 本来就不在的时候判"演出开始了"是假成功。"""
        cap = self.HUD_UP_CAP if cap is None else cap
        start = time.time()
        while time.time() - start < cap:
            self.task.next_frame()
            if self.hud_ok():
                if time.time() - start > 0.05:
                    self.macro_mark(f'{tag}在场({time.time() - start:.2f}s)')
                return True
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}一直不在({cap:.1f}s)')
        return False

    def watch_hud_gone(self, window, tag, poke_after=None):
        """在 window 里盯队伍 HUD 有没有连续消失(= 演出开始), 消失了立刻返回 True。"""
        start = time.time()
        gone = clicks = 0
        next_click = 0.0
        while time.time() - start < window:
            self.task.next_frame()
            if not self.hud_ok():
                gone += 1
                if gone >= self.LIB_GONE_CONFIRM:
                    self.macro_mark(f'{tag}(出手,{time.time() - start:.2f}s,A x{clicks})')
                    return True
            else:
                gone = 0
                now = time.time()
                if poke_after is not None and now - start >= poke_after and now >= next_click:
                    self.tap()
                    clicks += 1
                    next_click = time.time() + self.A_INTERVAL
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}(没出,A x{clicks})')
        return False

    def on_field_char(self, time_out=None):
        """现在场上是谁 —— 只在拿不到入口角色时才用(开局 HUD 渐入时 in_team() 会说谎)。"""
        time_out = self.FIELD_SETTLE_TIME_OUT if time_out is None else time_out
        expected = len([c for c in self.task.chars if c is not None])
        end = time.time() + time_out
        while True:
            self.task.next_frame()
            in_team, index, count = self.task.in_team()
            if in_team:
                self.hud_seen_at = time.time()
            if in_team and count >= expected:
                for char in self.task.chars:
                    if char is not None and char.index == index:
                        return char
                return None
            if time.time() >= end:
                self.logger.warning(f'team HUD never settled in {time_out:.1f}s '
                                    f'(in_team={in_team} index={index} count={count} '
                                    f'expected={expected}), cannot tell who is on field')
                return None
            self.macro_wait(0.03)

    def mark_busy(self, busy):
        """F 键监视线程靠它区分"战斗中手动处决"和"重开副本"。"""
        self.task._ww_macro_busy = busy
        self.task._three_fire_macro_busy = busy

    def need(self, ok, what):
        if not ok:
            raise MacroBroken(what)

    def press_key_until_cd(self, send, available, cap, tag, ready_grace=0.15, poke=False):
        """一直按某个技能键到它进 CD。返回放出去了没有(本来就在 CD 上返回 False)。

        【先见过"亮"才认"暗"】: 刚切人那几帧技能栏还是上一个人的。
        """
        start = time.time()
        n = live = clicks = 0
        seen_ready = False
        next_click = 0.0
        while time.time() - start < cap:
            self.task.next_frame()
            hud = bool(self.hud_ok())
            if hud:
                if available():
                    seen_ready = True
                elif seen_ready and live > 0:
                    self.macro_mark(f'{tag}_ok(x{n},A x{clicks},{time.time() - start:.2f}s)')
                    return True
                elif not seen_ready and time.time() - start >= ready_grace:
                    self.macro_mark(f'{tag}_没见过亮(x{n},{time.time() - start:.2f}s)')
                    return False
            send()
            n += 1
            if hud:
                live += 1
            step_end = time.time() + self.E_RESEND_STEP
            while True:
                now = time.time()
                if now >= step_end:
                    break
                if poke and now >= next_click:
                    self.click()
                    clicks += 1
                    next_click = now + self.A_INTERVAL
                self.macro_wait(min(0.02, step_end - now))
        self.macro_mark(f'{tag}_CD?(x{n},seen{int(seen_ready)},{cap:.1f}s)')
        self.logger.info(f'{tag}: never read as on-cooldown after {n} presses (seen ready={seen_ready})')
        return False

    def press_res_until_cd(self, char, cap, tag, ready_grace=None, poke=False):
        ready_grace = self.SKILL_BAR_SETTLE if ready_grace is None else ready_grace
        return self.press_key_until_cd(char.send_resonance_key, char.resonance_available, cap, tag,
                                       ready_grace=ready_grace, poke=poke)

    def fire_r(self, char, tag, window):
        """发大招到队伍 HUD【连续】消失 LIB_GONE_CONFIRM 帧。返回放出去没有。"""
        self.wait_hud_up(tag=f'{tag}前HUD')
        start = time.time()
        self.lib_press_at = start
        n = gone = 0
        fired = False
        while time.time() - start < window:
            char.send_liberation_key()
            n += 1
            self.task.next_frame()
            if not self.hud_ok():
                gone += 1
                if gone >= self.LIB_GONE_CONFIRM:
                    fired = True
                    break
            else:
                gone = 0
            self.macro_wait(self.LIB_KEY_INTERVAL)
        self.task.skip_combat_check = True
        if fired:
            char.record_liberation_use()
            self.macro_mark(f'{tag}_fired(x{n},{time.time() - start:.2f}s)')
            return True
        self.macro_mark(f'{tag}_NOFIRE(x{n})')
        try:
            lit = bool(char.liberation_available())
        except Exception:
            lit = 'err'
        self.logger.warning(f'{tag}: {char.name} liberation never started an animation '
                            f'after {n} presses (icon lit={lit})')
        return False

    def lib_ready_reads(self, char, frames):
        """HUD 在场时连续 frames 帧读到 char 的 R 可用。HUD 不在的帧不算, 最多读 frames*3 帧。"""
        hits = 0
        for _ in range(frames * 3):
            self.task.next_frame()
            if self.hud_ok():
                try:
                    ready = bool(char.liberation_available())
                except Exception:
                    ready = False
                if not ready:
                    return False
                hits += 1
                if hits >= frames:
                    return True
            self.macro_wait(0.02)
        return False

    def ensure_r(self, char, tag, window, cap, build):
        """R 一定要放出来。读 R 亮 -> 按; 亮着却没放出去就再按, 最多 R_TRIES 次; 不亮 -> build 攒能量。"""
        start = time.time()
        tries = rounds = 0
        while time.time() - start < cap:
            if self.lib_ready_reads(char, 2):
                tries += 1
                if self.fire_r(char, f'{tag}R' if tries == 1 else f'{tag}R重按#{tries - 1}', window):
                    if rounds:
                        self.logger.info(f'{tag}: {char.name} R 攒了 {time.time() - start:.1f}s 能量才放出去')
                    return True
                if tries >= self.R_TRIES:
                    break
                continue
            rounds += 1
            if rounds == 1:
                self.macro_mark(f'{tag}R没亮(攒能量)')
            build(rounds)
            if rounds % self.R_BLIND_EVERY == 0 and not self.lib_ready_reads(char, 2) and \
                    self.fire_r(char, f'{tag}R盲按#{rounds}', self.R_BLIND_WINDOW):
                return True
        self.logger.warning(f'{tag}: {char.name} 的 R 保底 {time.time() - start:.1f}s 还是没放出去 '
                            f'(亮了按 {tries} 次, 攒能量 {rounds} 轮), 不放了')
        return False

    def read_cd(self, name='resonance', char=None):
        """读技能框里的 CD 数字(秒)。不在 CD / 读不到都返回 0。"""
        try:
            index = None if char is None else char.index
            return max(0.0, float(self.task.get_cd(name, index)))
        except Exception:
            return 0.0

    def read_con(self, want, settle=None, click=False, tag=None):
        """读协奏: 自己刷帧、给结算留时间, 连着几帧达到 want 就立刻返回。返回期间读到的最大值。"""
        settle = 0.50 if settle is None else settle
        start = time.time()
        best = 0.0
        hits = 0
        next_click = 0.0
        while True:
            now = time.time()
            if click and now >= next_click:
                self.click()
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            self.hud_ok()
            try:
                con = float(self.task.get_current_con())
            except Exception:
                con = 0.0
            best = max(best, con)
            hits = hits + 1 if con >= want else 0
            if hits >= self.CON_FULL_CONFIRM or time.time() - start >= settle:
                break
            self.macro_wait(self.CON_POLL)
        if tag:
            self.macro_mark(f'{tag}(con{best:.2f},{time.time() - start:.2f}s)')
        return best

    def wait_con_full(self, who, cap, tag, poke=True):
        """边打边等协奏真满(连着几帧)。返回满没满。"""
        start = time.time()
        samples = []
        hits = 0
        next_click = 0.0
        while time.time() - start < cap:
            now = time.time()
            if poke and now >= next_click:
                self.click()
                next_click = now + self.A_INTERVAL
            self.task.next_frame()
            self.hud_ok()
            try:
                con = float(self.task.get_current_con())
            except Exception:
                con = 0.0
            if len(samples) < self.CON_SAMPLE_MAX:
                samples.append(f'{time.time() - start:.2f}:{con:.2f}')
            hits = hits + 1 if con >= self.CON_ENOUGH else 0
            if hits >= self.CON_FULL_CONFIRM:
                self.macro_mark(f'{tag}(满,{time.time() - start:.2f}s)')
                return True
            self.macro_wait(self.CON_POLL)
        self.macro_mark(f'{tag}(没满,{time.time() - start:.2f}s)')
        self.logger.info(f'{tag}: {who} 协奏 {" ".join(samples)}')
        return False

    @staticmethod
    def glyph_vec(a):
        v = a.astype(np.float32).flatten()
        v = v - v.mean()
        n = float(np.linalg.norm(v))
        return v / n if n > 0 else v

    def dodge(self, tag):
        """闪避(右键)。"""
        self.task.mouse_down(key='right')
        try:
            self.macro_wait(self.XN2_DODGE_HOLD)
        finally:
            self.task.mouse_up(key='right')
        self.macro_mark(f'{tag}闪避')

    def break_prompt(self):
        """怪身上有处决提示(屏幕中间那个 F, 排除拾取 F)。读当前帧。不看顶部的谐度满(f_break_full)。"""
        task = self.task
        try:
            hit = task.find_one('f_break', box=task.box_of_screen(0.2, 0.2, 0.75, 0.8, hcenter=True, vcenter=True),
                                target_height=720, threshold=self.XN_BREAK_CENTER_MIN)
            return bool(hit) and not task.is_pick_f()
        except Exception as e:
            self.logger.info(f'处决提示读失败 {e}')
            return False

    def break_prompt_reads(self, frames):
        """最多读 frames 帧, 有一帧读到怪身上的处决提示就返回 True。"""
        for _ in range(frames):
            self.task.next_frame()
            if self.break_prompt():
                return True
        return False

    # ==================== 卜灵 ====================
    # 【卦象读数】: 黄 = 艮, 蓝 = 震。扫回路条上方那一整条带, 按列分段数图标 ——
    # 卦象居中排列, 数量变时位置会动, 写死单个坐标会读丢。
    # 阈值来自 2026-10-08 截图逐像素采样(不是猜的)。
    # 【所有读屏都包了异常】: 读不到就退回按时间走 —— 读屏失败绝不能弄死整个宏。

    def _probe_fail(self, what, e):
        """读屏失败只报一次, 免得刷屏。"""
        key = f'_probe_fail_{what}'
        if not getattr(self, key, False):
            setattr(self, key, True)
            self.logger.warning(f'xlb: {what} 读屏失败({type(e).__name__}: {e}) — 该判据退回按时间走')

    def _band_hsv(self, box):
        frame = self.task.frame
        if frame is None:
            return None
        crop = frame[box.y:box.y + box.height, box.x:box.x + box.width, :3]
        if crop.size == 0:
            return None
        return cv2.cvtColor(np.ascontiguousarray(crop), cv2.COLOR_BGR2HSV)

    def _count_blobs(self, col_hits):
        """把"这一列有没有目标色"的布尔序列切成段, 返回段数。太窄的段当噪点丢掉。"""
        w = len(col_hits)
        if w == 0:
            return 0
        gap = max(1, int(w * self.BL_GUA_GAP))
        n = 0
        run = 0
        blank = gap + 1          # 开头就把"空"当满的, 第一段起头不用等
        for has in col_hits:
            if has:
                if blank > gap and run == 0:
                    n += 1
                run += 1
                blank = 0
            else:
                if 0 < run < self.BL_GUA_MIN_COLS:
                    n -= 1       # 太窄, 是噪点不是图标
                run = 0
                blank += 1
        if 0 < run < self.BL_GUA_MIN_COLS:
            n -= 1
        return max(0, n)

    def bl_gua(self):
        """读回路条上方的卦象: 返回 (艮数, 震数)。【黄 = 艮, 蓝 = 震】。读不到返回 (0,0)。

        【顺带记 self._gua_ok】: 读成功(哪怕是 0,0)置 True; 读崩了置 False。
        调用方靠它区分"真的没有卦象"和"读屏坏了" —— 前者要跳过重击, 后者只能盲按。
        """
        try:
            box = self.task.box_of_screen_scaled(3840, 2160, *self.BL_GUA_BAND, hcenter=True)
            hsv = self._band_hsv(box)
            if hsv is None:
                self._gua_ok = False
                return 0, 0
            h, sat, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
            base = (sat >= self.BL_GUA_SAT_MIN) & (v >= self.BL_GUA_VAL_MIN)
            lo, hi = self.BL_GUA_HUE_YELLOW
            yellow = base & (h >= lo) & (h <= hi)
            lo, hi = self.BL_GUA_HUE_BLUE
            blue = base & (h >= lo) & (h <= hi)
            # 一列里这个颜色的占比够多才算"这一列有这个图标"(滤掉辉光边缘的零星像素)
            n_y = self._count_blobs(yellow.mean(axis=0) >= self.BL_GUA_PIX_MIN)
            n_b = self._count_blobs(blue.mean(axis=0) >= self.BL_GUA_PIX_MIN)
            self.bl_gua_last = (n_y, n_b)
            self._gua_ok = True
            return n_y, n_b
        except Exception as e:
            self._gua_ok = False
            self._probe_fail('bl_gua', e)
            return 0, 0

    def bl_gua_trace(self, tag):
        """把卦象带的读数打进日志(上机标定用)。返回 (艮, 震)。读不到返回 (0,0)。"""
        try:
            n_y, n_b = self.bl_gua()
            box = self.task.box_of_screen_scaled(3840, 2160, *self.BL_GUA_BAND, hcenter=True)
            hsv = self._band_hsv(box)
            yy = bb = 0.0
            if hsv is not None:
                h, sat, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
                base = (sat >= self.BL_GUA_SAT_MIN) & (v >= self.BL_GUA_VAL_MIN)
                lo, hi = self.BL_GUA_HUE_YELLOW
                yy = float((base & (h >= lo) & (h <= hi)).mean())
                lo, hi = self.BL_GUA_HUE_BLUE
                bb = float((base & (h >= lo) & (h <= hi)).mean())
            self.logger.info(f'{tag}卦象读取: 黄{yy:.4f} 蓝{bb:.4f} -> 艮{n_y} 震{n_b}')
            return n_y, n_b
        except Exception as e:
            self._probe_fail('bl_gua_trace', e)
            return 0, 0

    def bl_gua_share(self):
        """卦象带里 黄+蓝 的占比和。读不到返回 None。

        【为什么不用数图标】: 2026-10-08 实机三次读数(同一状态) 艮1震0 / 艮2震2 / 艮1震1 ——
        _count_blobs 这条路上发光团的辉光会把相邻图标连成一片, 数不准。
        "有没有卦象"用占比和判断稳得多(有: 0.17~0.62 / 没有: 0.00~0.05)。
        """
        try:
            box = self.task.box_of_screen_scaled(3840, 2160, *self.BL_GUA_BAND, hcenter=True)
            hsv = self._band_hsv(box)
            if hsv is None:
                self._gua_ok = False
                return None
            h, sat, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
            base = (sat >= self.BL_GUA_SAT_MIN) & (v >= self.BL_GUA_VAL_MIN)
            lo, hi = self.BL_GUA_HUE_YELLOW
            yy = float((base & (h >= lo) & (h <= hi)).mean())
            lo, hi = self.BL_GUA_HUE_BLUE
            bb = float((base & (h >= lo) & (h <= hi)).mean())
            self._gua_ok = True
            return yy + bb
        except Exception as e:
            self._gua_ok = False
            self._probe_fail('bl_gua_share', e)
            return None

    def bl_heavy_ready(self):
        """卜灵现在能不能按重击、会打出哪个 —— 读右下角鼠标图标的左键高亮。读当前帧。

        返回: 'yang' = 亮黄(艮+震 -> 少阳) / 'yin' = 亮蓝(震+震 -> 少阴) /
              'no'   = 没亮(卦象不够, 按了就是卜卦失败) / None = 读屏坏了, 判不了。

        【为什么不按颜色二分】: 2026-10-08 四张实拍截图 —— 图2(无卦象)那一小块背后是亮蓝城市,
        "蓝占比"读成 100%, 完全被背景污染。所以先用"又亮又饱和"(V>=204 且 S>=140)把【高亮本身】
        挑出来, 再看它偏向黄还是蓝:
            该亮的两张 2.00% / 2.29%, 不该亮的两张 0.00% / 0.00%。
        """
        try:
            box = self.task.box_of_screen_scaled(3840, 2160, *self.BL_HEAVY_BOX, hcenter=True)
            hsv = self._band_hsv(box)
            if hsv is None:
                return None
            h, sat, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
            lit = (v >= self.BL_HEAVY_VAL_MIN) & (sat >= self.BL_HEAVY_SAT_MIN)
            if float(lit.mean()) < self.BL_HEAVY_MIN:
                return 'no'
            lo, hi = self.BL_YY_HUE_YELLOW
            n_y = int((lit & (h >= lo) & (h <= hi)).sum())
            lo, hi = self.BL_GUA_HUE_BLUE
            n_b = int((lit & (h >= lo) & (h <= hi)).sum())
            if n_b > n_y:
                return 'yin'
            return 'yang'          # 黄的更多, 或者色相认不出(亮着就行, 当少阳)
        except Exception as e:
            self._probe_fail('bl_heavy_ready', e)
            return None

    def bl_yy(self):
        """读下方回路条: (左半有黄, 右半有蓝)。【黄 = 少阳(左), 蓝 = 少阴(右)】。读不到 (False,False)。"""
        try:
            out = []
            for x1, y1, x2, y2, hue in ((*self.BL_YY_L, self.BL_YY_HUE_YELLOW),
                                        (*self.BL_YY_R, self.BL_GUA_HUE_BLUE)):
                box = self.task.box_of_screen_scaled(3840, 2160, x1, y1, x2, y2, hcenter=True)
                hsv = self._band_hsv(box)
                if hsv is None:
                    out.append(False)
                    continue
                h, sat, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
                lo, hi = hue
                share = float(((sat >= self.BL_YY_SAT_MIN) & (v >= self.BL_YY_VAL_MIN)
                               & (h >= lo) & (h <= hi)).mean())
                out.append(share >= self.BL_YY_PIX_MIN)
            return out[0], out[1]
        except Exception as e:
            self._probe_fail('bl_yy', e)
            return False, False

    def bl_flying(self):
        """现在在不在空中。读不出来一律当"在地面"。"""
        try:
            return bool(self.flying())
        except Exception:
            return False

    def bl_wait_down(self, tag, cap=None):
        """等落地。【硬上限】到了照走。"""
        cap = self.BL_WAIT_DOWN_CAP if cap is None else cap
        start = time.time()
        while time.time() - start < cap:
            self.task.next_frame()
            if not self.bl_flying():
                return True
            self.macro_wait(0.05)
        return False

    def bl_wait_air(self, tag, cap):
        """等离地。【硬上限】"""
        start = time.time()
        while time.time() - start < cap:
            self.task.next_frame()
            if self.bl_flying():
                self.macro_mark(f'{tag}离地({time.time() - start:.2f}s)')
                return True
            self.macro_wait(0.03)
        return False

    def bl_cycle(self, bl, duration, tag):
        """平a 一个时间窗。返回点了几下。"""
        start = time.time()
        n = 0
        while time.time() - start < duration:
            self.task.next_frame()
            self.tap()
            n += 1
            self.macro_wait(self.BL1_CYCLE_SLEEP)
        self.macro_mark(f'{tag}平a(x{n},{time.time() - start:.2f}s)')
        return n

    def bl_heavy_hold(self, bl, tag, hold=None, retries=None):
        """长按重击: 按满 hold 秒; 期间离地(被打断)就等落地重来。每次尝试都有硬上限。

        【一次长按就出两段】(用户 2026-10-08): "卜灵的重击一直长按能在很短时间内快速把两段
        重击都打出去的"。所以调用方现在只调一次, hold = BL2_HOLD 覆盖两段。
        BL2_HOLD_EARLY_DARK 打开时, 会盯着右下角那个提示: 它灭了 = 卦象用光、两段打完, 提前松手。
        """
        hold = self.BL2_HOLD if hold is None else hold
        retries = self.BL2_HOLD_RETRIES if retries is None else retries
        for k in range(1, retries + 1):
            self.task.mouse_down()
            self.holding_attack = True
            start = time.time()
            interrupted = False
            early = False
            dark = 0
            next_read = 0.0
            try:
                while time.time() - start < hold:
                    self.task.next_frame()
                    if self.bl_flying():
                        interrupted = True
                        break
                    elapsed = time.time() - start
                    if (self.BL2_HOLD_EARLY_DARK and elapsed >= self.BL2_HOLD_DARK_MIN
                            and time.time() >= next_read):
                        next_read = time.time() + self.BL2_HOLD_DARK_EVERY
                        if self.bl_heavy_ready() == 'no':
                            dark += 1
                            if dark >= self.BL2_HOLD_DARK_CONFIRM:
                                early = True
                                break
                        else:
                            dark = 0
                    self.macro_wait(self.BL2_HOLD_POLL)
            finally:
                self.task.mouse_up()
                self.holding_attack = False
            self.macro_wait(self.BL2_HOLD_SETTLE)
            if not interrupted:
                if early:
                    self.macro_mark(f'{tag}重击两段打完(提示灭,提前松手,{time.time() - start:.2f}s)')
                else:
                    self.macro_mark(f'{tag}重击(按住{time.time() - start:.2f}s)')
                return True
            self.macro_mark(f'{tag}重击被打断(离地,#{k})')
            self.bl_wait_down(tag)
        self.macro_mark(f'{tag}重击(重试{retries}次都没按满)')
        self.logger.warning(f'{tag}: 重击 {retries} 次都被打断, 照常往下走')
        return False

    def bl_heavy_ok(self, tag):
        """重击之前: 看游戏自己给的提示。返回 True = 按, False = 【跳过这一下重击】。

        【用户 2026-10-08 提的判据】: 右下角鼠标图标的左键亮 = 能按(黄少阳/蓝少阴), 不亮 = 卦象不够。
        这个比"数卦象发光团"靠谱得多(后者同一状态数出 1/4/2)。

        【提示没亮就补平a —— 用户 2026-10-08 第二次反馈: "还是会出现那个问题"】:
        日志里实测: 重击1 前提示亮(yang) -> 打完重击1, 重击2 前提示就没亮了(只攒到 2 枚),
        于是只出少阳、没有少阴, 五雷阵也就没了。所以提示没亮时【点几下平a 补卦象】——
        卜灵普攻第2段给艮、第4段给震, 正好能补。每点一下都重读提示, 【一亮立刻停手按重击】;
        上限 BL2_TOPUP_CAP 到了还亮不了就放弃跳过。
        【跟最早那版的区别】: 最早是按一个读不准的卦象占比瞎补(补 2.5~3.7 秒还常白补),
        现在是【按游戏自己的提示补, 一亮就停】, 不会白站。
        """
        what = self.bl_heavy_ready()
        if what is None:
            self.logger.warning(f'{tag}: 重击提示读屏不可用, 判不了 —— 照按(盲)')
            return True
        if what != 'no':
            self.macro_mark(f'{tag}重击提示亮({what})')
            return True
        start = time.time()
        taps = 0
        while time.time() - start < self.BL2_TOPUP_CAP:
            self.tap()
            taps += 1
            self.macro_wait(max(0.0, self.BL2_TOPUP_EVERY - self.A_TAP))
            what = self.bl_heavy_ready()
            if what is None or what != 'no':
                self.macro_mark(f'{tag}补卦象后提示亮({what},A x{taps},'
                                f'{time.time() - start:.2f}s)')
                return True
        self.macro_mark(f'{tag}提示一直没亮(补A x{taps},{time.time() - start:.2f}s), 跳过')
        return False

    def seg_bl1(self, bl, lei, tag):
        """卜灵·第一格: a1a2 攒「艮」-> e(遁影牵雷, 拿「震」) -> e后秒接 a4(再拿「震」) -> 跳a(第三枚) -> 切雷主。

        【4 枚卦象的来源】: a2 给艮, e 给震, 【e 秒接的那个 a 就是 a4】照样给震, 跳a(空中攻击)再给震。
        【跳a 结束时人在空中】: 雷主就从空中切进来打下落 —— 所以末尾【不等落地】,
        也【不等 HUD】(要趁还在空中切, 等了就落地了)。
        """
        if self.cur is not bl:
            self.need(self.switch_retry(bl, f'{tag}切卜灵'), 'switch to douling')
        self.bl_cycle(bl, self.BL1_A_BEFORE_E, f'{tag}攒卦')
        if self.bl_flying():
            self.bl_wait_down(tag)
        clicked = False
        try:
            clicked = bool(bl.click_resonance(send_click=True, time_out=self.BL1_E_TIME_OUT)[0])
        except Exception as e:
            self.logger.info(f'{tag}: click_resonance 读失败 {e}')
        if not clicked:
            self.macro_mark(f'{tag}E没放出去')
            self.logger.warning(f'{tag}: 卜灵 E 没放出去 — 这一格少一枚震, 第二格第二次重击可能卜卦失败; '
                                f'照内置 _finish_and_reset 直接 q r 收尾')
            self.bl_e_failed_finish(bl, tag)
            return
        bl.record_resonance_use()
        self.macro_wait(self.BL1_E_SETTLE)
        if self.bl_flying():
            self.bl_wait_down(tag)
        # ---- e 后接着 A: 这一下就是 a4(给「震」) ----
        self.bl_cycle(bl, self.BL1_A_AFTER_E, f'{tag}接a4')
        # 【读数放在跳之前】: 跳完要【立刻】切人, 中间插一次读屏(两次截图+入日志)会拖掉
        # 一二百毫秒, 人就落地了 —— 雷主就不是空中切进来, 下落打不出来。
        self.bl_gua_trace(f'{tag}接a4后')
        # ---- 跳a: 空中攻击, 第三枚「震」。跳完【立刻】切雷主(趁还在空中) ----
        self.bl_jump_a(bl, tag, stay_air=True)
        self.need(self.switch_retry(lei, f'{tag}切雷主', time_out=self.LEI1_SWITCH_TIME_OUT),
                  'douling -> rover')

    def bl_jump_a(self, bl, tag, stay_air=False):
        """跳 -> 【立刻】空中平a(补第三枚「震」)。stay_air=True 就不等落地。

        【为什么不能等 flying()】(2026-10-08 实机日志):
            op卜1跳a(没读到离地, 照点)@5.81
        bl_wait_air 空等满了 BL1_TO_AIR_CAP(1.2s) 才点这一下 —— 那时人早落地了, 于是变成
        "跳起来没接a, 落地以后才a", 还顺带少一枚「震」(第二格的重击就不够卦象了)。
        flying() 在这台机器上要么读不到、要么太慢, 【不能进控制流】。
        照内置 src/char/Douling.py 的 _do_segment2 形状: jump(after_sleep=0.01) -> sleep(0.05) -> click。
        """
        try:
            self.task.jump(after_sleep=self.BL2_JUMP_SETTLE)
        except Exception as e:
            self.macro_mark(f'{tag}跳失败')
            self.logger.info(f'{tag}: task.jump 失败 {e} — 空中那枚卦象拿不到')
            return False
        self.macro_wait(self.BL1_AIR_TAP_DELAY)   # 0.05, 照内置
        self.tap()                                 # 空中那一下(第三枚「震」)
        self.macro_mark(f'{tag}跳a')
        if not stay_air:
            self.bl_wait_down(tag)
        return True

    def bl_e_failed_finish(self, bl, tag):
        """E 没放出去时的兜底(照内置 _finish_and_reset): q -> r -> 交给调用方切人。"""
        self.spam_key(bl.send_echo_key, self.BL2_ECHO_TIME_OUT, tag=f'{tag}Q', presses=1)
        bl.record_echo_use()
        self.fire_r(bl, f'{tag}卜灵R', self.BL_R_WINDOW)
        self.wait_hud_back(tag=f'{tag}R演出', min_gone=self.BL_R_ANIM_MIN, time_out=self.BL_R_ANIM_CAP)

    def seg_bl2(self, bl, lei, tag):
        """卜灵·第三格: zz(少阳 + 少阴) -> 切雷主。

        【一次长按就出两段 —— 用户 2026-10-08 纠正】:
          "卜灵的重击一直长按能在很短时间内快速把两段重击都打出去的"。
        所以这里是【一次】bl_heavy_hold, 不是两次。之前拆成两次各 2.5s(合计 5.2s + 中间 0.35s 缝)
        是错的: 又慢、又多等一个 GAP, 而且第二次长按还容易被上一段的动画吃掉。
        日志里就是这个错的样子:
            卜2重击1前重击提示亮(yang)@5.78  卜2重击1重击(按住2.59s)@8.37
            卜2重击2前重击提示亮(yin)@8.74   卜2重击2重击(按住2.66s)@11.40
        【提示判据本身没识别错】: 一次亮 yang(艮+震)、一次亮 yin(震+震), 跟两段重击完全对得上。
        【4 枚卦象正好够两段】: 艮+震 -> 少阳(黄), 震+震 -> 少阴(蓝), 游戏在一次长按里连着打完。
        【卦象不够就跳过, 不硬按】: 不足 2 枚硬按是卜卦失败, 白扣 20% 血(用户 2026-10-08)。
        """
        if self.cur is not bl:
            self.need(self.switch_retry(bl, f'{tag}切卜灵'), 'switch to douling')
        # 【先等 UI 渲染】: 刚切过来那一两帧什么都读不准(回路条、技能栏都在渐显)。
        self.macro_wait(self.BL2_ENTER_SETTLE)
        # 【提示没亮就补卦象, 亮了就长按这一次】(不亮说明卦象不够, 硬按是卜卦失败)
        if self.bl_heavy_ok(f'{tag}重击前'):
            self.bl_heavy_hold(bl, f'{tag}重击')
        y, b = self.bl_yy()
        self.macro_mark(f'{tag}阴阳(少阳{"有" if y else "无"},少阴{"有" if b else "无"})')
        # 【切人前先等重击动作走完】(2026-10-08 实机): 长按刚松手时角色还在重击动画里,
        # 这时发的数字键会被吃掉 -> >RovFAIL -> 整圈重来 -> 重开时人还在卜灵身上 ->
        # 跳过切人直接攒卦平a -> 又重击 -> 卦象不够被电(用户报的"两次重击后不切人还继续打")。
        self.macro_wait(self.BL2_LEAVE_SETTLE)
        # 【切人失败不再放弃整圈】(用户 2026-10-08): 改成"正常切 -> 不行就按时间强切继续"。
        # 抛 MacroBroken 会让整圈重来, 重开时人还在卜灵身上 -> 又攒卦又重击 -> 被电。
        self.switch_or_force(lei, f'{tag}切雷主', time_out=self.LEI1_SWITCH_TIME_OUT)

    def seg_bl3(self, bl, lei, tag):
        """卜灵·第四格: q(声骸) -> r(大招, 五雷阵立即铺开) -> 协奏满 -> 【变奏】雷主。

        【按用户文字轴: 这一格就是 q 然后 r】, 【没有平a】。
        上一版这里加了个"大招前协奏不够就点平a补", 实测【纯浪费】——
          2026-10-08 日志: 大招前补协奏(0.84,A x18,3.74s), 而协奏只从 0.51 爬到 0.62,
          18 下平a 一点用没有, 白站 3.7 秒。用户看到的就是"卜灵重击完还在打没用的平a"。
        现在只【读一次记日志】, 不补。

        【切人前先等 HUD】: 卜灵 R 演出期间 HUD 被盖住, 立刻切人必然超时(2026-10-08 日志:
        >RovFAIL trace 全是 x, 2.5s 读不到 HUD, 每圈白花 2 秒)。这一格等得起。
        """
        if self.cur is not bl:
            self.need(self.switch_retry(bl, f'{tag}切卜灵'), 'switch to douling')
            self.macro_wait(self.BL2_ENTER_SETTLE)
        self.bl_con_log(tag)
        self.spam_key(bl.send_echo_key, self.BL2_ECHO_TIME_OUT, tag=f'{tag}Q', presses=1)
        bl.record_echo_use()
        if self.ensure_r(bl, tag, self.BL_R_WINDOW, self.BL_R_CAP,
                         lambda rounds: self.macro_spam(self.R_BUILD_SLICE, tag=f'{tag}攒能量#{rounds}')):
            self.wait_hud_back(tag=f'{tag}卜灵R演出', min_gone=self.BL_R_ANIM_MIN,
                               time_out=self.BL_R_ANIM_CAP)
        full = self.read_con(1.0, settle=0.15) >= 1.0 or \
            self.wait_con_full('卜灵', self.XN2_CON_CAP, tag=f'{tag}协奏')
        if not full:
            self.logger.warning(f'{tag}: 卜灵协奏没满就切雷主 — 雷主不是变奏进来的')
        self.need(self.switch_after_anim(lei, f'{tag}切雷主', assume_con=full), 'douling -> rover')

    def bl_con_log(self, tag):
        """只读一次卜灵的大招前协奏并记日志。【不点平a】—— 实测平a对卜灵的协奏几乎没用。"""
        con = self.read_con(1.0, settle=0.20)
        self.macro_mark(f'{tag}大招前协奏{con:.2f}')
        if con < self.BL_R_CON_MIN:
            self.logger.warning(f'{tag}: 大招前协奏只有 {con:.2f}(<{self.BL_R_CON_MIN:.2f}), '
                                f'大招只回一点, 放完多半不满 —— 但【不补平a】, 按轴走')
    # ==================== 雷主 ====================
    # 【所有读屏都包了异常】: 读不到就退回按时间走。

    def lei_ready_white(self):
        """回路条右边 [E] 小框的白字占比(电涌满了才亮)。读不到返回 None。"""
        try:
            box = self.task.box_of_screen_scaled(3840, 2160, *self.LEI_READY_BOX, hcenter=True)
            return float(self.task.calculate_color_percentage(forte_white_color, box))
        except Exception as e:
            self._probe_fail('lei_ready_white', e)
            return None

    def lei_e_white(self):
        """雷主【E 图标】的白字占比: 地面亮着, 人在空中变灰。读不到返回 None。

        【框名是猜的】: LEI1_E_BOX_NAME='box_resonance', 框架里真实名字未知。
        2026-10-08 日志里白字恒 0.08(>阈值 0.04) -> 被判"一直在地面"。
        所以【这个判据只当参考】: 控制流全按时间走, 读到就用来提前结束, 读不到不影响流程。
        """
        try:
            if self.LEI1_E_BOX:
                box = self.task.box_of_screen_scaled(3840, 2160, *self.LEI1_E_BOX, hcenter=True)
            else:
                box = self.task.get_box_by_name(self.LEI1_E_BOX_NAME)
            return float(self.task.calculate_color_percentage(text_white_color, box))
        except Exception as e:
            self._probe_fail('lei_e_white', e)
            return None

    def lei_ready_reads(self, frames):
        """HUD 在场时连着 frames 帧读到 [E] 小框亮(电涌满)。"""
        hits = 0
        for _ in range(frames * 3):
            self.task.next_frame()
            if self.hud_ok():
                w = self.lei_ready_white()
                if w is None:
                    return False
                if w >= self.LEI_READY_MAX:
                    continue
                if w <= self.LEI_READY_MIN:
                    return False
                hits += 1
                if hits >= frames:
                    return True
        return False

    def lei_wait_ready(self, lei, deadline, tag):
        """一直点 A 到 [E] 小框亮(电涌满)。到 deadline 没亮返回 False。

        【先读 CD】: 2026-10-08 日志里白等 6.09s —— 用户实机是进场前能量就满了、强化E 提前放了。
        E 已经在 CD(>=12s) 说明超负荷已就绪, 直接跳过。
        """
        cd = self.read_cd('resonance', lei)
        if cd >= self.LEI_SKIP_WAIT_CD:
            self.macro_mark(f'{tag}E已在CD({cd:.1f}s)=超负荷已就绪, 跳过等电涌')
            return True
        start = time.time()
        taps = hits = 0
        next_tap = 0.0
        next_cd = start + self.LEI_CD_POLL
        trace = []
        while time.time() < deadline:
            now = time.time()
            # 【保底: 强化E 提前打出就不等电涌了】(用户 2026-10-08):
            # "雷主打完qre时若强化e提前打出且协奏已满就提前切人"。
            # 这一等最长 LEI3_READY_CAP(2.5s), 而强化E 真出去的话 E 的 CD 会变成 25s
            # (雷引只有 10s)。所以每隔 LEI_CD_POLL 重读一次 CD, 认出来就立刻收手 ——
            # 也让后面 seg_lei3 的"已出+协奏满 -> 直接切心"能马上判到。
            if now >= next_cd:
                next_cd = now + self.LEI_CD_POLL
                cd = self.read_cd('resonance', lei)
                if cd >= self.LEI_SKIP_WAIT_CD:
                    self.macro_mark(f'{tag}超负荷已提前打出(CD{cd:.1f}s), 不等电涌(A x{taps})')
                    return True
            if now >= next_tap:
                self.tap()
                taps += 1
                next_tap = time.time() + max(0.0, self.LEI2_A_EVERY - self.A_TAP)
            self.task.next_frame()
            if self.hud_ok():
                w = self.lei_ready_white()
                if w is not None:
                    if len(trace) < 40:
                        trace.append(f'{time.time() - start:.2f}:{w:.2f}')
                    hits = hits + 1 if self.LEI_READY_MIN < w < self.LEI_READY_MAX else 0
                    if hits >= self.LEI_READY_CONFIRM:
                        self.macro_mark(f'{tag}电涌满(A x{taps},{time.time() - start:.2f}s)')
                        return True
            self.macro_wait(0.01)
        self.macro_mark(f'{tag}小框没亮(A x{taps},{time.time() - start:.2f}s)')
        if trace:
            self.logger.info(f'{tag}: [E] 小框白字占比 — {" ".join(trace)}')
        return False

    def lei_overload(self, lei, tag):
        """点按 E 到进 CD, CD > LEI_E_CD_MIN 才算【超负荷(强E)】出去了(雷引 CD 才 10s)。"""
        cd = self.read_cd('resonance', lei)
        if cd >= self.LEI_E_CD_MIN:
            self.macro_mark(f'{tag}超负荷已在CD({cd:.1f}s), 不重复按')
            return True
        for k in range(self.LEI_E_TRIES):
            if k > 0:
                self.lei_wait_ready(lei, time.time() + self.LEI_E_RETRY_A, f'{tag}补电涌#{k}')
            self.press_res_until_cd(lei, self.LEI_E_CAP, tag=f'{tag}强E#{k + 1}', ready_grace=0.30)
            cd = self.read_cd('resonance', lei)
            if cd >= self.LEI_E_CD_MIN:
                lei.record_resonance_use()
                self.macro_mark(f'{tag}超负荷出手(#{k + 1},CD{cd:.1f})')
                return True
            self.macro_mark(f'{tag}强E#{k + 1}没认出超负荷(CD{cd:.1f})')
        self.logger.warning(f'{tag}: 按了 {self.LEI_E_TRIES} 回 E 都没认出超负荷')
        return False

    def seg_lei0(self, lei, tag):
        """雷主·起手格(【仅启动轴】): a1。

        【用户 2026-10-08 纠正】: 从别的角色【切】到雷主时, 切人本身就会让雷主自动打出 a1,
        不用再按平a —— 切完可以【立即】切下一位。
        只有【一开始场上就是雷主】时才需要按一次平a把 a1 打出来。
        """
        if self.cur is not lei:
            self.need(self.switch_retry(lei, f'{tag}切雷主'), 'opener: switch to rover')
            self.macro_mark(f'{tag}切雷主(a1随切人自动打出, 不按平a)')
            return
        self.tap()
        self.macro_wait(max(0.0, self.LEI0_A - self.A_TAP))
        self.macro_mark(f'{tag}起手a1(本来就在雷主, 按一下)')

    def seg_lei1(self, bl, tag):
        """雷主·第二格(卜灵跳a 时【空中】切进来): 下落 -> a1a2a3 -> 切卜灵。

        【不按 E】: 人已经在空中了, 不需要雷引拉人 —— 用户 2026-10-08 确认。
        【落地判据】: 读 E 图标 白 -> 灰(空中) -> 白(落地)。框名未知, 所以:
        控制流【按时间走】(LEI1_AIR_WINDOW 硬上限), 读到落地就提前结束 —— 绝不在这站住。
        """
        t0 = time.time()
        air_seen = ground = 0
        why = 'blind'
        trace = []
        while time.time() - t0 < self.LEI1_AIR_WINDOW:
            self.tap()
            self.task.next_frame()
            if self.hud_ok():
                w = self.lei_e_white()
                if w is not None:
                    if len(trace) < 40:
                        trace.append(f'{time.time() - t0:.2f}:{w:.2f}')
                    if w < self.LEI1_ECHO_WHITE:
                        air_seen = 1
                        ground = 0
                        why = 'air'
                    else:
                        ground += 1
                        if ground >= self.LEI1_ECHO_CONFIRM and air_seen:
                            why = 'landed'
                            break
            self.macro_wait(max(0.0, self.LEI1_A_EVERY - self.A_TAP))
        self.macro_mark(f'{tag}下落({ {"landed": "读到落地", "air": "读到空中", "blind": "读不出"}[why]},'
                        f'{time.time() - t0:.2f}s)')
        if trace:
            self.logger.info(f'{tag}: E 图标白字占比 — {" ".join(trace)}')
        self.macro_spam(self.LEI1_A_AFTER_LAND, self.LEI1_A_EVERY, tag=f'{tag}a1a2a3')
        self.need(self.switch_retry(bl, f'{tag}切卜灵', time_out=self.LEI1_SWITCH_TIME_OUT),
                  'rover -> douling')

    def seg_lei2(self, bl, tag):
        """雷主·第三格(卜灵 zz 之后普通切进来): 只打 a1a2a3 -> 切卜灵。不按 E。

        【先确认人在雷主身上】(2026-10-08): 上一格(seg_bl2)切雷主要是超时失败了, 这一格
        不检查就会在【卜灵】身上打 a1a2a3 —— 屏幕上就是"又是卜灵, 还在打没用的平a",
        日志里也看不出来。所以这里补一次切人。
        """
        lei = self.teammate('Rover')
        if lei is not None and self.cur is not lei:
            self.logger.warning(f'{tag}: 上场不是雷主(上一格切人没成功?), 先补切再打')
            self.need(self.switch_retry(lei, f'{tag}补切雷主', time_out=self.LEI1_SWITCH_TIME_OUT),
                      'switch to rover')
        self.macro_spam(self.LEI2_A3_WINDOW, self.LEI2_A_EVERY, tag=f'{tag}a1a2a3')
        self.need(self.switch_retry(bl, f'{tag}切卜灵', time_out=self.LEI1_SWITCH_TIME_OUT),
                  'rover -> douling')

    def lei3_fast_switch(self, lei, tag, arrived, why):
        """【保底】(用户 2026-10-08): "雷主打完qre时若强化e提前打出且协奏已满就提前切人"。

        条件 = 强化E(超负荷)已经出去(E 在 CD 上且 CD >= LEI_E_CD_MIN, 雷引只有 10s)
               且 协奏已满。
        成立就【立刻切心】(assume_con=True = 满协奏变奏), 返回 True; 否则返回 False, 调用方照常往下走。
        这样强化E 提前打出的那一次不会白等电涌(LEI3_READY_CAP) 也不白等协奏(LEI_CON_CAP)。
        """
        if self.read_cd('resonance', lei) < self.LEI_E_CD_MIN:
            return False
        con = self.read_con(1.0, settle=0.10)
        if con < 1.0:
            return False
        self.macro_mark(f'{tag}强E已出+协奏已满({why},{con:.2f}), 不等了直接切心')
        self.macro_mark(f'{tag}雷主到场->变奏心 '
                        f'游戏时间{time.time() - arrived - self.lei2_pause:.2f}s')
        self.need(self.switch_after_anim(self, f'{tag}切心', assume_con=True), 'rover -> hsin')
        return True

    def seg_lei3(self, tag):
        """雷主·第四格(卜灵大招演完【变奏】进来): q(声骸) -> r(大招) -> e(雷引) -> 下落a -> 强e(超负荷) -> 变奏心。

        【按用户文字轴, 顺序不动】: q r e 下落a 强e。
        【能量提前满了没关系】: 都先读 CD, 已经在 CD 上就跳过, 不白等也不空按。
        """
        lei = self.teammate('Rover') or self.cur
        if self.cur is not lei:
            # 同上: 别把雷主的整套技能打在卜灵身上
            self.logger.warning(f'{tag}: 上场不是雷主, 先补切再打')
            self.need(self.switch_retry(lei, f'{tag}补切雷主', time_out=self.LEI1_SWITCH_TIME_OUT),
                      'switch to rover')
        arrived = getattr(lei, 'last_switch_in_time', 0.0) or time.time()
        self.lei2_pause = 0.0
        if not getattr(lei, 'has_intro', False):
            self.macro_mark(f'{tag}雷主不是变奏进来的(心的导电加成没了)')
        # ---- q(声骸) ----
        self.tap()
        self.wait_until_time(arrived + self.LEI3_Q_AT)
        self.spam_key(lei.send_echo_key, self.LEI3_Q_WINDOW, tag=f'{tag}Q', presses=2)
        lei.record_echo_use()
        # ---- r(大招) ----
        if self.ensure_r(lei, tag, self.LEI3_R_WINDOW, self.LEI3_R_CAP,
                         lambda rounds: self.macro_spam(self.R_BUILD_SLICE, tag=f'{tag}攒能量#{rounds}')):
            fire_t = time.time()
            self.wait_hud_back(tag=f'{tag}R演出', min_gone=self.LEI3_R_ANIM_MIN,
                               time_out=self.LEI3_R_ANIM_CAP)
            self.lei2_pause = time.time() - fire_t
        # ---- e(雷引) + 下落a ----
        if self.read_cd('resonance', lei) >= self.LEI_SKIP_WAIT_CD:
            self.macro_mark(f'{tag}E已在CD(超负荷已放), 跳过雷引+下落')
        else:
            self.press_res_until_cd(lei, self.LEI3_E_CAP, tag=f'{tag}E雷引', ready_grace=0.30)
            lei.record_resonance_use()
            self.lei_air_down(lei, tag)
        # ---- 强e(超负荷) ----
        # 【保底1】(用户 2026-10-08): 强化E 可能【提前就打出去了】(qre 之前能量就满)。
        # 那就别再等电涌了 —— 已出 + 协奏满 就直接切心。
        if self.lei3_fast_switch(lei, tag, arrived, 'qre后'):
            return
        self.lei_wait_ready(lei, time.time() + self.LEI3_READY_CAP, f'{tag}电涌')
        self.lei_overload(lei, tag)
        # 【保底2】强E 刚打完, 复查一次: 出了而且协奏满 -> 直接切, 不走下面等协奏那一段
        if self.lei3_fast_switch(lei, tag, arrived, '强E后'):
            return
        # ---- 协奏满 -> 变奏心 ----
        full = self.read_con(1.0, settle=0.15) >= 1.0 or \
            self.wait_con_full('雷主', self.LEI_CON_CAP, tag=f'{tag}协奏')
        self.macro_mark(f'{tag}雷主到场->变奏心 游戏时间{time.time() - arrived - self.lei2_pause:.2f}s')
        if not full:
            self.logger.warning(f'{tag}: 雷主协奏没满就切心 — 心没有变奏(少 60 应世心)')
        self.need(self.switch_after_anim(self, f'{tag}切心', assume_con=full), 'rover -> hsin')

    def lei_air_down(self, lei, tag):
        """E(雷引)之后: 空中一直点 A 到下落打完。硬上限 LEI3_AIR_CAP, 读不到落地也照走。"""
        e_at = time.time()
        taps = 0
        air_seen = ground = 0
        why = 'blind'
        trace = []
        while time.time() - e_at < self.LEI3_AIR_CAP:
            self.tap()
            taps += 1
            self.task.next_frame()
            if self.hud_ok():
                w = self.lei_e_white()
                if w is not None:
                    if len(trace) < 40:
                        trace.append(f'{time.time() - e_at:.2f}:{w:.2f}')
                    if w < self.LEI1_ECHO_WHITE:
                        air_seen = 1
                        ground = 0
                        why = 'air'
                    else:
                        ground += 1
                        if ground >= self.LEI1_ECHO_CONFIRM and air_seen:
                            why = 'landed'
                            break
            self.macro_wait(max(0.0, self.LEI3_AIR_TAP_EVERY - self.A_TAP))
        self.macro_mark(f'{tag}下落({ {"landed": "落地", "air": "读到空中", "blind": "读不出"}[why]},'
                        f'E后{time.time() - e_at:.2f}s,A x{taps})')
        if trace:
            self.logger.info(f'{tag}: 下落期间 E 图标白字占比 — {" ".join(trace)}')
    # ==================== 心 ====================
    # 【心这两段一个字没改】: 应世心条 / 转相 / 统御众机 / 雕像翻面 / 处决判据都跟队友是谁无关。
    # 只有切人目标从穗穗换成卜灵(xn_handoff)。

    def xn_gauge(self):
        """应世心条 -> (左半, 右半) 有紫色的列占比。读当前帧。"""
        frame = self.task.frame
        out = []
        for x1, y1, x2, y2 in (self.XN_GAUGE_L, self.XN_GAUGE_R):
            box = self.task.box_of_screen_scaled(3840, 2160, x1, y1, x2, y2, hcenter=True)
            crop = frame[box.y:box.y + box.height, box.x:box.x + box.width, :3]
            if crop.size == 0:
                return 0.0, 0.0
            hsv = cv2.cvtColor(np.ascontiguousarray(crop), cv2.COLOR_BGR2HSV)
            h, sat, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
            purple = (h >= 125) & (h <= 160) & (sat >= 70) & (v >= 90)
            out.append(float(purple.any(axis=0).mean()))
        return out[0], out[1]

    def xn_ying(self):
        """应世心 -> (满没满, 左半紫, 右半紫)。满 = 重击位的花图标 hsin_h1。读当前帧。"""
        try:
            full = bool(self.task.find_one('hsin_h1', threshold=self.XN_FULL_THRESHOLD))
        except Exception:
            full = False
        L, R = self.xn_gauge()
        return full, L, R

    def xn_icon(self, name):
        """心技能栏的图标模板(hsin_lib1 = 转相 / hsin_lib2 = 万阙垂天解锁)。读当前帧。"""
        try:
            return bool(self.task.find_one(name, threshold=0.7))
        except Exception:
            return False

    def xn_attack_down(self):
        return self.attack_down(self.XN_HOLD_SENDINPUT and self.game_foreground())

    def xn_hold_burn(self, tag):
        """按住重击 XN1_HOLD 秒, 期间看应世心条有没有被清空(= 步红尘出手)。

        返回 (状态, 清空时刻, 按下时刻)。'burned' 清空了 / 'full' 出的是普通重击 / 'unknown' 读不到。
        """
        si = self.xn_attack_down()
        start = time.time()
        self.macro_mark(f'{tag}按住({"SI" if si else "PM"})')
        seen_full = False
        burned_at = None
        low_at = None
        trace = []
        try:
            while time.time() - start < self.XN1_HOLD:
                self.task.next_frame()
                if self.hud_ok() and burned_at is None:
                    now = time.time()
                    full, L, R = self.xn_ying()
                    if len(trace) < 30:
                        trace.append(f'{now - start:.2f}:{"满" if full else ""}{L:.2f}/{R:.2f}')
                    if full or L >= self.XN_GAUGE_VALID:
                        seen_full = True
                        low_at = None
                    elif seen_full and L < self.XN_CONSUMED:
                        # 连着两帧空才算; 时刻记第一帧 —— 转相解锁从这一刻算
                        if low_at is None:
                            low_at = now
                        else:
                            burned_at = low_at
                            self.macro_mark(f'{tag}步红尘出手({burned_at - start:.2f}s)')
                self.macro_wait(0.02)
        finally:
            self.release_attack()
        if burned_at is not None:
            self.macro_mark(f'{tag}松开')
            return 'burned', burned_at, start
        full = empty = 0
        for _ in range(6):
            self.task.next_frame()
            if self.hud_ok():
                is_full, L, R = self.xn_ying()
                if is_full or L >= self.XN_GAUGE_VALID:
                    full += 1
                    seen_full = True
                elif seen_full and L < self.XN_CONSUMED:
                    empty += 1
                if full >= 2 or empty >= 2:
                    break
            self.macro_wait(0.02)
        state = 'full' if full >= 2 else ('burned' if empty >= 2 else 'unknown')
        self.macro_mark(f'{tag}松开({state})')
        self.logger.info(f'{tag}: 按住 {self.XN1_HOLD:.1f}s 没读到应世心清空 -> {state} — {" ".join(trace)}')
        return state, None, start

    def xn_r1_ready(self):
        """转相能不能按: R 图标是转相(hsin_lib1)而且亮着。读当前帧。"""
        try:
            lit = bool(self.available('liberation', check_color=True, check_cd=False))
        except Exception:
            lit = False
        return lit and self.xn_icon('hsin_lib1')

    def xn_r1_rescue(self, xn, tag):
        """转相第一次没放出去: 补到放出去为止(上限 XN1_R1_RESCUE_CAP)。返回放出去没有。"""
        start = time.time()
        rounds = 0
        lost = 0
        self.macro_mark(f'{tag}转相补救开始')
        while time.time() - start < self.XN1_R1_RESCUE_CAP:
            rounds += 1
            self.task.next_frame()
            if not self.hud_ok():
                self.wait_hud_up(cap=1.0, tag=f'{tag}转相补救等HUD')
                continue
            lit = 0
            for _ in range(self.XN1_R1_READS):
                if self.xn_r1_ready():
                    lit += 1
                self.task.next_frame()
            if lit >= self.XN1_R1_READS:
                lost = 0
                if self.fire_r(xn, f'{tag}转相补#{rounds}', self.XN_R_WINDOW):
                    self.macro_mark(f'{tag}转相补救成功({time.time() - start:.2f}s)')
                    return True
                continue
            full, L, R = self.xn_ying()
            if full or L >= self.XN_GAUGE_VALID or self.xn_icon('hsin_lib1'):
                lost = 0
            else:
                lost += 1
                if lost >= self.XN1_R1_LOST_ROUNDS:
                    self.macro_mark(f'{tag}转相补救: 已不在应世相(当转相出过了)')
                    return True
            if full or (L >= self.XN_GAUGE_VALID and R >= self.XN_YING_READY):
                state, burned_at, _hold_at = self.xn_hold_burn(f'{tag}补步红尘#{rounds}')
                if state == 'burned':
                    anchor = burned_at if burned_at is not None else time.time() - 0.3
                    due = anchor + self.XN1_R1_UNLOCK + self.XN1_R1_MARGIN
                    while time.time() < due:
                        self.task.next_frame()
                        if self.hud_ok() and self.xn_r1_ready():
                            break
                        self.macro_wait(0.01)
                continue
            self.macro_spam(self.XN1_R1_RESCUE_A, self.XN1_FILL_EVERY, tag=f'{tag}补应世心A#{rounds}')
        self.macro_mark(f'{tag}转相补救(cap,{rounds}轮)')
        return False

    def xn_hold_until_gone(self, cap, tag):
        """按住左键到队伍 HUD 消失(临寰宇出手)。消失后再按 XN2_RELEASE_AFTER_GONE 秒松手。"""
        si = self.xn_attack_down()
        start = time.time()
        self.macro_mark(f'{tag}按住({"SI" if si else "PM"})')
        gone = 0
        fired = False
        try:
            while time.time() - start < cap:
                self.task.next_frame()
                if not self.hud_ok():
                    gone += 1
                    if gone >= self.LIB_GONE_CONFIRM:
                        fired = True
                        break
                else:
                    gone = 0
                self.macro_wait(0.02)
            if fired:
                self.macro_mark(f'{tag}临寰宇出手({time.time() - start:.2f}s)')
                self.macro_wait(self.XN2_RELEASE_AFTER_GONE)
        finally:
            self.release_attack()
        self.macro_mark(f'{tag}松开({"出手" if fired else "没出"})')
        return fired

    def xn_pre_r2_con(self, tag):
        """万阙垂天之前: 协奏低于 XN2_PRE_R2_CON 就照世相普攻补(人还贴着怪)。"""
        start = time.time()
        con = self.read_con(1.0, settle=0.12)
        if con >= self.XN2_PRE_R2_CON:
            self.macro_mark(f'{tag}开大前协奏{con:.2f}')
            return
        samples = [f'0:{con:.2f}']
        taps = 0
        while time.time() - start < self.XN2_PRE_R2_CAP:
            self.tap()
            taps += 1
            self.macro_wait(max(0.0, self.A_INTERVAL - self.A_TAP))
            con = self.read_con(1.0, settle=0.03)
            if len(samples) < 20:
                samples.append(f'{time.time() - start:.2f}:{con:.2f}')
            if con >= self.XN2_PRE_R2_CON:
                break
        self.macro_mark(f'{tag}开大前补协奏({con:.2f},A x{taps},{time.time() - start:.2f}s)')
        if con < self.XN2_PRE_R2_CON:
            self.logger.info(f'{tag}: 开大前协奏补不到 {self.XN2_PRE_R2_CON:.2f} — {" ".join(samples)}')

    def xn_slot_glyph(self):
        """重击位 16x16 灰度(只取圆内像素), 已归一化。心不在场/HUD 不在返回 None。读当前帧。"""
        in_team, index, _count = self.task.in_team()
        if not in_team or index != self.index:
            return None
        self.hud_seen_at = time.time()
        ref = getattr(self, '_slot_ref', None)
        if ref is None:
            yy, xx = np.mgrid[:96, :96]
            disk = ((((xx - 48) ** 2 + (yy - 44) ** 2) <= 25 ** 2)).astype(np.float32)
            mask = cv2.resize(disk[18:70, 22:74], (16, 16), interpolation=cv2.INTER_AREA) > 0.99

            def tpl(chunks):
                raw = base64.b64decode(''.join(chunks))
                return self.glyph_vec(np.frombuffer(raw, np.uint8).reshape(16, 16).astype(np.float32)[mask])

            ref = self._slot_ref = (mask, disk, tpl(self.XN_TY_GLYPH), tpl(self.XN_READY_GLYPH))
        mask, disk, _ty, _rd = ref
        x, y, w, h = self.XN_TY_SLOT
        box = self.task.box_of_screen_scaled(3840, 2160, x, y, x + w, y + h, hcenter=True)
        frame = self.task.frame
        cx, cy = int(box.x + box.width / 2), int(box.y + box.height / 2)
        half = int(box.height * 1.1)
        icon = frame[max(0, cy - half):cy + half, max(0, cx - half):cx + half, :3]
        g = cv2.cvtColor(cv2.resize(icon, (96, 96), interpolation=cv2.INTER_AREA),
                         cv2.COLOR_BGR2GRAY).astype(np.float32) * disk
        v = cv2.resize(g[18:70, 22:74], (16, 16), interpolation=cv2.INTER_AREA)
        return self.glyph_vec(v[mask])

    def xn_tongyu(self):
        """在不在统御众机: 重击位是雕像图标。读当前帧; 心不在场/HUD 不在返回 None。"""
        try:
            v = self.xn_slot_glyph()
            if v is None:
                return None
            self._ty_score = float(v @ self._slot_ref[2])
            return self._ty_score >= self.XN_TY_MIN
        except Exception as e:
            self.logger.info(f'xn_tongyu probe failed ({e})')
            return None

    def xn_slot_state(self):
        """统御众机里重击位: 'statue' / 'ready' / '?' / None(HUD 不在)。读当前帧。"""
        try:
            v = self.xn_slot_glyph()
            if v is None:
                return None
            _mask, _disk, ty, rd = self._slot_ref
            self._ty_score = float(v @ ty)
            self._rd_score = float(v @ rd)
            if self._rd_score >= self.XN_READY_MIN:
                return 'ready'
            if self._ty_score >= self.XN_TY_MIN:
                return 'statue'
            return '?'
        except Exception as e:
            self.logger.info(f'xn_slot_state probe failed ({e})')
            return '?'

    def xn_form(self, tag):
        """心现在是哪个相: 'ying' / 'zhao' / '?'(HUD 一直不在, 当应世相处理)。"""
        start = time.time()
        live = 0
        while time.time() - start < self.XN_FORM_CAP:
            self.task.next_frame()
            if self.hud_ok():
                live += 1
                full, L, _R = self.xn_ying()
                if full or L >= self.XN_GAUGE_VALID or self.xn_icon('hsin_lib1'):
                    return 'ying'
                if live >= self.XN_FORM_READS:
                    self.macro_mark(f'{tag}在照世相({time.time() - start:.2f}s)')
                    return 'zhao'
            self.macro_wait(0.02)
        return '?'

    def xn1_fill(self, arrived, tag):
        """心第一段: 一直点普攻, 应世心满(花图标 / 右半到线, 连读几帧)并且过了 XN1_HOLD_AT_MIN 就返回。"""
        self.wait_until_time(arrived + self.XN1_A_FROM)
        hits = taps = 0
        next_tap = last_tap = 0.0
        ready_at = None
        valid_seen = False
        trace = []
        why = 'cap'
        while True:
            now = time.time()
            if now >= next_tap:
                self.tap(self.XN1_A_HOLD)
                taps += 1
                last_tap = time.time()
                next_tap = last_tap + max(0.0, self.XN1_A_EVERY - self.XN1_A_HOLD)
            self.task.next_frame()
            now = time.time()
            if self.hud_ok():
                full, L, R = self.xn_ying()
                if len(trace) < 30:
                    trace.append(f'{now - arrived:.2f}:{"满" if full else ""}{L:.2f}/{R:.2f}')
                if full or L >= self.XN_GAUGE_VALID:
                    valid_seen = True
                hits = hits + 1 if (full or (L >= self.XN_GAUGE_VALID and R >= self.XN_YING_READY)) else 0
                if hits >= self.XN1_GATE_CONFIRM and ready_at is None:
                    ready_at = now
                    self.macro_mark(f'{tag}应世心满({"花" if full else f"{R:.2f}"},A x{taps},{now - arrived:.2f}s)')
            if ready_at is not None and now >= arrived + self.XN1_HOLD_AT_MIN:
                why = 'ready'
                break
            if now >= arrived + self.XN1_A_CAP:
                why = 'cap' if valid_seen else 'blind'
                break
            self.macro_wait(0.02)
        if why != 'ready':
            self.macro_mark(f'{tag}应世心{"不够" if why == "cap" else "读不到"}(照按,A x{taps})')
            self.logger.info(f'{tag}: 应世心 {why} — {" ".join(trace)}')
        left = last_tap + self.XN1_LAST_A_GAP - time.time()
        if left > 0:
            self.macro_wait(left)
        return why

    def seg_xn1(self, tag):
        """心·第一段(雷主变奏进来, 应世相): Q -> A 到应世心满 -> 按住出步红尘 -> 转相解锁 -> 转相 -> 演完。"""
        arrived = getattr(self, 'last_switch_in_time', 0.0) or time.time()
        if not self.has_intro:
            self.macro_mark(f'{tag}心不是变奏进来的(应世心少 60)')
        self.wait_until_time(arrived + self.XN1_Q_AT)
        self.spam_key(self.send_echo_key, self.XN1_Q_WINDOW, tag=f'{tag}Q', presses=2)
        self.record_echo_use()
        if self.xn_form(tag) == 'zhao':
            self.logger.warning(f'{tag}: 心上场还在照世相(上一圈万阙垂天没放出来), 第一段跳过步红尘/转相')
            return 'zhao'
        self.xn1_fill(arrived, tag)

        state = 'unknown'
        hold_at = burned_at = None
        for attempt in range(1 + self.XN1_RETRIES):
            if attempt > 0:
                for _ in range(self.XN1_RETRY_A):
                    self.tap(self.XN1_A_HOLD)
                    self.macro_wait(self.XN1_FILL_EVERY)
                self.macro_mark(f'{tag}重击重按#{attempt}')
            state, burned_at, hold_at = self.xn_hold_burn(f'{tag}重击' if attempt == 0 else f'{tag}重击#{attempt}')
            if state != 'full':
                break
        if state == 'full':
            self.logger.warning(f'{tag}: 重按 {self.XN1_RETRIES} 次应世心都没清空(步红尘没出), 转相多半放不出来')

        if burned_at is not None:
            self.wait_until_time(burned_at + self.XN1_R1_POLL_FROM)
            due = burned_at + self.XN1_R1_UNLOCK + self.XN1_R1_MARGIN
            why = '到点'
            while time.time() < due:
                self.task.next_frame()
                if self.hud_ok() and self.xn_r1_ready():
                    why = '亮'
                    break
                self.macro_wait(0.01)
            self.macro_mark(f'{tag}转相解锁({why},清空后{time.time() - burned_at:.2f}s)')
        else:
            cap_at = hold_at + self.XN1_R1_LIT_CAP
            blind_at = hold_at + self.XN1_R1_BLIND_AT
            hits = 0
            lit = False
            while time.time() < cap_at:
                self.task.next_frame()
                if self.hud_ok():
                    hits = hits + 1 if self.xn_r1_ready() else 0
                    if hits >= self.XN1_R1_READS:
                        lit = True
                        break
                if time.time() >= blind_at:
                    break
                self.macro_wait(0.02)
            self.macro_mark(f'{tag}转相{"亮" if lit else "没读到亮"}(没看到清空)')
        fired = self.fire_r(self, f'{tag}转相', self.XN_R_WINDOW)
        if not fired:
            fired = self.xn_r1_rescue(self, tag)
        if not fired:
            self.logger.warning(f'{tag}: 补了 {self.XN1_R1_RESCUE_CAP:.0f}s 转相还是没放出去, 这一圈没有照世相')
            return 'nor1'
        self.wait_hud_back(tag=f'{tag}转相演出', min_gone=self.XN_R_ANIM_MIN, time_out=self.XN_R_ANIM_CAP)
        return 'r1'

    def xn_break(self, tag):
        """统御众机里处决: 只按 F(最多 XN_BREAK_PRESSES 下, 提示没了就停), 从第一下起等满 XN_BREAK_ANIM。"""
        start = time.time()
        presses = 0
        while presses < self.XN_BREAK_PRESSES:
            self.task.send_key('f', down_time=0.05)
            presses += 1
            self.macro_wait(0.10)
            self.task.next_frame()
            if not self.break_prompt():
                break
        try:
            self.task.can_break = False
        except Exception:
            pass
        self.macro_wait(max(0.0, start + self.XN_BREAK_ANIM - time.time()))
        self.macro_mark(f'{tag}处决(F x{presses},{time.time() - start:.2f}s)')
        return time.time() - start

    def xn_lianheng(self, tag, waited=0.0):
        """E(照世相)之后连按 E: 照世心满 300 的那一刻 E 是万阙连衡, 按出去进统御众机。返回进没进。"""
        start = time.time()
        n = hits = na = 0
        next_e = next_a = 0.0
        scores = []
        while time.time() - start < self.XN2_LIANHENG_CAP:
            now = time.time()
            if now >= next_e:
                self.send_resonance_key(down_time=self.M_E_KEY_DOWN)
                n += 1
                next_e = time.time() + self.XN2_E_MASH
            elif now - start >= self.XN2_LIANHENG_POKE_AT - waited and now >= next_a:
                self.tap()
                na += 1
                next_a = time.time() + self.XN2_LIANHENG_A_EVERY
            self.task.next_frame()
            ty = self.xn_tongyu()
            if len(scores) < 30:
                scores.append(f'{time.time() - start:.2f}:{getattr(self, "_ty_score", -1):.2f}')
            hits = hits + 1 if ty else 0
            if hits >= self.XN2_TY_CONFIRM:
                self.macro_mark(f'{tag}进统御众机(E x{n},A x{na},{time.time() - start:.2f}s)')
                return True
            self.macro_wait(0.02)
        self.macro_mark(f'{tag}强化E没进统御众机(E x{n},A x{na},{self.XN2_LIANHENG_CAP:.1f}s)')
        self.logger.info(f'{tag}: 雕像图标读数 — {" ".join(scores)}')
        r0 = time.time()
        rounds = 0
        while time.time() - r0 < self.XN2_RESCUE_CAP:
            rounds += 1
            self.macro_spam(self.XN2_RESCUE_A, self.XN2_A_EVERY, tag=f'{tag}攒照世心A#{rounds}')
            end = time.time() + self.XN2_RESCUE_E
            hits = 0
            while time.time() < end:
                self.send_resonance_key(down_time=self.M_E_KEY_DOWN)
                self.macro_wait(0.05)
                self.task.next_frame()
                hits = hits + 1 if self.xn_tongyu() else 0
                if hits >= self.XN2_TY_CONFIRM:
                    self.macro_mark(f'{tag}补进统御众机(#{rounds},{time.time() - start:.2f}s)')
                    return True
                self.macro_wait(max(0.0, self.XN2_E_MASH - 0.05))
        self.macro_mark(f'{tag}统御众机补救(cap,{rounds}轮)')
        return False

    def xn_statue_reset(self):
        self._statue_streak = [0] * len(self.XN_STATUE_XS)
        self._statue_latch = [False] * len(self.XN_STATUE_XS)

    def xn_statue_count(self):
        """照世心雕像从右往左连续翻了几颗。读当前帧。"""
        frame = self.task.frame
        hw = self.XN_STATUE_HW
        for k, x in enumerate(self.XN_STATUE_XS):
            if self._statue_latch[k]:
                continue
            red = glow = 0.0
            for y, kind in ((self.XN_STATUE_Y, 'red'), (self.XN_STATUE_UP_Y, 'glow')):
                box = self.task.box_of_screen_scaled(3840, 2160, x - hw, y - hw, x + hw, y + hw, hcenter=True)
                crop = frame[box.y:box.y + box.height, box.x:box.x + box.width, :3]
                if crop.size == 0:
                    continue
                hsv = cv2.cvtColor(np.ascontiguousarray(crop), cv2.COLOR_BGR2HSV)
                h, sat, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
                if kind == 'red':
                    red = float((((h < 12) | (h > 160)) & (sat > 90) & (v > 110)).mean())
                else:
                    glow = float(((v > 235) & (sat < 60)).mean())
            hit = red >= self.XN_STATUE_RED or glow >= self.XN_STATUE_GLOW
            self._statue_streak[k] = self._statue_streak[k] + 1 if hit else 0
            if self._statue_streak[k] >= self.XN_STATUE_CONFIRM:
                self._statue_latch[k] = True
        n = 0
        for latched in reversed(self._statue_latch):
            if not latched:
                break
            n += 1
        return n

    def xn_tongyu_phase(self, tag, cap, dodge_at=None):
        """统御众机里一直普攻到重击位换成人像(照世心打空)。dodge_at: 给了就闪避一次。

        【闪避的时机 = 照世心雕像翻满 XN2_TY_DODGE_COUNT 颗】; 有处决提示就处决(代替闪避)。
        """
        start = time.time()
        n = 0
        next_click = 0.0
        dodged = dodge_at is None
        ready_hits = brk_hits = 0
        prompt_at = None
        count = last_count = 0
        counts = []
        self.xn_statue_reset()
        why = 'cap'
        last = None
        while time.time() - start < cap:
            now = time.time()
            if now >= next_click:
                self.tap()
                n += 1
                next_click = time.time() + max(0.0, self.XN2_TY_A_EVERY - self.A_TAP)
            self.task.next_frame()
            st = self.xn_slot_state()
            last = st
            ready_hits = ready_hits + 1 if st == 'ready' else 0
            if ready_hits >= self.XN2_READY_CONFIRM:
                why = 'ready'
                break
            el = time.time() - start
            if st is not None:
                try:
                    count = self.xn_statue_count()
                except Exception as e:
                    self.logger.info(f'xn_statue_count failed ({e})')
                if count != last_count:
                    last_count = count
                    if len(counts) < 12:
                        counts.append(f'{count}@{el:.2f}')
            prompt = False
            if self.XN_BREAK and not self.xn_broke and st is not None and el >= self.XN_BREAK_FROM:
                brk_hits = brk_hits + 1 if self.break_prompt() else 0
                prompt = brk_hits >= self.XN_BREAK_CONFIRM
                if prompt and prompt_at is None:
                    prompt_at = time.time()
                    self.macro_mark(f'{tag}处决提示({el:.2f}s,翻{count})')
            if dodged and prompt:
                self.xn_broke = True
                self.macro_mark(f'{tag}统御众机A(x{n},{el:.2f}s,翻{count})')
                self.xn_break(tag)
                continue
            if not dodged and el >= self.XN2_TY_DODGE_MIN and (
                    count >= self.XN2_TY_DODGE_COUNT or el >= self.XN2_TY_DODGE_CAP):
                dodged = True
                self.macro_mark(f'{tag}统御众机A(x{n},{el:.2f}s,翻{count}'
                                f'{"" if count >= self.XN2_TY_DODGE_COUNT else ",数不到撞上限"})')
                use_break = False
                if self.XN_BREAK and not self.xn_broke and prompt_at is not None and \
                        time.time() - prompt_at <= self.XN2_TY_PROMPT_KEEP:
                    use_break = prompt or self.break_prompt_reads(3)
                if use_break:
                    self.xn_broke = True
                    self.xn_break(tag)
                else:
                    self.dodge(tag)
                    self.macro_wait(self.XN2_DODGE_TO_A)
                continue
            self.macro_wait(0.01)
        self.macro_mark(f'{tag}照世心{"打空" if why == "ready" else "没看到打空(cap)"}'
                        f'(A x{n},{time.time() - start:.2f}s)')
        if counts:
            self.logger.info(f'{tag}: 照世心雕像翻面(颗@秒) — {" ".join(counts)}')
        if why != 'ready':
            self.logger.info(f'{tag}: {cap:.1f}s 没看到重击位换人像(最后读成 {last}, '
                             f'雕像{getattr(self, "_ty_score", -1):.2f} 人像{getattr(self, "_rd_score", -1):.2f})')
        return why

    def seg_xn2(self, bl, opener, state, tag):
        """心·第二段(转相演完接着打, 照世相)。state: 'nor1' 就跳过照世相这套, 补满协奏交棒。"""
        if state == 'nor1':
            self.macro_mark(f'{tag}没转相, 跳过照世相')
            self.xn_handoff(bl, tag)
            return
        self.wait_hud_up(cap=self.HUD_UP_CAP, tag=f'{tag}HUD')
        self.macro_spam(self.XN2_3A if opener else self.XN2_2A, self.XN2_A_EVERY,
                        tag=f'{tag}{"3A" if opener else "2A"}')
        e_ok = self.press_res_until_cd(self, self.XN2_E1_CAP, tag=f'{tag}E')
        if not e_ok:
            self.logger.info(f'{tag}: 照世相 E 没判到进 CD')
        self.record_resonance_use()
        waited = 0.0
        if not opener and e_ok:
            self.macro_wait(self.XN2_E_FULL)
            waited = self.XN2_E_FULL
            self.macro_mark(f'{tag}等普通E打完({waited:.2f}s)')
        in_ty = self.xn_lianheng(tag, waited)
        self.xn_broke = False
        if in_ty:
            why = self.xn_tongyu_phase(tag, self.XN2_TY_CAP, dodge_at=True)
            fired = self.xn_hold_until_gone(self.XN2_HOLD_CAP if why == 'ready' else self.XN2_BLIND_HOLD,
                                            f'{tag}按住')
            for attempt in range(1, 1 + self.XN2_RETRIES):
                if fired:
                    break
                why = self.xn_tongyu_phase(f'{tag}补#{attempt}', self.XN2_RETRY_CAP)
                fired = self.xn_hold_until_gone(self.XN2_HOLD_CAP if why == 'ready' else self.XN2_BLIND_HOLD,
                                                f'{tag}重按#{attempt}')
        else:
            fired = self.xn_hold_until_gone(self.XN2_BLIND_HOLD, f'{tag}按住(试探)')
        if not fired:
            self.logger.warning(f'{tag}: 临寰宇一直没出手(统御众机{"进了" if in_ty else "没进"}), '
                                f'这一轮不放万阙垂天(按 R 会放成借相)')
        else:
            self.wait_hud_back(tag=f'{tag}临寰宇演出', min_gone=self.XN2_ANIM_MIN, time_out=self.XN2_ANIM_CAP)
            # 【图标没出来就平a补能量】(用户 2026-10-08): "心最后一段大招能量老是差一点放不出来,
            # 能不能加点保底机制, 放不出来就平a补能量"。
            # 这里原来只是干等 XN2_LIB2_CAP(1.5s), 什么都不做, 所以能量差一点就整轮放弃。
            # 现在【一边点平a攒共鸣能量一边读图标】, 图标(万阙垂天解锁)一亮立刻停手去按 R;
            # 上限 XN2_LIB2_CAP 到了还不亮就不按(按了会放成借相)。
            start = time.time()
            hits = 0
            unlocked = False
            taps = 0
            next_tap = 0.0
            while time.time() - start < self.XN2_LIB2_CAP:
                now = time.time()
                if now >= next_tap:
                    self.tap()
                    taps += 1
                    next_tap = time.time() + max(0.0, self.XN2_LIB2_POKE - self.A_TAP)
                self.task.next_frame()
                if self.hud_ok():
                    hits = hits + 1 if self.xn_icon('hsin_lib2') else 0
                    if hits >= self.XN2_LIB2_READS:
                        unlocked = True
                        break
                self.macro_wait(0.02)
            self.macro_mark(f'{tag}万阙垂天{"解锁" if unlocked else "图标没出来(不按, 免得放成借相)"}'
                            f'({time.time() - start:.2f}s,补A x{taps})')
            if unlocked:
                self.xn_pre_r2_con(tag)
                if self.fire_r(self, f'{tag}万阙垂天', self.XN_R_WINDOW):
                    self.wait_hud_back(tag=f'{tag}万阙垂天演出', min_gone=self.XN_R_ANIM_MIN,
                                       time_out=self.XN_R_ANIM_CAP)
                else:
                    self.logger.warning(f'{tag}: 万阙垂天没放出去(能量不够?)')
            else:
                self.logger.warning(f'{tag}: 临寰宇之后 {self.XN2_LIB2_CAP:.1f}s 没认出万阙垂天图标, 这一轮不放'
                                    f'(心留在照世相, 下一圈第一段会跳过转相)')
        self.xn_handoff(bl, tag)

    def xn_handoff(self, bl, tag):
        """协奏满 -> 变奏卜灵。补协奏只点普攻(万阙垂天之后按 E 会把电磁效应层数一次结算掉)。"""
        full = self.read_con(1.0, settle=0.20) >= 1.0 or self.wait_con_full('心', self.XN2_CON_CAP,
                                                                            tag=f'{tag}协奏')
        if not full:
            self.logger.warning(f'{tag}: 心协奏没满就切卜灵 —— 卜灵不是变奏进来的, 下一圈第一格卦象要从头攒')
        self.need(self.switch_after_anim(bl, f'{tag}切卜灵', assume_con=full), 'hsin -> douling')

    # ==================== 一圈 ====================
    # 【用户文字轴】(a=平a, z=重击长按, q=声骸, r=大招; 主语延续到切换为止):
    #   启动轴: 雷a1 | 卜a1a2ea跳a | 雷(空中切进来)落地aa | 卜zz | 雷a1a2a3 | 卜qr
    #           | 变奏雷qre下落a强e | 变奏心 a1zqr a1ee a1a2a3处决/闪 a1a2zr
    #   循环轴: 去掉最前面那个"雷a1", 其余相同。
    # 【雷主上场三次, 卜灵上场三次, 然后心两段】

    def run_cycle(self, lei, bl, opener, tag):
        """一圈。

        【2026-10-08 修的崩溃】: 这里原来写 self.LEI2_A_EVERY, 但那个常量在重写雷主两格时被
        LEI2_AIR_TAP_EVERY 取代了 -> AttributeError, 宏跑到这一格直接停(用户看到的"雷主罚站")。
        现在 LEI2_A_EVERY 是【第三格 a1a2a3】的间隔, 定义在常量区, 不再依赖已删的名字。
        """
        marks = len(self.macro_marks)
        self.timeline_logged = False
        if opener:
            self.seg_lei0(lei, tag=f'{tag}雷0')          # 雷 a1 (仅启动轴)
        self.seg_bl1(bl, lei, tag=f'{tag}卜1')           # 卜 a1a2ea跳a (末尾人在空中)
        self.seg_lei1(bl, tag=f'{tag}雷1')               # 雷 空中切进来 -> 下落 -> a1a2a3
        self.seg_bl2(bl, lei, tag=f'{tag}卜2')           # 卜 zz
        self.seg_lei2(bl, tag=f'{tag}雷2')               # 雷 a1a2a3
        self.seg_bl3(bl, lei, tag=f'{tag}卜3')           # 卜 qr -> 变奏雷
        self.seg_lei3(tag=f'{tag}雷3')                   # 雷 q r e 下落a 强e -> 变奏心
        state = self.seg_xn1(tag=f'{tag}心1')
        self.seg_xn2(bl, opener, state, tag=f'{tag}心2')
        self.logger.info(f'{tag} cycle timeline: {self.macro_timeline(marks)}')
        self.timeline_logged = True

    def macro_enter(self, entry_char):
        lei = self.teammate('Rover')
        bl = self.teammate('Douling')
        if lei is None or bl is None:
            # 【一定要打日志】: 上一版这里静默 return None, 表现是"按了 F 什么都不发生"、日志里一条都没有。
            self.logger.warning(
                f'xlb: 队友没找齐 (Rover={getattr(lei, "name", lei)}, '
                f'Douling={getattr(bl, "name", bl)}); '
                f'chars = {[getattr(c, "name", None) for c in self.task.chars if c is not None]}')
            return None
        previous = getattr(self.task, 'skip_combat_check', False)
        self.task.skip_combat_check = True
        self.mark_busy(True)
        self.cur = entry_char or self.on_field_char() or self
        for char in (self, lei, bl):
            char.check_f_on_switch = False
        self.macro_start()
        self.timeline_logged = False
        self.hud_seen_at = time.time()
        self.hud_watch = True
        self.combat_watch = True          # 【锁不到敌就停】的看门狗(见 macro_mark)
        self.combat_checked_at = 0.0
        self.combat_gone_hits = 0
        # 新的一圈开始了: 上一圈记下的 HUD 断档已经用掉(见 maybe_rearm_after_interrupt)
        self.hud_gone_since = 0.0
        self.hud_outage_last = 0.0
        return lei, bl, previous

    def macro_exit(self, previous):
        """唯一保证松手的地方 —— 中途抛异常也不能让鼠标一直按着。"""
        # 【战斗中断重开】的计时起点: 整圈交回框架这一刻(见 maybe_rearm_after_interrupt)
        self.last_cycle_end = time.time()
        # 【只认"整圈之外"的 HUD 断档】: 卜灵 R 演出时 HUD 会被盖住 3~4 秒, 那是圈内的正常现象,
        # 不能算"中断"。这里把它清掉; 圈外一直没 HUD 的话 hud_gone_since 还在, HUD 回来时
        # hud_ok() 会重新算出整段断档时长, 那才是退出副本/过场。
        self.hud_outage_last = 0.0
        try:
            self.release_attack()
        except Exception:
            pass
        try:
            if not self.timeline_logged and self.macro_marks:
                self.logger.info(f'xlb timeline (没跑完): {self.macro_timeline()}')
                self.timeline_logged = True
        except Exception:
            pass
        self.hud_watch = False
        self.combat_watch = False
        try:
            self.task.skip_combat_check = previous
        except Exception:
            pass
        try:
            self.mark_busy(False)
        except Exception:
            pass

    def perform_opener(self, entry_char=None):
        """启动轴: 雷主起手 a1 -> 一圈。"""
        got = self.macro_enter(entry_char)
        if got is None:
            return False
        lei, bl, previous = got
        self.logger.info(f'xlb opener entry: {self.cur.name}')
        try:
            self.loop_count = 0
            self.run_cycle(lei, bl, opener=True, tag='op')
            self.logger.info(
                f'xlb opener total {self.time_elapsed_accounting_for_freeze(self.macro_t0):.2f}s '
                f'(wall {time.time() - self.macro_t0:.2f}s)')
        except MacroBroken as e:
            self.logger.warning(f'xlb opener broke ({e}) — timeline: {self.macro_timeline()}')
            self.timeline_logged = True
        except Exception as e:
            # 【绝不能让它冒出去】: 冒出去 = 框架判定 Auto Combat exception stopped = 整局不动。
            self.logger.error(f'xlb opener 异常({type(e).__name__}: {e}) — 已吞掉, 交回框架',
                              exc_info=True)
            self.timeline_logged = True
        finally:
            self.macro_exit(previous)
        return True

    def perform_loop(self, entry_char=None):
        """循环轴一圈(没有最前面那个雷主起手 a1)。"""
        got = self.macro_enter(entry_char)
        if got is None:
            return False
        lei, bl, previous = got
        try:
            self.loop_count += 1
            n = self.loop_count
            self.run_cycle(lei, bl, opener=False, tag=f'L{n}')
            self.logger.info(
                f'xlb loop #{n} {self.time_elapsed_accounting_for_freeze(self.macro_t0):.2f}s '
                f'(wall {time.time() - self.macro_t0:.2f}s)')
        except MacroBroken as e:
            self.logger.warning(f'xlb loop broke ({e}) — timeline: {self.macro_timeline()}')
            self.timeline_logged = True
        except Exception as e:
            self.logger.error(f'xlb loop 异常({type(e).__name__}: {e}) — 已吞掉, 交回框架',
                              exc_info=True)
            self.timeline_logged = True
        finally:
            self.macro_exit(previous)
        return True
    # ==================== 框架接口 ====================

    def drive(self, entry):
        """三个人的 do_perform 都走这里。entry = 框架这次调的是谁(= 场上是谁)。"""
        if not self.wait_hud_up(cap=self.DRIVE_HUD_CAP, tag='drive'):
            if time.time() - self.drive_log_at > 10:
                self.drive_log_at = time.time()
                self.logger.info('xlb: 队伍 HUD 不在(结算/过场/窗口没了?), 宏不动')
            return None
        # 【战斗中断 -> 轴重新开始】: 过场/退出副本/长时间脱战之后, 下一场从启动轴重来
        self.maybe_rearm_after_interrupt()
        blocked = self.opener_blocked_by()
        if blocked is None:
            # 标记要在跑之前落: 中途抛异常(脱战/任务被停)也不能让启动轴重跑
            self.opener_armed = False
            self.last_opener = time.time()
            return self.perform_opener(entry)
        self.logger.info(f'xlb: opener not pending ({blocked}), running the loop')
        return self.perform_loop(entry)

    def do_perform(self):
        """【最外层兜底】: 任何异常都不许冒到框架。

        冒出去就是 Auto Combat exception stopped(2026-10-08 01:43 那次就是这么整局不动的),
        之后再按 F 也不会复活 —— F 只能给运行中的任务重新武装启动轴。
        """
        try:
            if not self.is_in_xlb:
                return super().do_perform()
            self.drive(self)
        except MacroBroken as e:
            self.logger.warning(f'xlb: do_perform 中断 ({e})')
            try:
                self.release_attack()
            except Exception:
                pass
        except Exception as e:
            self.logger.error(f'xlb: do_perform 异常({type(e).__name__}: {e}) — 已吞掉, 不让框架停任务',
                              exc_info=True)
            try:
                self.release_attack()
            except Exception:
                pass

    def get_switch_priority(self, current_char=None, has_intro=False, target_low_con=False):
        """启动轴待跑时不让框架把心切上来(宏自己切)。"""
        try:
            if self.is_in_xlb and self.opener_pending():
                return SwitchPriority.NO
        except Exception:
            pass
        return super().get_switch_priority(current_char, has_intro, target_low_con)

    def on_combat_end(self, chars):
        try:
            self.release_attack()
        except Exception:
            pass
        # 【战斗判定结束 -> 强制切雷主】(用户 2026-10-08)
        # 看门狗已经切过的话这里是空操作(读一帧看人在雷主身上就直接返回)。
        self.lei_force_main('战斗结束')
        return super().on_combat_end(chars)