"""
赞菲光固定轴 V4.4 - Phoebe（菲比）

定位：
- V4.4与V4.3_rev1在本角色上的执行逻辑一致；仅同步版本标识与共享PRECAST状态注释。
- V4.3把HARD_GATE / SOFT_COMMIT确认分层扩展到P2：告解、R、Star、特殊E等主真值门继续强确认，普通E/Q/机会动作输入提交即推进。
- V4.3把菲比E拆成显式E1/E2图标识别：仅E1图标允许按E，E2图标绝不追按；不再使用PENDING/DEFERRED_RECOVERY猜测。
- P1开场改为菲比告解R-E1-Q -> 光主E-Q-R -> 赞妮E-A -> 菲比；P1 N1后改为Star -> E1 -> 赞妮，取消额外3A。
- P2 Z1/Z2特殊变奏归属锁定继续保留；P2菲比E1、光主机会E/Q与赞妮R窗机会E/Q下放SOFT_COMMIT。
"""


import time
import base64
import cv2
import numpy as np

from src.char.BaseChar import SwitchPriority, Elements
from src.char.Phoebe import Phoebe as BuiltinPhoebe


class _ZFGFSM:
    ACTOR = None

    STATE_KEY = 'zanfei_rotation_state'  # 共享FSM主体：step/phase/cycle等都放这里
    TEAM_SIGNATURE_KEY = 'zanfei_rotation_team_signature'  # 队伍变化检测；换队后重置固定轴
    SWITCH_LOG_KEY = 'zanfei_rotation_switch_logged'  # 避免重复刷同一条切人日志
    PHOEBE_PREHOLD_E_KEY = 'phoebe_prehold_e_active'  # 跨角色按住E：是否仍应保持按键
    PHOEBE_PREHOLD_SOURCE_KEY = 'phoebe_prehold_e_source'  # 记录是谁发起的预输入，便于查日志
    P1_PHOEBE_FORTE_EXPECTED_EMPTY_KEY = 'p1_phoebe_forte_expected_empty'
    P1_PHOEBE_E1_PENDING_KEY = 'p1_phoebe_e1_pending'
    P1_PHOEBE_E1_CONFIRMED_KEY = 'p1_phoebe_e1_confirmed'
    P1_PHOEBE_E1_INPUT_AT_KEY = 'p1_phoebe_e1_input_at'
    P1_PHOEBE_E1_RECOVERY_ATTEMPTED_KEY = 'p1_phoebe_e1_recovery_attempted'

    # P1/P2第一次Z后的赞妮quick-swap：普通E -> A/resource -> 强化E预释放 -> 切菲比。
    ZANI_PRE_R_PREP_SLICE_DONE_KEY = 'zani_pre_r_prep_slice_done'  # 赞妮quick-swap：本次PRECAST是否已结束并切回菲比
    ZANI_PRE_R_EFORTE_READY_KEY = 'zani_pre_r_eforte_ready'  # 赞妮强化E：PRECAST过程中是否观察到强化E READY
    ZANI_PRE_R_RETURN_STEP_KEY = 'zani_pre_r_return_step'  # 赞妮quick-swap：切回菲比后恢复到哪个STEP
    ZANI_PRE_R_RETURN_PHASE_KEY = 'zani_pre_r_return_phase'  # 赞妮quick-swap：切回菲比后恢复到STEP内哪个phase
    ZANI_PRE_R_PREP_SOURCE_KEY = 'zani_pre_r_prep_source'  # 赞妮quick-swap：记录本次PRECAST来自P1还是P2流程
    ZANI_PRE_R_PRECAST_E_ATTEMPTED_KEY = 'zani_pre_r_precast_e_attempted'  # 赞妮强化E：是否已开始尝试释放
    ZANI_PRE_R_PRECAST_E_CONSUMED_KEY = 'zani_pre_r_precast_e_consumed'  # 赞妮强化E识别：READY稳定消失或专属Buff连续2帧，任一成功即确认已释放
    ZANI_PRE_R_PRECAST_NORMAL_E_LAST_CAST_KEY = 'zani_pre_r_precast_normal_e_last_cast'  # 赞妮普通E：quick-swap最近一次成功释放时间
    ZANI_PRE_R_PRECAST_NORMAL_E_CASTS_KEY = 'zani_pre_r_precast_normal_e_casts'  # 赞妮普通E：本次quick-swap已成功释放次数
    P2_FIRST_Z_INTRO_USED_KEY = 'p2_first_z_intro_used'  # P2赞妮Z1/Z2：特殊变奏归属锁；True=Z1特殊/Z2普通，False=Z1普通/Z2特殊
    P2_ZANI_PRECHARGE_SEEDED_KEY = 'p2_zani_precharge_seeded'  # 上一轮R2后赞妮EA：是否已为下一轮P2完成强化E资源预充

    PHOEBE_LAST_CONFESSION_TIME_KEY = 'phoebe_last_confession_time'
    PHOEBE_LAST_R_CAST_TIME_KEY = 'phoebe_last_r_cast_time'
    P2_CONFESSION_AZ_USED_KEY = 'p2_confession_az_detour_used'  # 兼容旧日志：本轮是否至少走过一次光主等待槽
    P2_CONFESSION_AZ_COUNT_KEY = 'p2_confession_az_count'
    P2_CONFESSION_AZ_TARGET_KEY = 'p2_confession_az_target'
    P2_CONFESSION_RETRY_AFTER_KEY = 'p2_confession_retry_after'

    PHOEBE_R_COOLDOWN = 25.0
    ZANI_R2_HARD_DEADLINE_SHARED = 19.50
    P2_CONFESSION_R2_RESERVE = 6.00  # 给告解+R动画+切赞妮+N3/R2留出的尾端保护
    P2_CONFESSION_AZ_COST = 0.85
    P2_CONFESSION_SWITCH_TOTAL = 0.35
    P2_CONFESSION_PLAN_SAFETY = 0.25
    P2_CONFESSION_MAX_AZ = 6


    # P1开头按V4.3真实执行顺序排列：菲比 -> 光主 -> 赞妮 -> 菲比
    STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER = 'P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER'
    STEP_P1_ZANI_OPEN_EA_TO_PHOEBE = 'P1_ZANI_OPEN_EA_TO_PHOEBE'
    STEP_P1_ROVER_EQR_TO_ZANI = 'P1_ROVER_EQR_TO_ZANI'
    STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI = 'P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI'
    STEP_P1_ZANI_PRE_R_PREP_SLICE = 'P1_ZANI_PRE_R_PREP_SLICE'

    STEP_P1_ZANI_EFORTE_PREP = 'P1_ZANI_EFORTE_PREP'
    STEP_P1_ZANI_R1_N1_TO_ROVER = 'P1_ZANI_R1_N1_TO_ROVER'
    STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE = 'P1_ROVER_OPPORTUNITY_E_TO_PHOEBE'
    STEP_P1_PHOEBE_STAR_E1_TO_ZANI = 'P1_PHOEBE_STAR_E1_TO_ZANI'
    STEP_P1_ZANI_N2_TO_ROVER_R = 'P1_ZANI_N2_TO_ROVER_R'
    STEP_P1_ROVER_R_TO_ZANI = 'P1_ROVER_R_TO_ZANI'
    STEP_P1_ZANI_N3_TO_PHOEBE = 'P1_ZANI_N3_TO_PHOEBE'
    STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI = 'P1_PHOEBE_CONFESSION_R_TO_ZANI'
    STEP_P1_ZANI_N4_R2_EA_TO_PHOEBE = 'P1_ZANI_N4_R2_EA_TO_PHOEBE'

    STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI = 'P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI'
    STEP_P2_ZANI_PRE_R_PREP_SLICE = 'P2_ZANI_PRE_R_PREP_SLICE'
    STEP_P2_ZANI_EFORTE_PREP = 'P2_ZANI_EFORTE_PREP'
    STEP_P2_ZANI_R1_N1_TO_ROVER = 'P2_ZANI_R1_N1_TO_ROVER'
    STEP_P2_ROVER_SLOT_TO_ZANI = 'P2_ROVER_SLOT_TO_ZANI'
    STEP_P2_ZANI_N2_TO_PHOEBE = 'P2_ZANI_N2_TO_PHOEBE'

    STEP_P2_PHOEBE_CONFESSION_CHECK = 'P2_PHOEBE_CONFESSION_CHECK'
    STEP_P2_ROVER_AZ_WAIT_CONFESSION = 'P2_ROVER_AZ_WAIT_CONFESSION'
    STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI = 'P2_PHOEBE_CONFESSION_R_TO_ZANI'
    STEP_P2_ZANI_N3_R2_EA_TO_PHOEBE = 'P2_ZANI_N3_R2_EA_TO_PHOEBE'

    STEP_RECOVER_ZANI_LIBERATION = 'RECOVER_ZANI_LIBERATION'
    STEP_RECOVER_P2_PHOEBE = 'RECOVER_P2_PHOEBE'

    STEP_ACTOR = {
        STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER: 'Phoebe',
        STEP_P1_ZANI_OPEN_EA_TO_PHOEBE: 'Zani',
        STEP_P1_ROVER_EQR_TO_ZANI: 'Rover',
        STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI: 'Phoebe',
        STEP_P1_ZANI_PRE_R_PREP_SLICE: 'Zani',

        STEP_P1_ZANI_EFORTE_PREP: 'Zani',
        STEP_P1_ZANI_R1_N1_TO_ROVER: 'Zani',
        STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE: 'Rover',
        STEP_P1_PHOEBE_STAR_E1_TO_ZANI: 'Phoebe',
        STEP_P1_ZANI_N2_TO_ROVER_R: 'Zani',
        STEP_P1_ROVER_R_TO_ZANI: 'Rover',
        STEP_P1_ZANI_N3_TO_PHOEBE: 'Zani',
        STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI: 'Phoebe',
        STEP_P1_ZANI_N4_R2_EA_TO_PHOEBE: 'Zani',

        STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI: 'Phoebe',
        STEP_P2_ZANI_PRE_R_PREP_SLICE: 'Zani',
        STEP_P2_ZANI_EFORTE_PREP: 'Zani',
        STEP_P2_ZANI_R1_N1_TO_ROVER: 'Zani',
        STEP_P2_ROVER_SLOT_TO_ZANI: 'Rover',
        STEP_P2_ZANI_N2_TO_PHOEBE: 'Zani',
        STEP_P2_PHOEBE_CONFESSION_CHECK: 'Phoebe',
        STEP_P2_ROVER_AZ_WAIT_CONFESSION: 'Rover',
        STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI: 'Phoebe',
        STEP_P2_ZANI_N3_R2_EA_TO_PHOEBE: 'Zani',

        STEP_RECOVER_ZANI_LIBERATION: 'Zani',
        STEP_RECOVER_P2_PHOEBE: 'Phoebe',
    }

    SPECIAL_INTRO_TARGET = {
        'Phoebe': 'Zani',
        'Zani': 'Rover',
        'Rover': 'Phoebe',
    }

    CONCERTO_EFFECTIVE_FULL = 0.99
    INTRO_CONFIRM_FRAMES = 3
    INTRO_CONFIRM_TIMEOUT = 1.0
    POLL = 0.05

    SWITCH_TIMEOUT = 6.0
    SWITCH_RETRY_INTERVAL = 0.04

    def _release_phoebe_prehold(self, state, reason='cleanup'):
        if not isinstance(state, dict) or not state.get(self.PHOEBE_PREHOLD_E_KEY):
            return False
        try:
            self.task.send_key_up(self.get_resonance_key())
        except Exception:
            pass
        source = state.pop(self.PHOEBE_PREHOLD_SOURCE_KEY, None)
        state.pop(self.PHOEBE_PREHOLD_E_KEY, None)
        self.logger.info(
            f'ZFG Phoebe-E prehold RELEASE reason={reason} source={source}'
        )
        return True

    def _reedge_phoebe_prehold_on_entry(self, target_name, has_intro=False):
        """V4.3: Phoebe预输入E在切人确认首帧做一次UP->DOWN重新沿触发。

        赞妮侧的跨角色key_down负责把E提前送进输入队列；但部分实机会在角色切换期间
        吞掉持续按键的首个触发。确认current_index已经变成Phoebe后，立刻重建一次
        按键边沿，让告解长按尽可能从菲比登场首帧开始。特殊变奏入场不做此操作。
        """
        if target_name != 'Phoebe' or has_intro:
            return False

        state = getattr(self.task, self.STATE_KEY, None)
        if not isinstance(state, dict) or not state.get(self.PHOEBE_PREHOLD_E_KEY):
            return False

        try:
            key = self.get_resonance_key()
            self.task.send_key_up(key)
            self.task.send_key_down(key)
            self.logger.info(
                f'ZFG V4.4 Phoebe-E PREHOLD re-edge on entry source='
                f'{state.get(self.PHOEBE_PREHOLD_SOURCE_KEY)}'
            )
            return True
        except Exception as exc:
            self.logger.warning(
                f'ZFG V4.4 Phoebe-E PREHOLD re-edge failed: {exc}'
            )
            return False

    def _clear_zfg_state(self):
        state = getattr(self.task, self.STATE_KEY, None)
        self._release_phoebe_prehold(state, reason='clear-zfg-state')
        for key in (self.STATE_KEY, self.SWITCH_LOG_KEY):
            if hasattr(self.task, key):
                delattr(self.task, key)

    def _zfg_team_matches(self):
        chars = getattr(self.task, 'chars', None)
        if not isinstance(chars, (list, tuple)):
            return False

        chars = tuple(char for char in chars if char is not None)

        signature = tuple(
            (
                str(getattr(char, 'char_name', '') or '')
                .casefold()
                .removeprefix('labels.'),
                getattr(char, 'index', None),
            )
            for char in chars
        )

        required = {
            'char_zani',
            'char_phoebe',
            'char_rover',
        }

        identity_ok = (
            len(chars) == 3
            and {name for name, _ in signature} == required
            and any(char is self for char in chars)
        )

        rover = None
        for char in chars:
            name = (
                str(getattr(char, 'char_name', '') or '')
                .casefold()
                .removeprefix('labels.')
            )
            if name == 'char_rover':
                rover = char
                break

        rover_form = -1
        if rover is not None:
            try:
                if hasattr(self.task, 'get_known_ring_index'):
                    rover_form = self.task.get_known_ring_index(rover)
                else:
                    rover_form = getattr(rover, 'ring_index', -1)
            except Exception:
                rover_form = getattr(rover, 'ring_index', -1)

        form_ok = rover_form < 0 or rover_form == Elements.SPECTRO
        matched = identity_ok and form_ok

        previous = getattr(self.task, self.TEAM_SIGNATURE_KEY, None)

        if signature != previous:
            self._clear_zfg_state()
            setattr(self.task, self.TEAM_SIGNATURE_KEY, signature)
            self.logger.info(
                f'ZFG team changed matched={matched} '
                f'rover_form={rover_form} members={signature}'
            )
        elif not matched:
            self._clear_zfg_state()

        return matched

    def _zfg_state(self):
        """Return shared FSM state.

        First creation starts from P1.  If an already-existing state is damaged,
        do not replay the one-time opening: route to the agreed recovery entry.
        """
        state = getattr(self.task, self.STATE_KEY, None)

        if state is None:
            state = {
                'step': self.STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER,
                'cycle': 1,
                'nightfall_count': 0,
            }
            setattr(self.task, self.STATE_KEY, state)
            self.logger.info(
                'ZFG FSM initialize -> P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER'
            )
            return state

        if not isinstance(state, dict) or 'step' not in state:
            old_cycle = state.get('cycle', 1) if isinstance(state, dict) else 1
            state = {
                'cycle': old_cycle,
                'nightfall_count': 0,
            }
            setattr(self.task, self.STATE_KEY, state)
            self._route_broken_state_to_recovery(
                state,
                reason='state-missing-step',
            )

        return state


    def _advance_step(self, state, next_step):
        old = state.get('step')
        state['step'] = next_step
        state.pop('phase', None)
        state.pop('phase_started_at', None)

        self.logger.info(
            f'ZFG FSM advance {old} -> {next_step} '
            f'cycle={state.get("cycle", 1)} '
            f'nightfall={state.get("nightfall_count", 0)}'
        )

    def _expected_actor(self, state):
        if state.get('detour_active'):
            return state.get('detour_actor')
        return self.STEP_ACTOR.get(state.get('step'))

    def _route_broken_state_to_recovery(self, state, reason='unknown'):
        """Route a damaged FSM without replaying the one-time P1 opening.

        - Zani still in R state -> RECOVER_ZANI_LIBERATION.
        - Otherwise -> RECOVER_P2_PHOEBE.
        """
        if not isinstance(state, dict):
            return 'Phoebe'

        self._clear_detour(state)
        state.pop('phase', None)
        state.pop('phase_started_at', None)

        zani = self if self.ACTOR == 'Zani' else self._find_target_char('Zani')
        if zani is not None and getattr(zani, 'in_liberation', False):
            state['step'] = self.STEP_RECOVER_ZANI_LIBERATION
            actor = 'Zani'
        else:
            state['step'] = self.STEP_RECOVER_P2_PHOEBE
            actor = 'Phoebe'

        self.logger.error(
            f'ZFG broken FSM recovery reason={reason} '
            f'-> step={state.get("step")} actor={actor}'
        )
        return actor

    def get_switch_priority(
        self,
        current_char=None,
        has_intro=False,
        target_low_con=False,
    ):
        if not self._zfg_team_matches():
            return super().get_switch_priority(
                current_char,
                has_intro,
                target_low_con,
            )

        state = self._zfg_state()
        expected = self._expected_actor(state)

        if expected is None:
            expected = self._route_broken_state_to_recovery(
                state,
                reason=f'unknown-step:{state.get("step")}',
            )

        if not getattr(self.task, self.SWITCH_LOG_KEY, False):
            self.logger.info(
                f'ZFG FSM-exclusive switching enabled '
                f'step={state.get("step")} expected={expected}'
            )
            setattr(self.task, self.SWITCH_LOG_KEY, True)

        return (
            SwitchPriority.MUST
            if expected == self.ACTOR
            else SwitchPriority.NO
        )

    def _find_target_char(self, target_name):
        target_name = target_name.casefold()

        for char in getattr(self.task, 'chars', []):
            if char is None or char is self:
                continue

            names = (
                getattr(char, 'name', None),
                char.__class__.__name__,
                getattr(char, 'display_name', None),
            )

            for name in names:
                if name and str(name).casefold() == target_name:
                    return char

        return None

    def _raw_con_full(self):
        try:
            return bool(self.task.is_con_full())
        except Exception:
            return bool(self.is_con_full())

    def _read_concerto(self):
        if self._raw_con_full():
            return 1.0

        try:
            value = float(self.get_current_con())
        except Exception:
            try:
                value = float(self.task.get_current_con())
            except Exception:
                value = 0.0

        return max(0.0, min(1.0, value))

    def _concerto_effectively_full(self):
        return (
            self._raw_con_full()
            or self._read_concerto() >= self.CONCERTO_EFFECTIVE_FULL
        )

    def _confirm_hard_intro_ready(self, target_name):
        start = time.time()
        full_frames = 0

        while time.time() - start < self.INTRO_CONFIRM_TIMEOUT:
            if self._raw_con_full():
                full_frames += 1

                if full_frames >= self.INTRO_CONFIRM_FRAMES:
                    self.logger.info(
                        f'ZFG hard-intro guard passed '
                        f'{self.ACTOR}->{target_name} '
                        f'{full_frames}/{self.INTRO_CONFIRM_FRAMES}'
                    )
                    return True
            else:
                full_frames = 0

            self.sleep(self.POLL)
            self.task.next_frame()

        self.logger.warning(
            f'ZFG hard-intro guard failed '
            f'{self.ACTOR}->{target_name}'
        )
        return False

    def _switch_to(self, target_name, expect_intro=None):
        target = self._find_target_char(target_name)

        if target is None:
            self.logger.error(
                f'ZFG {self.ACTOR}: target not found -> {target_name}'
            )
            return False

        if expect_intro is True:
            allowed = self.SPECIAL_INTRO_TARGET.get(self.ACTOR)

            if target_name != allowed:
                self.logger.error(
                    f'ZFG invalid special intro '
                    f'{self.ACTOR}->{target_name}; '
                    f'allowed={allowed}'
                )
                return False

            if not self._confirm_hard_intro_ready(target_name):
                return False

            has_intro = True

        elif expect_intro is False:
            if self._concerto_effectively_full():
                self.logger.warning(
                    f'ZFG block forced-normal switch '
                    f'{self.ACTOR}->{target_name}: concerto full'
                )
                return False
            has_intro = False

        else:
            has_intro = self._concerto_effectively_full()

        target.has_intro = has_intro
        target.has_sub_dps_intro = (
            has_intro and getattr(self, 'is_sub_dps', False)
        )

        start = time.time()
        last_send = 0.0

        while time.time() - start < self.SWITCH_TIMEOUT:
            self.check_combat()

            try:
                in_team, current_index, _ = self.task.in_team()
            except Exception:
                in_team, current_index = False, -1

            if in_team and current_index == target.index:
                # V4.3: 若此前已经跨角色预按菲比E，在确认菲比成为当前角色的首帧
                # 立即做一次UP->DOWN re-edge，再进入常规切人bookkeeping。
                self._reedge_phoebe_prehold_on_entry(target_name, has_intro)

                self.task.in_liberation = False
                target.is_current_char = True

                self.switch_out(con_full=has_intro)
                target.last_switch_in_time = time.time()

                if has_intro:
                    now = time.time()
                    self.add_freeze_duration(
                        now,
                        target.intro_motion_freeze_duration,
                        -100,
                    )
                    self.last_outro_time = now

                self.logger.info(
                    f'ZFG exact switch success '
                    f'{self.ACTOR}->{target_name} '
                    f'intro={has_intro}'
                )
                return True

            if (
                in_team
                and current_index == self.index
                and not target.wait_switch()
            ):
                now = time.time()

                if now - last_send >= self.SWITCH_RETRY_INTERVAL:
                    self.task.send_key(target.index + 1)
                    last_send = now

            self.sleep(self.SWITCH_RETRY_INTERVAL)
            self.task.next_frame()

        self.logger.error(
            f'ZFG exact switch timeout '
            f'{self.ACTOR}->{target_name}'
        )
        return False

    def _clear_detour(self, state):
        for key in (
            'detour_active',
            'detour_actor',
            'detour_final_target',
            'detour_next_step',
            'detour_next_phase',
            'detour_resume_step',
            'detour_resume_phase',
        ):
            state.pop(key, None)

    def _switch_route(
        self,
        state,
        planned_target,
        next_step,
        force_intro=False,
    ):
        """
        正常切人入口。

        若协奏满，但planned_target不是当前角色正确的特殊变奏目标：
        保存主轴step/phase -> 先让正确角色吃特殊变奏
        -> 再自然切planned_target -> 进入next_step。
        """

        if force_intro:
            if self._switch_to(planned_target, expect_intro=True):
                self._advance_step(state, next_step)
                return True
            return False

        full = self._concerto_effectively_full()
        special_target = self.SPECIAL_INTRO_TARGET.get(self.ACTOR)

        if (
            full
            and special_target
            and planned_target != special_target
        ):
            if planned_target == 'Phoebe' and state.get(self.PHOEBE_PREHOLD_E_KEY):
                self.logger.info(
                    f'ZFG Phoebe-E prehold PRESERVE across detour '
                    f'{self.ACTOR}->{special_target}->Phoebe'
                )
            resume_step = state.get('step')
            resume_phase = state.get('phase')

            self.logger.warning(
                f'ZFG intro detour required: '
                f'source={self.ACTOR} '
                f'planned={planned_target} '
                f'correct_intro={special_target} '
                f'resume={resume_step}/{resume_phase}'
            )

            if not self._switch_to(
                special_target,
                expect_intro=None,
            ):
                return False

            state['detour_active'] = True
            state['detour_actor'] = special_target
            state['detour_final_target'] = planned_target
            state['detour_next_step'] = next_step
            state['detour_resume_step'] = resume_step
            state['detour_resume_phase'] = resume_phase
            return True

        if self._switch_to(planned_target, expect_intro=None):
            self._advance_step(state, next_step)
            return True

        return False

    def _run_detour_if_needed(self, state):
        if not state.get('detour_active'):
            return False

        expected = state.get('detour_actor')

        if expected != self.ACTOR:
            self._recover_wrong_actor(state)
            return True

        final_target = state.get('detour_final_target')
        next_step = state.get('detour_next_step')
        next_phase = state.get('detour_next_phase')
        resume_step = state.get('detour_resume_step')
        resume_phase = state.get('detour_resume_phase')

        self.logger.info(
            f'ZFG detour actor={self.ACTOR} '
            f'return={final_target} '
            f'resume={resume_step}/{resume_phase}'
        )

        if self._switch_to(final_target, expect_intro=None):
            self._clear_detour(state)
            self._advance_step(state, next_step)
            if next_phase is not None:
                state['phase'] = next_phase
                self.logger.info(
                    f'ZFG V4.4 detour resume phase restored -> {next_step}/{next_phase}'
                )

        return True

    def _recover_wrong_actor(self, state):
        expected = self._expected_actor(state)

        if expected and expected != self.ACTOR:
            self.logger.warning(
                f'ZFG wrong actor: current={self.ACTOR} '
                f'step={state.get("step")} expected={expected}'
            )
            return self._switch_to(
                expected,
                expect_intro=None,
            )

        recovery_actor = self._route_broken_state_to_recovery(
            state,
            reason=f'unhandled-step:{state.get("step")}',
        )

        if recovery_actor != self.ACTOR:
            return self._switch_to(
                recovery_actor,
                expect_intro=None,
            )

        return False


    def on_combat_end(self, chars):
        self._clear_zfg_state()

        if hasattr(self.task, self.TEAM_SIGNATURE_KEY):
            delattr(self.task, self.TEAM_SIGNATURE_KEY)

        return super().on_combat_end(chars)


class Phoebe(_ZFGFSM, BuiltinPhoebe):
    ACTOR = 'Phoebe'

    # V4.3 菲比E1/E2显式图标模板。模板来自用户确认的1600x900实机局部图，
    # 直接嵌入本py，复制文件时无需额外assets。ROI会先归一到1600x900基准再匹配。
    PHOEBE_E_STAGE_ROI = (1305, 755, 1410, 850)
    PHOEBE_E_STAGE_BASE_SIZE = (105, 95)
    PHOEBE_E_STAGE_MIN_SCORE = 0.50
    PHOEBE_E_STAGE_MIN_MARGIN = 0.10
    PHOEBE_E_STAGE_POLL = 0.02
    PHOEBE_E1_CONFIRM_TIMEOUT = 0.45
    PHOEBE_E1_TEMPLATE_B64 = 'iVBORw0KGgoAAAANSUhEUgAAAEYAAAA5CAIAAAAEOMrHAAAYnElEQVR4nH16a4xd1ZXmWvtxzrmvKtfDpoxtjF+A8SMxluUkkMSBhB6MAwGNZyYhgDIdd0R3z/xJlD9REpSQSUstpMgaxW6QEgZNpCB66DGJg9NGzGSITAdMQAbcPOwYl8GmymXX4z7OY++91vxY9566LrtzZK4up/bZZz2/9a21L959222gUIEGhVprpRQiEjMzAgAiEgIzExEzIyIAEFHoXeVNRigvRAYAZAOXXYiIiMwMAMwsX+QqbyKiiCELiGjBJuVTC3aQy0RGB2AtMlEIHJRSAICgGIAZgBgYFQCh7u2CzAiglGJmBoUA0NNIXi93sP9NC9ToF0uMIpe8/fJll+8jKy/fwSRJEkKQP4RAzgdQjOItgEDEzGJc7l0hhNJpiCgq9V6GlwtxRclKIeQLIoYQSh/+mU3KT5Gh9GG5oRkZXpSmqXOOmL0nckyBIZCnAgAk/JgDgyJUEmn9BlZKUSBEZKR+ORARGBR3JbjEX32vL83EAIGCxNsVVy7QDREXBGT5dqO1rlarorHzFBdF4YNkiwueqDQDhcCe51/DHOBSp1/yemINDKjKzOl/90LlRRRjrqDqpcnWH72y8+X7myzLoigy1gKAsZgkCSI6Cq7wWZbleV4UhfcUmJhBMQOAQgUADMzMSMwKmZmpm9bd16OsCFeyMS3QX74qhQDct4blfy8Hg35lL085Mzc3F8exsVYppZQxxlhrDRhrImuttTbLsjx33vvAFIgAlEQ7UTcHuBfZkgnzWtG8KHBZ8vRfcicQXTHM/q1rQWrNq+S8J2ZVFACgtTXGKKW01kppRDRKxdYiYgg6d4UmwTpiBkIkAEQ0iCGwJwQGJEboJg9345MXCFrqfEWB/vxVhlkJJFcIPOrZhplDYAEApZRSusRTkSMyNrAAnel6HkHSVCmlkAU5/4xFS5WwT1vJVWZWev7+FRMJLou9K5rDECpEBagElTyTYiAiAKQuggMzEwAqUASg+l8MiMioNKqgKQRkmrdZDy0XyteF/p7JlVL9dbxUYMFTC8KMr1SCuyr1hwEAEBEC9sd9930A3ge5A0oBQAhBXiecQ4ES4YgIWEFZiUvJesKVr+ilNwEQIkPwrFAxBCYk6GKPFEcExRCA5VPuLwi5eeQsbVZGQmAOFJBpYcwEAgAGCBjkESUPcjd0NaLWGrQGQGYChQwE1LU0MvbAVzQP3AU6dsEHR4iIrIBBATOAQWBkJmISSCSNqBR2E5m4DJbyU0zVVenfQqFL7iglT2oAutIChQjz1lE6UszAgZi5qxgxAzOTAmZkBKAuWHoG1mC7zCpwdx0REyllAOartVaKgBRgoHk5ex5jZjb9Bbtf737deiDTZbEAoPoc2F2PeJl1GFGjBLZ4SHGZM7Ybc8zMETAz+zwAABEze1mGoBFIIr/3FsGSKxi9FMZc0UULlvYsAeVn//3+DO6/SYEZAkh1Il6woPugQqmGWms2wMzOeUTsNQPdQsc9Rscw3w3wpUKWDrgy/1+gjzwQuMvcust6DFXIBHG3APRwkgmYiDhQiZzQ9+LSNlprbY3W2toIldImsqCU7vUuoQedhCEEYA1S6QH6iHR3Ww2IZYXp1+QSK16pAvRXD+ihoqfgvRdBBF4JiKgLD/1wInUM+ksQAiIqpY0xRkeqR2QERkMI4qiyPSMi732PxNAlbYGUWoBLALG/D7lUq/lq3W8eF7qaeO+992XpJJg3gWJAxEAMACEQhG56BO73oTLGSBBaG1trtdZaa/kCMF++iMi53Lm8XyVmlkwzpdALnLPAS2LKy28yc17kYrbSPyUKlQFMfVelUplfD11qgohMSER5njOzMS6O4yiKtNbC0XqZXGa+0toyB0m2rmIl4i3QpHxSWgzudc5MIF2aMYaZi6LIilwsJF5SSlUqlVarZeOoKIooiuRNiBgoJEnS6XRsHKFWrVazUqlE1qRpKpSSmZXWzgVpZ/K8ned5tVq1tks7e4ppkYqIgvNEBCh0TKq3NsaYy/XpT7iSHTIzUTdeQwh5nqdpGpiMMd57IRClAhIt8lQURVEUtdtt55xzLkmSdrtdr9e9961WS5TJ8zyySehlndZaPiWYxVGiGyKVzWyZyWJxY4zWqLU2/ZqUanQjrdcpyBZaa2E73vvCO0+hfAoRGYGImQIo7KNFClgVuWfUiLh12/bXXnuNGU2UBM61pWqcMLNzTmAAEWV6oRQoBUS+KAoRl7kiuCKiyX8ShsyslLLWWquVUkbsVOY0XHb1VVDlnCuDzVoroos0gbv9koQlIlobiZQhhCiKnHMPPvjgzMzMuXPn0jQNIcRxLOQ9juM0TbU2ZRjLtmU2EpFzDgDEgcItsJuuXDqgi6td0nlZD1NWtNLFhS9yl+d5VhQ5UZCuk5mYKQQPwNKWIgIzGaMZgg9FQQVaJPZKw8dv+tjd99xlIg2KlQZiX1ARMKBipcFoNBqN1lopBAIOCtkaZTQiEAXnXU4+IMN847DgIuZACi+7+teIzQSdsiwrjdePHOJ3SV8BceecLJAQKIrCObdt2zZEvO2224jIWhvHMQAkSVKpVLz3cRzLzr0Qsv2wWYohkvTXEgHMnvcYSrCXh8VdpW699lZJuDvnmFlqRblMKQUKtTUCDwBQrVYFMwQAkyRRSkVx/O937zbGLB4bu/baa5m5cK6stnmeQ2+cgsjWaoHv0ucALC7woShc5n1B5CWISpFKYFNlnerX5FIY0WV8C1j3G0YgrlyQJMnw4tHBwUE02lFIi1xSxVp74403amuB6HOf+5wMD621RVEURSGAFkWRxH9pSuwOmECprtDee+ecxEIXAqQF79ILJiKlmJCCYtCABpVBFRurAbUyRluF2rvgCt+tsNDlJsYYCQCtdRTFRBwAbJI4ol1fvOvv/v7vb77l0zZKjI2z3OWF37Hj1ihKiqwAxp07dxkTGWU1GlcEJty5666f7P3vS5eNmUijVoEpLzyD0toqpY2JABSAUsrIU8AcvPeeEDUR5JnzjpjZUyh8UOXVDy/UGyo457pB7IJki+gmeSJUpdVqVatVrbX3Xhvz5JNPXrtq1UMPPRRVEkehUqlYa++8806tdVSpAOLIkiXLli3TWqdpGsfx2rVrv/71ry9dunR8fLzT6WRZhtidveV5rtQ8GShTHbtEvaxLOoTgiiDew//8H3eX1KYLd4wCl55CnuchhE6nAwCI4L3vsSy23clRiCtJmqaB0TmXVCtEdP2N6x988MGRkRHv/d/96L898MADt9xyi00Sl2XWWu99s9n8wQ9+4Jz7xp6/WrJkycGDB19++eU33zqWJEmRe6VU3klFEwlv5xyykteVNC+OK9oaqw0iMgdhElpr/Mv/9B/KPOvmFUnYmTzPsywTP/QIRABApZRzTphHCEF6Hmm7c1eEEEaWLN60adMjjzzivXdZXqvViGh6erpWqzWbzaGhIaVUp9NBxHqtDkrtvvfe8fFxZjZWMWGSJO25prVWKZWmqUAiotaoJJ/FaTZOEDEyVmsdgvPeKw2IaFgaTkBiJgahWIjMAbIiz3JXr8eBIATSWoNiYBWIGVThpNijQeOdR2ObzWZ9oJFlWXOu/caxtzrtrDEwAKzeO3nqsf3733nnnZJ/3X///XfccUelXs/a7aNHj168OOOciyuJ877IcmYGrYrgQxGUVmnhlFIIjMDKaJlYJEkSAnvvHSIoDEyM3TmA4QUXAgEjkfc+yzLngrVWoAYRQyBEds7FcSxmtta22+0oirI0rdfrAsetVivLsqIoKIRXX3314YcfTtvtPM+F3WmtH3vssYMHD/70pz9NarVTp07Nzc0RQbPZrFarSZK0Wq0oigCgKIp6vZ7nzlobQijIGzQueA2YJEma5t57Qf8eaAMRqbzw8q9wwXkqPHmCrPCdrOhkhaNg4gi0CsCZ82nhch+KQJVKjRmdC96T1rbV6oQQhKoJ2dm9e7e1Vmn98MMPT05ONtvtTpatWLkyzfNWqzUxMXHixImf/exnoSg+//nPD40MR0k8MDAwOzsLSqM2jAq1UcZ2spyAbRyBwtwVgcB58gyVeoMVeiZHofyUEDBpmpbAEHpNm/e+KIo8z8uqyszeO+kgELFer8/MzEgtN8YQQqNWm5qaqg80HnvsscVXXTU4ONhoNH70yCOzs7PW2iRJfv7zn1erVefcPx86tH///pmZmV/84hdf+9rXrrrqql/+8pdpmj733MG9e/d2Oh1jjHNOcC9NU2HlIqGw8iiKBgYHp6amSlLaJW4KmdnkPpRcuwvQTMzcTjPnfISq1UmXX7Pij3/8o1JGKZMX3hiz4tpV75w4mSSVTqcTAS5btuKuu+66/S/+Io7joaEh0MoYgwgvvvhimqZE9KMf/WjtunXeOUT88pe//PTTT1+8eLHVar377rubt2yp1+vDw8P33Xf/zp27sizbu3fv0aNHZ2dnvSMETQBZ4XMXUNtOngFA3mkvGhn2775LzFmeo1IUfBzHaVEYsceCbCJgIWldjI7jer0exxUE7ZyTFkO6ICKq1+vf+ta3duzYoY2pNxpFnkeVGAAAgYmYOYqioijWrVsHAMZaCqFer2/ZsuXAgQOIOD4+vnHjxt6sVo2NjSlrv/e9701NTe3fv////p//x8wbNm786KOPJLBF4MHBQUm2skiqPh5jpLOW+ahMERmoKIou+y4KRIzjShzHzXZKTMpTCEFpPbZ06Yn33gOAn/zkJ08++eQNN16/Z8+ea9esAea5ubmBwcHAlLui0+lEUXTmzJnFixfXGw0AIIAj//IvgXlo0aLVq1d776NKBUKIKxVA/MX/+J+//e1vm83m2bNn5+bmxsbGrrnmmomJCedCklRl0LJ48VWIOgB7JoPKe28j3QU96DXqwqalWwgUugWnN5PQWi9ZsmT6vZPWWp8XwrLWrFlz9sMP0zRtt9vT09PTsxd/97vfDQ4Nbdy48ZFHHsmzLEriO+6441cHnr1w4cJ3v/vdJ554IkkSY8y3v/3t2dnZKIpardbSpUujSsXn+UsvvbRv376ZmZnJiSlE7HQ6SZLEcTw9PS2sRSklp3tpmi5fvly6ZiICrbz3xiohNABgKAAAdCe8zMwcPCs0wTullI1kXmNXr1596vSZVqetUVXqtVqtxsyoFDE3BusXLlyYnJwMITTb7enp6S984Quf+tSnvvPd7/3N3/yXf/zHZ2abrUZj8L777h8YGPDef/jhh0VR1Gq1PXv21BqDp/70/t8+9NfMfGFqanJycmh4WMI7hFAUxfXXX8+erxq9qt1OZ2dnmTmO4yVLlpTtj/gqdKezAACqbIfKEVwZoPMUCWBoZCSOYyHm7XY7z/NFixZdd911ALBu3bosy6SMxnHsnFu2bNnExIT3vl6vPvXUU9ddd12r1Wq1Wn/605/Gx8elUN55550PPPBAFNvf//731157rdY6juPBwUGpAdbaDRs2LF68ePPmzZVKZeXKlTKocM597GMfKzk79k7NSihGRFMGGPTNmsvz+iL3TN2u5pZbbvnn5w9PX7i4YcOGaqOeF8Wq1SuXr7h6cHDwjTfeWLNmzcqVK9Mi/eCDD86e+2DsqquTJAGAZcuW7d+//8CBA7/+9a/zjyYQcfv27V/96lc3btxYr9cp8DXXXPP4/n8YHR294YYbRkZGiOjs2bOvvfbaurVrV61aE0WRTL/qlWqz2RwYHFizZo1UEWlDRNTuuFMGyP1D9G4LCSxcQWud57lSypo4BB4bG1u/fv35icktW7bIgmqlrhsIrDZt2vTeuydPnDhxYXpaKZUkye1f+HdZliml4tiuWbPmG9/4xn333ddutiqVijFmZGQkjiMA8D5s3brVWnv8+PHhoSEA8I5GFw/ffvvtS5Ys6aS5cy5NU2vtrbfe+tJLL23/1Cfr9bpSSuv5AwutNZEv57L4ia2fLKm7fEo/XATvvbfWfuYznxkbG5M+Qlo9YccSZr/61YGLF2eUghB4YuLc2NhYu91+9tlnx8bGjr35xqOPPnru3LlNmzY99tj+EDjrpLV6lQmOHTv2ne98J8uyv/rLr+/atevYsWM//OEPT58ad85FUWytYYRFixatWrVq+/bt7XY7hEBIc3Nzo6OjWZYJR/unf/pfs7Oz4h8iGh0d9Z4A4ApjfhkhFK6QxEjTtNFoSHtTqVSExTUajYMHD46Pj0dR1Ol0hENs3/7Jq6++eu3atStXrjp16tT3v//9999/HwBeeeWVAwd+tXPnzlq9WuTOGLN3796TJ08S0aOPPnr8+PFvfvObjz/++N/+9X89ceJEHMd5nrvgPvjgg1ar9frrr3/xi18cHBxUSi1fvrzVaknHMTw8rLVGJcdU3VaqOxpaMEWR4igOTZJEBoJxHLfb7YGBAQBYvnz5O++888QTT5w+fbrZbOZ5XqvVNm/evGLFivXr1xdF8ZWvfOWpp5566KGHzp8/LwZK0/Tw4cN5ngdPUWxnZmbGx8dlQOeZnjnwv/ft2yeDsXvuuefjN32ckeM4FtAjomefffbQoUMSIHEcDw8Pi62VUgi6DK5e+0OX/CBEvuR5LhRb+iXhWgBQqVQQ8eDBg2+++aaU6kql0ul0lFJDQ0Of/exnn3vuucnJyQceeGBmZmZiYqJarwjVyLLspZdeEkTVRh0+fPjChQuy58WLF621zzzzzOHDh/O0mJmZqdare/bsOXDggGCmTM+npqZ+85vf7NixY9myZeKNWq3WD3rCCrwnlnM5uHQoKYgHAM45a22tVvPey/jm+eeff/HFF4loZGRE6AkR7dy5c/Xq1YcOHTp37lyz2Tx9+vTMzEyj0RDmoZSq1Wqzs7OvvvpqFFsKfODAgaIoRFwZIU1emPro/OTFmem51lylUjl48OA999yzYsUKSZKly5cS0vvvv3/o0KGpqSkZtsgISdwiW8lkxjmn4LIha9moIaJgqBSNl19++fjx4/V6vdlsJknCzM1m8xOf+MTY2FhRFGfPnhVoEfbV6XRkmJqmqYTQvn378qyYmJh4/fXXEbFarYpizFytVqXzcc6dPn16/fr1f/jDH2699VYJlkaj4ZwbHR0tiuLQoUNJkkRRJGMCIeCyieyAvcPt+R9p9YYYSuSYnZ0NIQwNDcVxfPToy94XadpOkmhoaBCAosisW7cGgN566w2tcXZ2ul6vFkWmNSZJlKeZUdpqk7Y7yPD28X91zj3//PNxHDOzsJtarSYsIYoi0BAgpEVaqVdaaSupJWuvX1sbqG3YsCHP806nw8xnzpx58sknpSMUksDd6aTpHSDDJadjkleijxwZ1Ov1RYsWOedeeOEFOX2Qmdvk5KT0p3EcSxzmeS4NqRwflbVPClEcx1mWHTt2bN++fcIDhI9lWdZoNCRv4zguiqLdbp8/f/6mm24SNnTx4sVNmzaNjIxkWdZqtWq12pkzZ4RPCekRAJS8EI9dMk8qJ6zl1EKG66Ojo2+//TYR1Wq1Wq3W6XQajcbWrVuFB0VRtHLlSjnaMMZIZZStpPaJIZIk+fGPfyyIL9tK+OV5Loc0MmOL47jZbIrE7XYbEa+55hqZ6nTx3bljx45prTXo2MShCAaNYjCoNGCkzSU/IBHrOuck+crDD/n03s/NzbXb7Wq12mq11q9fH8fxqVOnsix7++23t23btnz5cslDQViZbocQJBnyPD9//jwRVatVcWDJDCT8pA2J43jz5s0Cp2+++aY4WRA8TVNBYAAQJl4iXpk+XcRboJXYVWSSqtxoNCT0BwcHS8zYunVrFEVHjhyJ43jVqlUA8OGHH8pfy1ohVRsR5RBWDi2FiMSVJKlWPIU0z1zwuStAce6yFSuXowZP7q1/fXNycnLbtm2iuQCPBLDAA/V+LlcmTlel/lwqM0qEkMiRYcCWLVskI40xExMTAwMDzrnrr78+z/Onn346TdMNGzbcfffdMiQyxrRaLUSM47jRaEiJlOSRoUKapsIDKpWKWBARG43GzTffvH37dqXU0aNHX3nllQsXLuzatUv+JOeiQiBvvvlmEYC7P0q7xDEL2QMAeO/F3QIVR44cYebdu3fLIQozj46Onjt3bmBgYMeOHdbaubm5Q4cOnT59etmyZV/60pd27969bt260dFRCASBvPcSMCKBUCopR977TqcjmXnTTTfdcccdN9xww+jo6JEjR06cODE9Pb32ujWLhgfr9bq1VrCh0+kMDg7WajWJZEng/uk385V+yi1tiYSmUurkyZPMvGTJknvvvfeZZ56RNBgYGAghfPrTn37qqafOnTuntT579uyJEyc2bNiwdu3a4eHhLMuQ+OLFi6fGT09NTc3OzhZF0el0ynPYSq06Ojq6bt26kZERABgcHDx/fuKFF1648847jx8/nmVZHMf33nuvcJdOp1OpVIRkPv7440R08uTJoijEyuU5kFz/H92Q2LJ/JiAVAAAAAElFTkSuQmCC'
    PHOEBE_E2_TEMPLATE_B64 = 'iVBORw0KGgoAAAANSUhEUgAAAEYAAAA5CAIAAAAEOMrHAAAgx0lEQVR4nF166ZNc13XfOecu771eZx/MYAYDzABDgCAAUuIOg6YkihJliZYlK3IiO05STtmp8hf7W1Ll/ANOJeUvrvIXy0mVKpWSYy0WZYqkCFEERRIEIZorFnGAwWCZrbunt7fc7eTDG4zo3Orp6unq1/3OPef+zvn9zsH//Cf/hZmdM9Za7z0zE5EQgpQmFMzIzEQSkQmCtTaEIIQgJRAREYmI2QMAIiqlPIder5emA0QM3hIRgggBQgBgVOWVYvdaZmZmwECARIiIAMCIcHchCER0HMp/mX0A3lsQ2FprbOGcK+8cIBCRdM4x+xACABARABBJIgJGJEQkZvbeh+BCcNYZRIxlHGutlELk8hJmDuCFEOgcIpffJoRgZh+8c8HbEDxnQEQyiiIhhJSSCAQiIAJCAEYA5vIPqDQRGYCBw+5PsA93FzOHEKy11lpmLrcjMPkAktmXRpdbjojMGEIAQAAgQu+9Mc6YPM9T5225x3EcAwQiQUQhBGYPCIgohFBKRVGEyHmRMXPwGMLdfQVk5nSYK6WimJUSRIAAIZR+FsxQOrwMltI3RMQQODAHDiE450qrnHOlf4iovHNgDiFI770QQghRbi0iKqWttQHAe18UtigKY1xRZIGtEDjMskHajxLdHG1kWaYlMgeSIoRABFESB/BCkZQSOAwGg51O3zkHTAE4eE/MIQA7gCIMh0ZrWW/UkIiZJYnS8tIY711AQGRmLOPIe++cKz3jvbfW78bqXZcAkhBS7n3LXV9jURRCCEEiTdOisFmWec/OWaTACHEcA0Ce54PBgAi8Lz0GcazHJycajYZzLs9zABCE165ds2YVAIIn7wMLJJTl5c56Zg+o0xSIQGttnEcUpT2ISFRu+q5b/N1VeiaEcNeNu14tXQoA8u5hK+OOEDGKBAAU1g2HQ2b23iIKRGaALMuUN1rrwuYBfBxXmHl0fGRxcbFarWamUEp671utVpqmRWa2W632TgeApNAokAMbW0RaK41E2lqTm8yFQiklhJAohUCUBAhISIQygHMhBFf6ZA8GmBFRIAIzAyOHMl6BMSCi3HMcAJSxp5RK03SY5c65JEl2A1JoFBzAC4lCiDzPu93u7Ozs8vLhubm52fm5ZrNhrVNKgoRbq7cuXLjwszdf3traQsQ4jqz1wbNSkdbojC1BgQRoIYUQ1hadrqkmtQpUCKGE0PIslBi7558SGBDFHiru3XzpI2aWzBgCMPvSfSGEXq+fZRkjaq2FJBIohKhoPcwGzbHmcDgcZtnc3Nwjjz326GMPHzhwIKpqZzwoUEoGy2kvvX7j2utv/qLd3cmt0VrLSEcVoWQkibK0yJGttYhAiN6D9SaEUO4jM8cQ754Q8CEE5613XJoUQggBmIHYAwBjGXhUItndZ5B7qMDMJYYMhykAqCiSUhZFEUVRvV5PqnG9qA3zYZ7nR44c+dznPvfYY4+NTjas8d6GEMLWesc512w20zTtdrvNZlMJDQC1Wm1iYmJiYmJ0dEwA9nq9zc3NjY2NTqfb73eHw+FgMLDWAoC3oTRGaSFludflWfKlc8r73Lv3wIyfWADACMwsS2AtnVsURVEUzKyUCuytM9ba/fv3x3HcG3Tb3R0X7NF7jz377LMPfOokCmAP3vutrdZma/vtt992zj3xxG8cOHDgxP2njh49mkSVRqNRrVYBIfjdvBdCwMAohLfuypXLb7311gcffHDr1m1nrHdZlg8Lk5VpQAgqg40ZmBk8YEBCgjJqAUqLSmADFHcTN0hELO2x1hZFkWWp1tox2dyqSEolJ6cn0jS9vrpKip74zJkvPP3M4eWDwYPNXafTuXjx4geXPtzY2Gg2m48//vjMzP5qrQIAne1OnufG2I2NTWuNEIKIyl/VQtbr9Wazec+9x46dOt5td1988cWf/fRse7uVpWlRFM45AJBS3AVuDwAcEFEIACZEIAAq7RFCERHcrUWYWaIQgigz+TAbOudAQG5zRU4q6dlpqYSiABYVP/Tog08/84UDBw4EhuFw+M4777z66qudTieO40qUHL3n2LFjx4QQH3145cqVK7949dzN1duRUiGENE2llIhcFEUU6Wqjvri4ePr06XvvO54kUbVe+do3v/7FLz3zg7//wUsvvHjz5k0kyrJMay2EsNbtxhViAGYOyAIRAViSElIKoe7aJkq0kHtlRQgBICCi1MI5NzExkZusWk1QYj8dnLz/5Je+9MyhQ4ekws2N1j/96Mcvv/xyr9ebm5uTUt57770njh8nFG+88cb3v//9O3fuRFILlP3eEBGFUEqIEAIihsCdTufNN9/cam13ujsPPfrQ1NQUSXQcvvjFL25vtobD4XA4tNZYa6WUUsrdYgfQew/MApCEQCxRrSxxqPxkaZUMIRhjjDHMXL4lhCg4bzabOKAkSSKprHWf/vSDx44dQwWr1269/PLLr77ySqfTiWQ86A4XF5aWFo9sbW29/PLLaZpW40q9Uu31+oo0EWmlyuS7l82DcfMH5hcWFprNppTyzp077Z3OsJ++9OOXPnzvw3a7zcyCQCkFwCH4f4kBd5GAGRBK/NgL6RI/JADsJWMpqUxjWkbW2iSKlVKl9VrrLMvs0J87d+7ll19ub2/X63ViURTF3NzcrbWb11dXuv3e4cWldrvd7/eVkAIQiLz3ACCl9N4DQqPReOCBJx566KGjx++Nkvj82+efe+65Dy99NOgNNehgQ7VaDSE4WzjnQvBSyrKSlIKklBxKZGMOZVELZfJ1zpXHFRHlrj0MgkiiDBxccETUarWWlpZUpJlRSnn16tWjR4+++/775994IxsOE10xmYVQNJvNt996q1qtGmMAMdGRJAEBgICZg3PMXgjBTHmeHzq08Oyzzz752SdRCAbuDwevv/76hQsXCmvq1UYonLF5eXaCc8YYQkiS5G59RIiCd4MQGEp64pkhBNhzESJSWZzfrcG5jHgAGAwGlUplfHyciJIkWfnVx+fOnTt79uza2ppSiogipSqVSp7n/W5vMBhAYAKQUkokDBysc8aWBXGZHkqipbVeX18HAYhYr9Y+ff8DJ06cqMRJv98vg5+IEFkIEUURImZZtlclhOACu93iTQCD50+sPdIhvbX4CZN+HZFSttvtkbFRKeX4yHhru/P8888XRSFJIEOeptVqVSD1B71gnNY6rmkOXE0qzWYziiJrLSA6Z8rYkJKE0CsrK3/913998v6Tp0+fnjs4Nzc395tPPpnUqmfPnn3zzbd6rR0mBgjGGGSIk0hIKotuRBS7RRAyeCjvsXxd0jxmYAbGverh10wOIDgXlFJKqdXV1YmpySRJGo1GFKvBnb5Q0jmnhRwdHZUkvHX1ai2EwD4YY+I4rtfrkdJlsvY2ZFmmlAKAoiiUUsy8s7Nz7ty5119//Z7j9zz55JOPPPpo6ajvf//7//gPP9zc3CqKAhFJYFkEleeEiOQug0ZmDszMgaB0GO65sUzJZINjQmutlFStJmXZSlRurez1et77qBJprb33tigqUeycM3nhjDXG5GnK3g/7fYGYZVkURfv27RsZaXrviEApoZSQkqy1eZ4jASCXOf3999//y7/8y+985ztXr15VSn3zm9/81re+tbh4KKlVhJaFMcbaEEIURQzgd6tV3OMdAMAcAAJACMExe0RGYmYmrTVAqNerCwsLcRwHBOdMYY33fnpmX1lxSymJaGxslJmLokCGJIoBIDgXx7ExJsuy4XCIxIRYqVTq9Xq9Xq/VaqOjo9VqtXyHiJxzcRwzs5TSGOOc+853vvPtb3/7tdde895/6cu/9ad/+qdzc3Na6zLPll++d8j31l02xXcL8V8fJGYmIRAgTM1MLR9bHhkfSZJIa01ESolHHnlocfHgdme73+8vLS1VKpWyTvHBVWtJpARyCM4SsLcmTQdxHEdRtG9memFhYX5+vtlsWmvzLPPOeWe1kqOjo81mc/nIkVqtJoSo1Wq1Wu2VV1757ne/+/rrr+d5euLUfb//B/9m/9xMWaaVnrnL+RyzZ/YAASEIAiGRBJQMvXxGZCKQ3lsimp6eLhGmsMYY49kFUFMz++YPLqz+4AeXL18+ceK+kZGR1uYWAhjrtJBeSiLy3sdxXKJLo1FHgcjU6XXf+/CDQadXqVSsMXmel9tJUiwvLz/++OPe+3fe/eXVlY+vr64qpd577704jg/sn5ufn//Nz3xmZWVle317MBiUCa3ITXlUdgWGuyeHSJTaxB6Z2BWArDfN0cbSkUWpRa1RjWMtJUVRNDIyEsfRqVMnDy8fHqSDtbW16enpickxawsiGA4HtVo1iiKlVJ7n/X5/Z6dDRFEcT81OzcxOkwAdqSwdCkGNRr3kc9ubWz97+ezf/u3fWmv//M///M/+7M8ef/zx6elpY8wbb7xx9uzZnZ0dIPjm7/3eQ489pBLlQ8jy/BPQVVIK/y8e4AHDJ4g6EzPPzs4eOXJkbGxscnKy2Wx6DlmWVepVRNRxpLXe2dl5/8P3smF/enKqmlTiOO52u1NTUxMTE+UJFkqoOBodH2uO1McnJg4sLExNTSFikiRFUbTbbed288n4+Hiv1/u7v/u755577tChQ//1L/7izJkzk5OT1Wr1hRde+Pjjj4s0r9SqJ06cGBkZUUpVq1WlVBmHe6x2j8buaQ90dwkhCAWOTYyNjI1MTE1U69UoieI4UkpWKpUkSbz33W633W13u93Lly/neTo6OhrHMYP3zsxMT4006sYWcRwfOHDg8PJSc2yUiCYmxxYOHpydnS1RuFaraa2TJBFCrK+vW1uE4H76059+8MEHlUbtj/7oj770hS9i4Nsbty/+88WiKJyxZ86cuf/++51z3W73/7Nnjwjefc1EICSKXVJBsiSejUaj2Wx2et19d9bavXZci3UkS7uZ2RsPBBsbG8H5yfEJKWWSJNdvrJ46cXLh8EF9J6o1GoeXj8wtzCmtHbv5hYXTT5yWwFrT5uamKYo0za3xWsqJiTFmHg77t9ZufPjeu0tLh/btn/3W7/9rqeh73/verbW1mzdv3nv8+MjE2OTkJBGNjIwUWVGmJgCQQuwW5gE9l9BXKkq/dpqEAABgjKmN1OYO7F+7PRPA93q9arUitSBEZ2wlTmxecAi93qDV6mgthRA2c3daG8vLyweXD5KS9508MbuwPwgmotpI7eDSfCU588/vVH91+cpOu9tp7aT9YXBsTC6lrGhFyK+d+/nJT903tW+81qw8/cxT7e2ttD/IB332FoO477773jh0/tKlS8TICN774L1QMSGxD4gcAiERMhISciAsqSDIEMLW1lav12tMjkzvmzx+4oTQot1ujzZGrSuMyScnJ21ukqRSiZNqteq8lVJWakmlEk9NTQHx/MGFe44tj01OO2cBAgIJISanpkbrycR448Txo3du3lm/eWun3U37aa/X6/V6pORgOESw2bCXF1lF1+dmZ/79v/3DSx99ND8/j1IBwNLS0r59+65du+aNg1LWRokgaFc/4dI9ZU24W63j3Up8bW2t1WrNLR2IKpUjS0tIvLGxMT87f+ToUWAgAc1mQwgxt39udnZ2anpyenp6fHy0Vqs0RppxrGWkgZCdk0oBkPXOe46UUnF1ZmJmZnzqxPKxIs+LdNjrdre3Nzc2Nra2Wjdv3er0B7dWV4fHj1eq9W5n5+ba2vz8fK1WM4MBKT0yMlJr1IGIsWwLCABiRh+AA5TiaimsIApEKh9EJJmx0+p0u13wARCJyBjTbDaTJGHnEMTc3NzExMTt27cvXrz47rvv6khVKpVqNRkZGZmfn5+dm1leXh6dGJ2cnBRCGFNIrZSW1uRo3OadzW6n1W5tbtxZK/JhNhxsbdzp9Xq5NSSiWEdpf8cVaRgOfnn+wurqDaXUwsKhBz71qVqlAgzjo2PBeSQGLjV/AsASFEoKCFDqEL+Gvl0KWBTFzs6OMUaT8t6ffens5cuXv/rVr46NjcU6OX78+NuH375y5Uocx6Yo8tSZvOi02jdu3Lh06VJSjQ8fPnz0+L0nTpxYOnI4qdWctcYVeZq++tOf9trbSoIzw5s3Vghsox5rHUZGtFL1NDOeKRIBnGGb1+Kotb1RWNPt7jD6M2eeQJ2wt81ard8fBIRPMFsBxFjqKmV+JRCIhIRIACiD85ZgdfVGe7O978BsFEXVanVjY+MnP/lJs9l8/NHT9Xp9cXHx0OLC2vVbIQSlduUKIipVuO3NrXa7bfNCKXXkyBEZ6X63+8rZn73x6rl+p31gbnpxcW5ycmKnvY7spydHrbVpmhoDlSjSinyR2iLv99rDfvvO5kZ8RNxY/fi9Zv3kAw9WEiEoCGJClIhSoNjtdSAAIEkmJpICf83/EGGXqH/00Ue/+tWvJvZNyFgvLi6Oj49/+OGHr7zySr1eP3Hy5Fe+8pWt9Y3OdrfX7X5SQZcggBAAVlauKxUtHlk+cOAgWn9j9ealS5c2Nja6re1hf0cQj45WnHPDoR0dbdZqNWYOIJWO40QnlThORJ51JVpFbmd7fWqiSZzbrOPcYHQ0YS6CZ4mURKhkWSowogBZ6l4CP5l5MUgpJWC4dXNtbW3t/uHJWqRPHL/vnaNHW63WuXPnrLW9Xu/TDzz41FNPbW+23n/3/e3tLbjb0gohCBTe+0qteuP66oU3zx8+tDg6Mb65sbG6cq3T6SRRNMyzqx9/fHB+xju/k/YC4OHDS3MHFtutnfbOThxrpRDA6QgjjfP7J4rCNqqy3bq90xodH0m0MKONyLsgQGktBEAInj0wAiAyit0uH4MHj4EDBOmc05HUWr/00ktz87NnPvPkvtm5T93/6Rs3bly5cuWtt95aXV1t/XbrgVOf+uxnPytJXLhwoSgKY0ye54mOjHdE0hgXgltfX9/c3Iyi6Ma1661WC5EH6QAgbGwV+6am8sz1+jnzMPCN48ePzcwuDHJXqVWBGOqx0qwjVDqqVKRSXkAx7G16050cT7wNeWaiqFJJasFCkRv24AIbj6E8U4QCiVEE5603UkgEgDRNQwgfvPf+8ePHxyYnPvf5z7c62+12e3t7e3Nz82/+5m8OzC389pe+fPr06TRNz58/H8exUsoVRiK5EIIJjCEdDPM0u3Pnzq1bt7JhSoJBEAbMi7zV7ufZsNfLhn3XH7o4WT985ODU9P5r128k9dqDI3UmQLLW5M654HPm7PbtldbmWr0iiBQ042qlkSRVX/iisM4Fa4LxVFg0xngfCEkIAYgAUobgEUEgWWt/8YtfVOu1r33jd5VSv/u1b0DA7/793+/s7DDzpUuX1q6vOmMfeejhEyeOX758mQiUUkmSBAQpZRSpsrDKsqzT2raukFD2JzEE7PSHJrd5xnmWW0curNRHxpaPLXX6vRtrt/bNzjB7IUkwRAq1BCV4e3s9S7uNurbW1pLq2NhIpVINlssmoCl8ajDNTDYga50gpbUWinZrPGut1hoRb9++/eMfPZfn+R/8uz9ExGeeeSYviueff357ezuu1UyaEeBbb73FzHEcJ0nSGG2MjY2pOKpUKr3ezsrHK9euXatWq6USFIItoYSk9g59IBRRsK7Xzwd5vnL9Zm2kGSe1O5vrb5y/kA47wbMUrJTu9Xa8ywf9npBMwpOzlZoYGYmSOGIfQtDGmDxzicFYwxCDtSiE1FGklBBCSILgnGEWiFip1Dqd7gs/eUnJ6Ctf/e1arfbVr35N6/jVX7y2cvVKtZpkWVYURaVSYeZWq9Xv97faWyGE4XAopSxFi+vXV0phzNoQAocAUuoQwDsOATxgqfFtbrVW127tm5kkoVeu3QQ2jUQz+wDUHQyHwyEJqNdrzptIxSMjtUYzkUJyCN6xQEJmIZEDu8IDWEEYKRdFQiiUpXqGAEVRVGp1732v1/vhD3+41W49++yzM/tnv/GNbzz06CP/9KN//OXFC5t3bse6XhSFcbbkQs45RCz1Omttt9vt9XrOuTRLhRBE0jkvSAQPe3MI1juB8vb6xsLiAgk9Pja9td3m4KpxxMFpqbQUDF5LUEpag9U4ao7UkyQCAAjkhUcGJBkGhRSFoBzBYvCEQiutIpLe7wqIRJTnealX9Xq9c+fOXb169Xe+/vVHH3103/TMH//xf7p+7erZl1588803B4NBOsiMK0ppstRJSjLTbrc3NjacN0IIb0MlqbHLAeiunigAgvWwtLS0vnU7TfOisFKSNSFNh94MmtUIhRRSSqGA2FpHQlQb9TiOiTCEQJJQIEOQSjhnvKM8QmcDeMuh4CARkMpTxN5LKW1htNbBe611p9O5cePGX/3VX/2f734XEUHQkXuP/cc/+eP/9j/++4MPPpibQik1HA5LupIkSRRFANDtdofDIYLwjgOjjiMVxQHYBh8wADFjmJ6d/vq/+vqZ33zSOm8KX5hQr40jx+1OVngcpq7bz/Mi+CBdoDiuVCo1FUUoiDEABiRGASix3qjVG9VaLY4ThZJ9KIoiy7Ih1Sp1IVRJP0stHxGNMbVaXQhJROfOnbt48SIJMoXNnV/f3Cqc11obY5QWDJ4gZMN+lmVENBxmeW48Q27s+MTU9L7ZWqOqImnZevSOgqzop77w1D33HtNRlGaWQV79+GZcGdW6kWW8sdnr9kxvx/Z2ikHPEkbV+piOEueCDR4EMYYAnoQoeWxUrTXGxxtjY3Gjhkoa9nmeSymllqrUwQBIkjDGRFFUTSoy0qPjYw8/+uj0zL7t7VarvfXmm6+//daF6ysrxrskitgHQZTnuZDCu8AI1lqhZDrMFw4tHTp0qNFoOHBpkTcqUbfbRYmnnzjzxGeenN4/m9TqvWGa5g5BtLZ6JCveicHAgctTXRgTCyGaI3WtYqU0o7XWIu6pkySFUFo645GkVJFOKt1uN08L54Iskco465wDBiScnJwcGx8/derU42d+Y37hQGOs/vbb//ziS8+//csLG3duZ2kqAIWSjgMHL0kIKbXWXnpGaO90Blk6f2j+C1/4/In7Tj333HO3bt3q9XojI42JiYl77z365S9/+dDiIggxMTFRq9XKeaKVlZWkEkmRGJOm3oqCIfBIo6KU0lqHEIzNnSkYgiCpdRzHsVKRd3kITkisiBgFheAgsHNut3dkvfPee8cC8PDi0pef/crDjzwCMdnUAkPw/ubNm3du3fbe6igCZnZcMjGTZ0SEnhBRaBVXKwcPLz399NPz8/P/89v/6/XXXze2aDabjUb95MmTv/VbzywfPQpEt1bXbt26k2VZlmUAaIyJlCKMgrUuMCJ4j0BayYikEgrAUNka954JdbVaVKvVWiIZWZBEooqIASCOtPdelm2/WEcQuCATQnj//XfHJkYZw7H7jjWao4BwbPmI/dIzU1Nj6+vrW1tbpijAAwAoIQGglIVrtdrE1OTp06dPPfBAFEU//OGPPvjoQ0SMomhmZuY3fuPx06dPH1hcZGu77fbPf/7zt99+uzzO5bhDnhmBssgBFCAiB+JAzBQ8O8dMgkQU2GV5bo1JszDo5zBZ1VpoLTkERIoqkVLCWivLmQMiKqfpjDHI/MJP/un8+Tc+9/mnHn744Uq9dujQocdPn370sYd7/X5re7vX6/V3+kVRREqXOzIzMzOzf1YpJbUOIfzf7/3D88//OE2zycnJI8tLTz/99KlTp6wtbJZ571988cVXX3213e4cmD8oper3+845b3wS1YEFBww+eEdZZtudvtai0dBCYpLUEGXwwprhcJAN+z1n+/VaJalYoVUZoqRIMknvy/k3UEox+xBclqXVei1N0//9v7/zwgsv3Hfq5JkzZyanp+r1enN0dH52Xh6QIQSBxIytVqusHm6s3tRaN8eapRa5f//+xccPn37s8XuO3gPI3jmVJNd/tfLSSy9dvHhxY2NrbHQijuNWqzUcDuM4liiD4UgqIQExBE+9bnabgzH5wsJ0rR5FFR2TdIGMD8b0szQNLk8HWRSncbVSq9WqdYwipWLA//A73wohCIFSSudMnufG2TRNmZikQBCeAwAkterCwsLy8vLhw4dnZmaIodPpbmxsXF35+Ma164WzURQtHDz49BeeOry8XOY6USpqAiDAzk57bW3txz/+8TvvvKO1juN4/+x8mqZ37qwPBgMOaDJT0VUtpVISkeOYlGYl3Oh4ZXZmbHyiMTFRjyIZ2OV5Puj2+v1+Z2s7hMAoKrVkZGRkZKTRaFaTipJlXi87UyEEpUVgF8faGOOdB9wdpUz7gysfXfrV5SvlHAxyORHIPgQpBCCOjjXHHhidGJvUQhMAkfCFF4CucOvr6+fPn3/ttdfW1taYWYLsZ/2P2h+WXQJ2PgSItCThy2FKIQQwe8cA0O4UHDqeIYoiqZSQQkVSxSK2eqQ5MRymgzTv94yz/cKyBySqS6VUOfbI7AEDB9ZaAwCHwNa6cHfaFQkZkAEDsOcQANGXrQJn/f652Xvuuef40WMTo2Pg/KA3YEYOuLm5efny5XfffXdlZaXb7Zbt2rJvi0h7MwlCkCQRSyEEkij1YQQGYMGehwO30xlWk1gqqtYkEiaVWEopMQAmNvTSPO/28sIBAHrHUinlnAPPAYL3DD5orUEDMDEQuuCZISAScWAAJKayhVgOzQHRyOjYPUfu2T+zf+PO5muDc1JK722a5rdvr6/f2bh9+3av1yuKohwj2tVCAjAELkdHUQohpCQtJSGWXVdGERgxIGDwTIOh7+wMoookWdERA6JSURyjMyovIC8oM2lucwDhA5XjH8wIzpf9NQwhCEClVDnMa13w3rsQyoEXplLaLGGSAODIkSPjY5NFbrvd20pJrWW337tx40ar1RkOUmet0jrSujAmeA8AwfvATIhcUhpBSkilBO72WwlK2Q6pDHJBEQfOMz8cFEmikYiDN5mxGeXGB48MIgRpre1C4QNJiSSEDEhIpXRUTiOjIiEEKBVJ540x5BxT2T/k3flKEOWw84ULF6embtRqNSQeDPo7O+3SXGaUQkrANM/ZeVJSADrnXOFQCKmUJKWlRCEkkQARnN3trKD49QQuCB8gABgfhpmtFy5OKta6YZoO2iZLfZaZzARrILdcWGsNyz25B3D3ddkLAkaJIiCSEkTSe8/sS5IMABwwULmjIKVstTqbm9taS8BgrVNKeO9d4aX0RKRIhJKuBR9CKOd94jguG7J8dzy6hBwEQiIEgUCIDICAAZE4gCl8lvok4RCkdyJN00Hf9IfGOvZBuoBEoiD6f2KBOkeXwwh4AAAAAElFTkSuQmCC'



    CONFESSION_HOLD_TIMEOUT = 1.60

    CONFESSION_CORE_X0 = 1633
    CONFESSION_CORE_Y0 = 1996
    CONFESSION_CORE_X1 = 2160
    CONFESSION_CORE_Y1 = 2016

    CONFESSION_CORE_BLUE_HSV_LOWER = (95, 45, 90)
    CONFESSION_CORE_BLUE_HSV_UPPER = (150, 255, 255)

    CONFESSION_CORE_BLUE_STRONG_RATIO_MIN = 0.12
    CONFESSION_CORE_BLUE_WEAK_RATIO_MIN = 0.075
    CONFESSION_CORE_COLUMN_PIXEL_RATIO_MIN = 0.20
    CONFESSION_CORE_STRONG_ACTIVE_COLUMN_FRACTION_MIN = 0.20
    CONFESSION_CORE_WEAK_ACTIVE_COLUMN_FRACTION_MIN = 0.12

    CONFESSION_SEGMENT_CONFIRM_FRAMES = 2
    CONFESSION_STRONG_BLUE_CONFIRM_FRAMES = 3
    CONFESSION_RING_ARM_CONFIRM_FRAMES = 1
    CONFESSION_RING_FALL_CONFIRM_FRAMES = 2
    CONFESSION_RING_WEAK_BLUE_RECENCY = 0.40

    P2_CONFESSION_PRAYER_REFILL = 24.0
    P2_CONFESSION_AZ_THRESHOLD = 1.60   # 预计还差更多时间 -> 光主AZ一次
    P2_CONFESSION_A_WAIT_GAP = 0.18     # 差得不多 -> 菲比A一下再复查
    P2_CONFESSION_FAILED_PROBE_BACKOFF = 0.80
    P2_CONFESSION_E_READY_FRAMES = 2

    # P2时间更宽裕：不允许任何单一视觉信号单独授权告解R。
    P2_CONFESSION_ENTRY_SUPPORT_FRAMES = 2
    P2_CONFESSION_ENTRY_FALL_RECENCY = 0.50
    P2_CONFESSION_ENTRY_FALLBACK_RING_CLEAR_FRAMES = 2
    P2_CONFESSION_PRE_R_CONFIRM_FRAMES = 2
    P2_CONFESSION_PRE_R_TRANSITION_BACKED_FRAMES = 3
    P2_CONFESSION_PRE_R_TIMEOUT = 0.45
    P2_CONFESSION_PRE_R_MAX_FAILED_SLICES = 3

    THREE_A_GAP = 0.12
    P2_STAR_NOT_READY_CONFIRM_FRAMES = 3
    P2_STAR_CONFIRM_TIMEOUT = 0.75
    P2_FINAL_EMPTY_CONFIRM_FRAMES = 3
    P2_FINAL_EMPTY_TIMEOUT = 0.80

    # P2菲比E1：V4.3显式图标one-shot。只有识别到E1才发送一次E；
    # 识别到E2则直接锁死本轮并禁止E输入，UNKNOWN不猜。
    P2_E1_ATTEMPTED_KEY = 'p2_phoebe_e1_attempted'
    P2_E1_PENDING_KEY = 'p2_phoebe_e1_pending'
    P2_E1_CONFIRMED_KEY = 'p2_phoebe_e1_confirmed'
    P2_E1_INPUT_AT_KEY = 'p2_phoebe_e1_input_at'

    CONCERTO_FILL_TIMEOUT = 9.0
    FULL_CON_TAIL = 0.20
    REQUIRED_E_TIMEOUT = 1.6
    REQUIRED_Q_TIMEOUT = 1.6

    # V4.3 confirmation tiers (P1 + selected P2 opportunity actions):
    # HARD_GATE = state-changing actions must be proven.
    # SOFT_COMMIT = once a legal input window exists, send once and advance without waiting for post-cast UI proof.
    SOFT_COMMIT_POLL = 0.02
    SOFT_COMMIT_READY_WINDOW = 0.30
    SOFT_COMMIT_SETTLE = 0.04
    P1_SOFT_COMMIT_POLL = SOFT_COMMIT_POLL
    P1_SOFT_COMMIT_READY_WINDOW = SOFT_COMMIT_READY_WINDOW
    P1_SOFT_COMMIT_SETTLE = SOFT_COMMIT_SETTLE
    P1_OPEN_CONFESSION_PROOF_FRESH = 0.45

    P1_CONFESSION_R_READY_FRAMES = 2
    P1_CONFESSION_R_WAIT_SLICE = 0.80
    P1_CONFESSION_R_FAST_RETRY_POLL = 0.03
    P1_CONFESSION_R_FAST_RETRY_WINDOW = 0.55

    # P1同样禁止“R亮了就放”。时间比P2紧，因此复核窗口更短，
    # 但仍要求“进入告解证据 + R前当前告解证据”两阶段成立。
    P1_CONFESSION_ENTRY_SUPPORT_FRAMES = 1
    P1_CONFESSION_ENTRY_FALL_RECENCY = 0.45
    P1_CONFESSION_ENTRY_FALLBACK_RING_CLEAR_FRAMES = 2
    P1_CONFESSION_PRE_R_CONFIRM_FRAMES = 2
    P1_CONFESSION_PRE_R_TRANSITION_BACKED_FRAMES = 2
    P1_CONFESSION_PRE_R_TIMEOUT = 0.30
    P1_CONFESSION_PRE_R_MAX_FAILED_SLICES = 2


    def f_break(
        self,
        check_f_on_switch=False,
        force=False,
    ):
        if self._zfg_team_matches():
            return False
        return super().f_break(
            check_f_on_switch=check_f_on_switch,
            force=force,
        )

    def do_perform(self):
        if not self._zfg_team_matches():
            return super().do_perform()

        if (
            getattr(self, 'team', 0) != 1
            or getattr(self, 'attribute', 0) != 2
        ):
            self.decide_teammate()

        state = self._zfg_state()

        if self._run_detour_if_needed(state):
            return

        step = state.get('step')
        self.logger.info(
            f'ZFG V4.4 Phoebe step={step} phase={state.get("phase")} '
            f'intro={self.has_intro} forte={self.is_forte_full()} '
            f'con={self._read_concerto():.3f}'
        )

        if step == self.STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER:
            return self._p1_confession_r_eq_to_rover(state)

        if step == self.STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI:
            return self._p1_3a_star_save_fill_to_zani(state)

        if step == self.STEP_P1_PHOEBE_STAR_E1_TO_ZANI:
            return self._p1_star_e1_to_zani(state)

        if step == self.STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI:
            return self._confession_r_to_target(
                state,
                target='Zani',
                next_step=self.STEP_P1_ZANI_N4_R2_EA_TO_PHOEBE,
                tag='P1-before-N4',
            )

        if step == self.STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI:
            return self._p2_double_star_fill_to_zani(state)

        if step == self.STEP_P2_PHOEBE_CONFESSION_CHECK:
            return self._p2_confession_check(state)

        if step == self.STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI:
            return self._p2_confession_r_to_zani(state)

        if step == self.STEP_RECOVER_P2_PHOEBE:
            self.logger.warning(
                'ZFG V4.4 RECOVER_P2_PHOEBE '
                '-> P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI'
            )
            self._advance_step(
                state,
                self.STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI,
            )
            return

        return self._recover_wrong_actor(state)


    def _read_confession_forte_segments(self):
        """读取菲比告解形态的两格蓝色特殊能量。

        继续复用OK-WW原版Phoebe.judge_forte()：
        attribute=2时会在血条上方forte区域按两格统计蓝色能量。
        V4.3把它作为辅助证据；新增主证据是整个forte条的蓝色像素占比。
        """
        if self.attribute != 2:
            self.attribute = 2
        try:
            segments = int(self.judge_forte())
        except Exception as exc:
            self.logger.debug(
                f'ZFG V4.4 Phoebe confession forte segment read failed: {exc}'
            )
            return 0
        return max(0, min(2, segments))

    def _read_confession_blue_bar_evidence(self):
        try:
            box = self.task.box_of_screen_scaled(
                3840, 2160,
                self.CONFESSION_CORE_X0, self.CONFESSION_CORE_Y0,
                self.CONFESSION_CORE_X1, self.CONFESSION_CORE_Y1,
                name='phoebe_confession_core_blue_bar', hcenter=True,
            )
            cropped = box.crop_frame(self.task.frame)
            if cropped is None or getattr(cropped, 'size', 0) == 0:
                return False, False, 0.0, 0, 0, 0

            hsv = cv2.cvtColor(cropped, cv2.COLOR_BGR2HSV)
            lower = np.array(self.CONFESSION_CORE_BLUE_HSV_LOWER, dtype=np.uint8)
            upper = np.array(self.CONFESSION_CORE_BLUE_HSV_UPPER, dtype=np.uint8)
            mask = cv2.inRange(hsv, lower, upper)

            ratio = float(np.count_nonzero(mask)) / float(mask.size)
            column_ratio = np.count_nonzero(mask, axis=0) / float(mask.shape[0])
            active_cols = int(np.count_nonzero(
                column_ratio >= self.CONFESSION_CORE_COLUMN_PIXEL_RATIO_MIN
            ))
            width = int(mask.shape[1])
            weak_required = max(6, int(round(
                width * self.CONFESSION_CORE_WEAK_ACTIVE_COLUMN_FRACTION_MIN
            )))
            strong_required = max(6, int(round(
                width * self.CONFESSION_CORE_STRONG_ACTIVE_COLUMN_FRACTION_MIN
            )))

            weak_ok = (
                ratio >= self.CONFESSION_CORE_BLUE_WEAK_RATIO_MIN
                and active_cols >= weak_required
            )
            strong_ok = (
                ratio >= self.CONFESSION_CORE_BLUE_STRONG_RATIO_MIN
                and active_cols >= strong_required
            )

            box.confidence = ratio
            try:
                self.task.draw_boxes('phoebe_confession_core_blue_bar', box)
            except Exception:
                pass

            return (
                bool(strong_ok), bool(weak_ok), ratio, active_cols,
                weak_required, strong_required,
            )
        except Exception as exc:
            self.logger.debug(
                f'ZFG V4.4 Phoebe confession blue-bar read failed: {exc}'
            )
            return False, False, 0.0, 0, 0, 0

    def _read_confession_ring_visible(self):
        checker = getattr(self, 'confession_ready', None)
        if not callable(checker):
            return False
        try:
            return bool(checker())
        except Exception as exc:
            self.logger.debug(
                f'ZFG V4.4 Phoebe confession ring read failed: {exc}'
            )
            return False

    def _finalize_confession_state_success(
        self, state, key, via, segments, strong_blue, weak_blue,
        blue_ratio, active_cols, weak_required, strong_required,
        ring_armed=False, ring_fall=False,
    ):
        self.task.send_key_up(key)
        state.pop(self.PHOEBE_PREHOLD_E_KEY, None)
        state.pop(self.PHOEBE_PREHOLD_SOURCE_KEY, None)
        state.pop(self.P1_PHOEBE_FORTE_EXPECTED_EMPTY_KEY, None)

        state[self.PHOEBE_LAST_CONFESSION_TIME_KEY] = time.time()
        self.logger.info(
            f'ZFG V4.4 Phoebe CONFESSION STATE CONFIRMED via={via} '
            f'segments={segments}/2 strong_blue={strong_blue} weak_blue={weak_blue} '
            f'ratio={blue_ratio:.3f} active_cols={active_cols} '
            f'weak_need={weak_required} strong_need={strong_required} '
            f'ring_armed={ring_armed} ring_fall={ring_fall} -> release held E'
        )

        self.star_available = True
        self.reset_action(new_rotation=False)
        self._refill_form_charges()
        self.state['enter_status'] += 1
        return True

    def _hold_e_until_confession_state(self):
        if self.attribute != 2:
            self.attribute = 2

        state = self._zfg_state()
        key = self.get_resonance_key()
        start = time.time()
        inherited_prehold = bool(state.get(self.PHOEBE_PREHOLD_E_KEY))

        segment_frames = 0
        strong_blue_frames = 0
        ring_visible_frames = 0
        ring_clear_frames = 0
        ring_armed = False
        ring_fall_time = -100.0
        last_weak_blue_time = -100.0
        last_fusion_log = -100.0

        self.task.send_key_down(key)
        self.logger.info(
            'ZFG V4.4 Phoebe confession hold START visual-fusion '
            f'inherited_prehold={inherited_prehold}'
        )

        last = {
            'segments': 0, 'strong': False, 'weak': False, 'ratio': 0.0,
            'active': 0, 'weak_need': 0, 'strong_need': 0,
            'ring': False,
        }

        try:
            while time.time() - start < self.CONFESSION_HOLD_TIMEOUT:
                self.task.next_frame()
                now = time.time()

                segments = self._read_confession_forte_segments()
                (
                    strong_blue, weak_blue, blue_ratio, active_cols,
                    weak_required, strong_required,
                ) = self._read_confession_blue_bar_evidence()
                ring_visible = self._read_confession_ring_visible()

                last.update(
                    segments=segments, strong=strong_blue, weak=weak_blue,
                    ratio=blue_ratio, active=active_cols,
                    weak_need=weak_required, strong_need=strong_required,
                    ring=ring_visible,
                )

                if segments >= 1:
                    segment_frames += 1
                else:
                    segment_frames = 0
                if segment_frames >= self.CONFESSION_SEGMENT_CONFIRM_FRAMES:
                    return self._finalize_confession_state_success(
                        state, key, 'FORTE_SEGMENTS', segments,
                        strong_blue, weak_blue, blue_ratio, active_cols,
                        weak_required, strong_required, ring_armed, False,
                    )

                if strong_blue:
                    strong_blue_frames += 1
                else:
                    strong_blue_frames = 0
                if strong_blue_frames >= self.CONFESSION_STRONG_BLUE_CONFIRM_FRAMES:
                    return self._finalize_confession_state_success(
                        state, key, 'STRONG_BLUE_BAR', segments,
                        strong_blue, weak_blue, blue_ratio, active_cols,
                        weak_required, strong_required, ring_armed, False,
                    )

                if weak_blue:
                    last_weak_blue_time = now

                if not ring_armed:
                    if ring_visible:
                        ring_visible_frames += 1
                        if ring_visible_frames >= self.CONFESSION_RING_ARM_CONFIRM_FRAMES:
                            ring_armed = True
                            ring_clear_frames = 0
                            self.logger.info(
                                'ZFG V4.4 Phoebe confession ring ARMED (auxiliary)'
                            )
                    else:
                        ring_visible_frames = 0
                else:
                    if ring_visible:
                        ring_clear_frames = 0
                    else:
                        ring_clear_frames += 1
                        if ring_clear_frames >= self.CONFESSION_RING_FALL_CONFIRM_FRAMES:
                            ring_fall_time = now
                            ring_armed = False
                            ring_visible_frames = 0
                            ring_clear_frames = 0
                            self.logger.info(
                                'ZFG V4.4 Phoebe confession ring FALL (auxiliary)'
                            )

                ring_fall_recent = (
                    now - ring_fall_time <= self.CONFESSION_RING_WEAK_BLUE_RECENCY
                )
                weak_blue_recent = (
                    now - last_weak_blue_time <= self.CONFESSION_RING_WEAK_BLUE_RECENCY
                )
                if ring_fall_recent and weak_blue_recent:
                    return self._finalize_confession_state_success(
                        state, key, 'RING_FALL_PLUS_WEAK_BLUE', segments,
                        strong_blue, weak_blue, blue_ratio, active_cols,
                        weak_required, strong_required, True, True,
                    )

                if (
                    segments >= 1 or strong_blue or weak_blue or ring_visible or ring_fall_recent
                ) and now - last_fusion_log >= 0.12:
                    self.logger.info(
                        f'ZFG V4.4 Phoebe confession fusion sample '
                        f'seg={segments}/2 seg_frames={segment_frames}/'
                        f'{self.CONFESSION_SEGMENT_CONFIRM_FRAMES} '
                        f'strong={strong_blue} strong_frames={strong_blue_frames}/'
                        f'{self.CONFESSION_STRONG_BLUE_CONFIRM_FRAMES} '
                        f'weak={weak_blue} ratio={blue_ratio:.3f} '
                        f'cols={active_cols} weak_need={weak_required} strong_need={strong_required} '
                        f'ring={ring_visible} armed={ring_armed} fall_recent={ring_fall_recent}'
                    )
                    last_fusion_log = now

                self.sleep(0.01)
        finally:
            self.task.send_key_up(key)
            state.pop(self.PHOEBE_PREHOLD_E_KEY, None)
            state.pop(self.PHOEBE_PREHOLD_SOURCE_KEY, None)

        self.logger.warning(
            f'ZFG V4.4 Phoebe confession visual-fusion timeout '
            f'segments={last["segments"]}/2 strong={last["strong"]} weak={last["weak"]} '
            f'ratio={last["ratio"]:.3f} active_cols={last["active"]} '
            f'weak_need={last["weak_need"]} strong_need={last["strong_need"]} '
            f'ring={last["ring"]} inherited_prehold={inherited_prehold}'
        )
        return False

    def _clear_p1_confession_proof(self, state):
        for key in (
            'p1_confession_entry_verified',
            'p1_confession_entry_transition',
            'p1_confession_entry_via',
            'p1_confession_pre_r_failed_slices',
        ):
            state.pop(key, None)

    def _hold_e_until_p1_confession_guarded(self, tag):
        """P1告解入口保护。

        正常路径：
            E圈 ARMED -> FALL
            +（两格能量稳定 或 强蓝条稳定）

        若切入时漏掉E圈转换：
            两格能量稳定 + 强蓝条稳定 + E圈当前消失

        预输入标记只表示“应继续按E”，绝不作为告解成功证据。
        """
        if self.attribute != 2:
            self.attribute = 2

        state = self._zfg_state()
        self._clear_p1_confession_proof(state)

        key = self.get_resonance_key()
        start = time.time()
        inherited_prehold = bool(state.get(self.PHOEBE_PREHOLD_E_KEY))

        segment_frames = 0
        strong_blue_frames = 0
        ring_visible_frames = 0
        ring_clear_frames = 0
        ring_absent_frames = 0
        ring_armed = False
        ring_fall_time = -100.0
        transition_support_frames = 0
        fallback_joint_frames = 0
        last_log = -100.0

        # 无论赞妮侧预输入是否真的被游戏吃到，菲比上场后都重新assert E。
        self.task.send_key_down(key)
        self.logger.info(
            f'ZFG V4.4 Phoebe {tag}: P1 confession GUARDED hold START '
            f'inherited_prehold={inherited_prehold}'
        )

        last = {
            'segments': 0,
            'strong': False,
            'weak': False,
            'ratio': 0.0,
            'active': 0,
            'ring': False,
        }

        try:
            while time.time() - start < self.CONFESSION_HOLD_TIMEOUT:
                self.task.next_frame()
                now = time.time()

                segments = self._read_confession_forte_segments()
                (
                    strong_blue, weak_blue, blue_ratio, active_cols,
                    weak_required, strong_required,
                ) = self._read_confession_blue_bar_evidence()
                ring_visible = self._read_confession_ring_visible()

                last.update(
                    segments=segments,
                    strong=strong_blue,
                    weak=weak_blue,
                    ratio=blue_ratio,
                    active=active_cols,
                    ring=ring_visible,
                )

                segment_frames = segment_frames + 1 if segments >= 1 else 0
                strong_blue_frames = (
                    strong_blue_frames + 1 if strong_blue else 0
                )
                ring_absent_frames = (
                    0 if ring_visible else ring_absent_frames + 1
                )

                if not ring_armed:
                    if ring_visible:
                        ring_visible_frames += 1
                        if (
                            ring_visible_frames
                            >= self.CONFESSION_RING_ARM_CONFIRM_FRAMES
                        ):
                            ring_armed = True
                            ring_clear_frames = 0
                            self.logger.info(
                                f'ZFG V4.4 Phoebe {tag}: P1 confession ring ARMED'
                            )
                    else:
                        ring_visible_frames = 0
                else:
                    if ring_visible:
                        ring_clear_frames = 0
                    else:
                        ring_clear_frames += 1
                        if (
                            ring_clear_frames
                            >= self.CONFESSION_RING_FALL_CONFIRM_FRAMES
                        ):
                            ring_fall_time = now
                            ring_armed = False
                            ring_visible_frames = 0
                            ring_clear_frames = 0
                            self.logger.info(
                                f'ZFG V4.4 Phoebe {tag}: P1 confession ring FALL'
                            )

                ring_fall_recent = (
                    now - ring_fall_time
                    <= self.P1_CONFESSION_ENTRY_FALL_RECENCY
                )
                current_support = (
                    segment_frames >= self.CONFESSION_SEGMENT_CONFIRM_FRAMES
                    or strong_blue_frames
                    >= self.CONFESSION_STRONG_BLUE_CONFIRM_FRAMES
                )

                if ring_fall_recent and current_support:
                    transition_support_frames += 1
                else:
                    transition_support_frames = 0

                if (
                    transition_support_frames
                    >= self.P1_CONFESSION_ENTRY_SUPPORT_FRAMES
                ):
                    if (
                        segment_frames >= self.CONFESSION_SEGMENT_CONFIRM_FRAMES
                        and strong_blue_frames
                        >= self.CONFESSION_STRONG_BLUE_CONFIRM_FRAMES
                    ):
                        via = 'P1_RING_FALL_PLUS_SEGMENT_AND_STRONG_BLUE'
                    elif (
                        segment_frames
                        >= self.CONFESSION_SEGMENT_CONFIRM_FRAMES
                    ):
                        via = 'P1_RING_FALL_PLUS_SEGMENTS'
                    else:
                        via = 'P1_RING_FALL_PLUS_STRONG_BLUE'

                    state['p1_confession_entry_verified'] = True
                    state['p1_confession_entry_transition'] = True
                    state['p1_confession_entry_via'] = via
                    state['p1_confession_pre_r_failed_slices'] = 0
                    return self._finalize_confession_state_success(
                        state,
                        key,
                        via,
                        segments,
                        strong_blue,
                        weak_blue,
                        blue_ratio,
                        active_cols,
                        weak_required,
                        strong_required,
                        True,
                        True,
                    )

                fallback_ok = (
                    segment_frames >= self.CONFESSION_SEGMENT_CONFIRM_FRAMES
                    and strong_blue_frames
                    >= self.CONFESSION_STRONG_BLUE_CONFIRM_FRAMES
                    and ring_absent_frames
                    >= self.P1_CONFESSION_ENTRY_FALLBACK_RING_CLEAR_FRAMES
                )
                fallback_joint_frames = (
                    fallback_joint_frames + 1 if fallback_ok else 0
                )

                if (
                    fallback_joint_frames
                    >= self.P1_CONFESSION_ENTRY_SUPPORT_FRAMES
                ):
                    via = 'P1_SEGMENT_AND_STRONG_BLUE_RING_CLEAR_FALLBACK'
                    state['p1_confession_entry_verified'] = True
                    state['p1_confession_entry_transition'] = False
                    state['p1_confession_entry_via'] = via
                    state['p1_confession_pre_r_failed_slices'] = 0
                    return self._finalize_confession_state_success(
                        state,
                        key,
                        via,
                        segments,
                        strong_blue,
                        weak_blue,
                        blue_ratio,
                        active_cols,
                        weak_required,
                        strong_required,
                        False,
                        False,
                    )

                if (
                    segments >= 1
                    or strong_blue
                    or weak_blue
                    or ring_visible
                    or ring_fall_recent
                ) and now - last_log >= 0.12:
                    self.logger.info(
                        f'ZFG V4.4 Phoebe {tag}: P1 confession guarded sample '
                        f'seg={segments}/2 '
                        f'seg_frames={segment_frames}/'
                        f'{self.CONFESSION_SEGMENT_CONFIRM_FRAMES} '
                        f'strong={strong_blue} '
                        f'strong_frames={strong_blue_frames}/'
                        f'{self.CONFESSION_STRONG_BLUE_CONFIRM_FRAMES} '
                        f'weak={weak_blue} ratio={blue_ratio:.3f} '
                        f'cols={active_cols} ring={ring_visible} '
                        f'armed={ring_armed} fall_recent={ring_fall_recent} '
                        f'transition_support={transition_support_frames}/'
                        f'{self.P1_CONFESSION_ENTRY_SUPPORT_FRAMES} '
                        f'fallback_joint={fallback_joint_frames}/'
                        f'{self.P1_CONFESSION_ENTRY_SUPPORT_FRAMES}'
                    )
                    last_log = now

                self.sleep(0.01)
        finally:
            self.task.send_key_up(key)
            state.pop(self.PHOEBE_PREHOLD_E_KEY, None)
            state.pop(self.PHOEBE_PREHOLD_SOURCE_KEY, None)

        self._clear_p1_confession_proof(state)
        self.logger.warning(
            f'ZFG V4.4 Phoebe {tag}: P1 confession GUARDED timeout '
            f'segments={last["segments"]}/2 '
            f'strong={last["strong"]} weak={last["weak"]} '
            f'ratio={last["ratio"]:.3f} active_cols={last["active"]} '
            f'ring={last["ring"]}'
        )
        return False

    def _confirm_p1_confession_current_before_r(self, state, tag):
        """P1第二道保护：R真正输入前再次确认“当前仍在告解”。

        有完整 ARMED->FALL 入口证据时：
            当前 segments 或 strong-blue 至少一路稳定 + E圈保持消失。

        若入口只走了漏帧兜底：
            必须 segments AND strong-blue 同时稳定。
        """
        if not state.get('p1_confession_entry_verified'):
            self.logger.warning(
                f'ZFG V4.4 Phoebe {tag}: P1 pre-R gate missing entry proof '
                '-> R BLOCKED'
            )
            return False

        transition_verified = bool(
            state.get('p1_confession_entry_transition')
        )
        start = time.time()
        strict_frames = 0
        transition_backed_frames = 0
        last_log = -100.0

        while time.time() - start < self.P1_CONFESSION_PRE_R_TIMEOUT:
            self.task.next_frame()

            segments = self._read_confession_forte_segments()
            (
                strong_blue, weak_blue, blue_ratio, active_cols,
                weak_required, strong_required,
            ) = self._read_confession_blue_bar_evidence()
            ring_visible = self._read_confession_ring_visible()

            strict_ok = segments >= 1 and strong_blue
            strict_frames = strict_frames + 1 if strict_ok else 0

            transition_backed_ok = (
                transition_verified
                and not ring_visible
                and (segments >= 1 or strong_blue)
            )
            transition_backed_frames = (
                transition_backed_frames + 1
                if transition_backed_ok
                else 0
            )

            if strict_frames >= self.P1_CONFESSION_PRE_R_CONFIRM_FRAMES:
                self.logger.info(
                    f'ZFG V4.4 Phoebe {tag}: '
                    f'P1 PRE-R CONFESSION CONFIRMED '
                    f'via=SEGMENTS_AND_STRONG_BLUE '
                    f'frames={strict_frames} seg={segments}/2 '
                    f'ratio={blue_ratio:.3f} cols={active_cols} '
                    f'ring={ring_visible}'
                )
                return True

            if (
                transition_backed_frames
                >= self.P1_CONFESSION_PRE_R_TRANSITION_BACKED_FRAMES
            ):
                self.logger.info(
                    f'ZFG V4.4 Phoebe {tag}: '
                    f'P1 PRE-R CONFESSION CONFIRMED '
                    f'via=TRANSITION_BACKED_CURRENT_SUPPORT '
                    f'frames={transition_backed_frames} seg={segments}/2 '
                    f'strong={strong_blue} weak={weak_blue} '
                    f'ratio={blue_ratio:.3f} cols={active_cols} '
                    f'ring={ring_visible}'
                )
                return True

            now = time.time()
            if (
                segments >= 1
                or strong_blue
                or weak_blue
                or ring_visible
            ) and now - last_log >= 0.10:
                self.logger.info(
                    f'ZFG V4.4 Phoebe {tag}: P1 pre-R sample '
                    f'seg={segments}/2 strong={strong_blue} weak={weak_blue} '
                    f'ratio={blue_ratio:.3f} cols={active_cols} '
                    f'ring={ring_visible} '
                    f'transition_verified={transition_verified} '
                    f'strict={strict_frames}/'
                    f'{self.P1_CONFESSION_PRE_R_CONFIRM_FRAMES} '
                    f'transition_backed={transition_backed_frames}/'
                    f'{self.P1_CONFESSION_PRE_R_TRANSITION_BACKED_FRAMES}'
                )
                last_log = now

            self.sleep(0.02)

        self.logger.warning(
            f'ZFG V4.4 Phoebe {tag}: '
            'P1 PRE-R confession current-state NOT confirmed -> R BLOCKED'
        )
        return False

    def _handle_p1_confession_pre_r_failure(self, state, tag):
        """R前复核失败时不放R；必要时重新执行一次菲比E告解入口。"""
        failed = int(
            state.get('p1_confession_pre_r_failed_slices', 0) or 0
        ) + 1
        state['p1_confession_pre_r_failed_slices'] = failed

        if failed < self.P1_CONFESSION_PRE_R_MAX_FAILED_SLICES:
            self.logger.info(
                f'ZFG V4.4 Phoebe {tag}: P1 pre-R gate failed '
                f'{failed}/{self.P1_CONFESSION_PRE_R_MAX_FAILED_SLICES} '
                '-> keep r_cancel and recheck; R remains blocked'
            )
            return

        # 只有E已经再次可用时才重做告解入口；否则继续挡住R并等待下一次复核。
        if self.resonance_available():
            self.logger.warning(
                f'ZFG V4.4 Phoebe {tag}: P1 pre-R gate failed {failed} slices '
                'and E is READY -> restart confession proof'
            )
            self._clear_p1_confession_proof(state)
            state['phase'] = 'confession'
            return

        self.logger.warning(
            f'ZFG V4.4 Phoebe {tag}: P1 pre-R gate failed {failed} slices '
            'but E is not READY -> keep R blocked; wait for current-state proof'
        )


    def _clear_p2_confession_proof(self, state):
        for key in (
            'p2_confession_entry_verified',
            'p2_confession_entry_transition',
            'p2_confession_entry_via',
            'p2_confession_pre_r_failed_slices',
        ):
            state.pop(key, None)

    def _hold_e_until_p2_confession_strict(self):
        """P2严格入口门：先证明进入告解，再允许进入R等待阶段。

        正常路径：E圈 ARMED->FALL +（两格能量 或 强蓝条）的稳定当前证据。
        转换漏帧兜底：两格能量 + 强蓝条 + E圈当前消失同时稳定。
        弱蓝条和R READY只做辅助/日志，不能单独放行。
        """
        if self.attribute != 2:
            self.attribute = 2

        state = self._zfg_state()
        self._clear_p2_confession_proof(state)
        key = self.get_resonance_key()
        start = time.time()
        inherited_prehold = bool(state.get(self.PHOEBE_PREHOLD_E_KEY))

        segment_frames = 0
        strong_blue_frames = 0
        ring_visible_frames = 0
        ring_clear_frames = 0
        ring_absent_frames = 0
        ring_armed = False
        ring_fall_time = -100.0
        transition_support_frames = 0
        fallback_joint_frames = 0
        last_log = -100.0

        self.task.send_key_down(key)
        self.logger.info(
            'ZFG V4.4 P2 confession STRICT hold START '
            f'inherited_prehold={inherited_prehold}'
        )

        last = {
            'segments': 0, 'strong': False, 'weak': False, 'ratio': 0.0,
            'active': 0, 'ring': False,
        }

        try:
            while time.time() - start < self.CONFESSION_HOLD_TIMEOUT:
                self.task.next_frame()
                now = time.time()

                segments = self._read_confession_forte_segments()
                (
                    strong_blue, weak_blue, blue_ratio, active_cols,
                    weak_required, strong_required,
                ) = self._read_confession_blue_bar_evidence()
                ring_visible = self._read_confession_ring_visible()

                last.update(
                    segments=segments, strong=strong_blue, weak=weak_blue,
                    ratio=blue_ratio, active=active_cols, ring=ring_visible,
                )

                segment_frames = segment_frames + 1 if segments >= 1 else 0
                strong_blue_frames = strong_blue_frames + 1 if strong_blue else 0
                ring_absent_frames = 0 if ring_visible else ring_absent_frames + 1

                if not ring_armed:
                    if ring_visible:
                        ring_visible_frames += 1
                        if ring_visible_frames >= self.CONFESSION_RING_ARM_CONFIRM_FRAMES:
                            ring_armed = True
                            ring_clear_frames = 0
                            self.logger.info('ZFG V4.4 P2 confession ring ARMED')
                    else:
                        ring_visible_frames = 0
                else:
                    if ring_visible:
                        ring_clear_frames = 0
                    else:
                        ring_clear_frames += 1
                        if ring_clear_frames >= self.CONFESSION_RING_FALL_CONFIRM_FRAMES:
                            ring_fall_time = now
                            ring_armed = False
                            ring_visible_frames = 0
                            ring_clear_frames = 0
                            self.logger.info('ZFG V4.4 P2 confession ring FALL')

                ring_fall_recent = (
                    now - ring_fall_time <= self.P2_CONFESSION_ENTRY_FALL_RECENCY
                )
                current_support = (
                    segment_frames >= self.CONFESSION_SEGMENT_CONFIRM_FRAMES
                    or strong_blue_frames >= self.CONFESSION_STRONG_BLUE_CONFIRM_FRAMES
                )
                if ring_fall_recent and current_support:
                    transition_support_frames += 1
                else:
                    transition_support_frames = 0

                if transition_support_frames >= self.P2_CONFESSION_ENTRY_SUPPORT_FRAMES:
                    if (
                        segment_frames >= self.CONFESSION_SEGMENT_CONFIRM_FRAMES
                        and strong_blue_frames >= self.CONFESSION_STRONG_BLUE_CONFIRM_FRAMES
                    ):
                        via = 'P2_RING_FALL_PLUS_SEGMENT_AND_STRONG_BLUE'
                    elif segment_frames >= self.CONFESSION_SEGMENT_CONFIRM_FRAMES:
                        via = 'P2_RING_FALL_PLUS_SEGMENTS'
                    else:
                        via = 'P2_RING_FALL_PLUS_STRONG_BLUE'

                    state['p2_confession_entry_verified'] = True
                    state['p2_confession_entry_transition'] = True
                    state['p2_confession_entry_via'] = via
                    state['p2_confession_pre_r_failed_slices'] = 0
                    return self._finalize_confession_state_success(
                        state, key, via, segments,
                        strong_blue, weak_blue, blue_ratio, active_cols,
                        weak_required, strong_required, True, True,
                    )

                fallback_ok = (
                    segment_frames >= self.CONFESSION_SEGMENT_CONFIRM_FRAMES
                    and strong_blue_frames >= self.CONFESSION_STRONG_BLUE_CONFIRM_FRAMES
                    and ring_absent_frames >= self.P2_CONFESSION_ENTRY_FALLBACK_RING_CLEAR_FRAMES
                )
                fallback_joint_frames = fallback_joint_frames + 1 if fallback_ok else 0

                if fallback_joint_frames >= self.P2_CONFESSION_ENTRY_SUPPORT_FRAMES:
                    via = 'P2_SEGMENT_AND_STRONG_BLUE_RING_CLEAR_FALLBACK'
                    state['p2_confession_entry_verified'] = True
                    state['p2_confession_entry_transition'] = False
                    state['p2_confession_entry_via'] = via
                    state['p2_confession_pre_r_failed_slices'] = 0
                    return self._finalize_confession_state_success(
                        state, key, via, segments,
                        strong_blue, weak_blue, blue_ratio, active_cols,
                        weak_required, strong_required, False, False,
                    )

                if (
                    segments >= 1 or strong_blue or weak_blue
                    or ring_visible or ring_fall_recent
                ) and now - last_log >= 0.12:
                    self.logger.info(
                        f'ZFG V4.4 P2 confession STRICT sample '
                        f'seg={segments}/2 seg_frames={segment_frames}/'
                        f'{self.CONFESSION_SEGMENT_CONFIRM_FRAMES} '
                        f'strong={strong_blue} strong_frames={strong_blue_frames}/'
                        f'{self.CONFESSION_STRONG_BLUE_CONFIRM_FRAMES} '
                        f'weak={weak_blue} ratio={blue_ratio:.3f} cols={active_cols} '
                        f'ring={ring_visible} armed={ring_armed} fall_recent={ring_fall_recent} '
                        f'transition_support={transition_support_frames}/'
                        f'{self.P2_CONFESSION_ENTRY_SUPPORT_FRAMES} '
                        f'fallback_joint={fallback_joint_frames}/'
                        f'{self.P2_CONFESSION_ENTRY_SUPPORT_FRAMES}'
                    )
                    last_log = now

                self.sleep(0.01)
        finally:
            self.task.send_key_up(key)
            state.pop(self.PHOEBE_PREHOLD_E_KEY, None)
            state.pop(self.PHOEBE_PREHOLD_SOURCE_KEY, None)

        self._clear_p2_confession_proof(state)
        self.logger.warning(
            f'ZFG V4.4 P2 confession STRICT timeout '
            f'segments={last["segments"]}/2 strong={last["strong"]} '
            f'weak={last["weak"]} ratio={last["ratio"]:.3f} '
            f'active_cols={last["active"]} ring={last["ring"]}'
        )
        return False

    def _confirm_p2_confession_current_before_r(self, state, tag):
        """P2第二道硬门：R真正输入前再次确认当前仍在告解。"""
        if not state.get('p2_confession_entry_verified'):
            self.logger.warning(
                f'ZFG V4.4 Phoebe {tag}: pre-R confession gate missing entry proof'
            )
            return False

        transition_verified = bool(state.get('p2_confession_entry_transition'))
        start = time.time()
        strict_frames = 0
        transition_backed_frames = 0
        last_log = -100.0

        while time.time() - start < self.P2_CONFESSION_PRE_R_TIMEOUT:
            self.task.next_frame()

            segments = self._read_confession_forte_segments()
            (
                strong_blue, weak_blue, blue_ratio, active_cols,
                weak_required, strong_required,
            ) = self._read_confession_blue_bar_evidence()
            ring_visible = self._read_confession_ring_visible()

            strict_frames = strict_frames + 1 if (segments >= 1 and strong_blue) else 0
            transition_backed_ok = (
                transition_verified
                and not ring_visible
                and (segments >= 1 or strong_blue)
            )
            transition_backed_frames = (
                transition_backed_frames + 1 if transition_backed_ok else 0
            )

            if strict_frames >= self.P2_CONFESSION_PRE_R_CONFIRM_FRAMES:
                self.logger.info(
                    f'ZFG V4.4 Phoebe {tag}: P2 PRE-R CONFESSION CONFIRMED '
                    f'via=SEGMENTS_AND_STRONG_BLUE frames={strict_frames} '
                    f'seg={segments}/2 ratio={blue_ratio:.3f} '
                    f'cols={active_cols} ring={ring_visible}'
                )
                return True

            if (
                transition_backed_frames
                >= self.P2_CONFESSION_PRE_R_TRANSITION_BACKED_FRAMES
            ):
                self.logger.info(
                    f'ZFG V4.4 Phoebe {tag}: P2 PRE-R CONFESSION CONFIRMED '
                    f'via=TRANSITION_BACKED_CURRENT_SUPPORT '
                    f'frames={transition_backed_frames} seg={segments}/2 '
                    f'strong={strong_blue} weak={weak_blue} '
                    f'ratio={blue_ratio:.3f} cols={active_cols} ring={ring_visible}'
                )
                return True

            now = time.time()
            if (segments >= 1 or strong_blue or weak_blue or ring_visible) and now - last_log >= 0.12:
                self.logger.info(
                    f'ZFG V4.4 Phoebe {tag}: P2 pre-R sample '
                    f'seg={segments}/2 strong={strong_blue} weak={weak_blue} '
                    f'ratio={blue_ratio:.3f} cols={active_cols} ring={ring_visible} '
                    f'transition_verified={transition_verified} '
                    f'strict={strict_frames}/{self.P2_CONFESSION_PRE_R_CONFIRM_FRAMES} '
                    f'transition_backed={transition_backed_frames}/'
                    f'{self.P2_CONFESSION_PRE_R_TRANSITION_BACKED_FRAMES}'
                )
                last_log = now

            self.sleep(0.02)

        self.logger.warning(
            f'ZFG V4.4 Phoebe {tag}: P2 PRE-R confession current-state '
            'NOT confirmed -> R BLOCKED'
        )
        return False


    def _reset_pre_r_prep_slice(self, state, source):
        """开启新一轮P1/P2 setup时清理上一轮赞妮PREP slice痕迹。"""
        for key in (
            self.ZANI_PRE_R_PREP_SLICE_DONE_KEY,
            self.ZANI_PRE_R_EFORTE_READY_KEY,
            self.ZANI_PRE_R_RETURN_STEP_KEY,
            self.ZANI_PRE_R_RETURN_PHASE_KEY,
            self.ZANI_PRE_R_PREP_SOURCE_KEY,
            self.ZANI_PRE_R_PRECAST_E_ATTEMPTED_KEY,
            self.ZANI_PRE_R_PRECAST_E_CONSUMED_KEY,
            self.ZANI_PRE_R_PRECAST_NORMAL_E_LAST_CAST_KEY,
            self.ZANI_PRE_R_PRECAST_NORMAL_E_CASTS_KEY,
            self.P2_FIRST_Z_INTRO_USED_KEY,
        ):
            state.pop(key, None)
        state[self.ZANI_PRE_R_PREP_SOURCE_KEY] = source

    def _start_zani_pre_r_prep_slice(
        self,
        state,
        zani_step,
        return_phase,
        tag,
        allow_natural_intro=False,
    ):
        """Starflash硬确认后切赞妮做PRECAST detour。

        P1维持原普通切保护；P2在Z1后按当前协奏状态一次锁定归属：普通或特殊，切人重试期间不再改判。
        P2这里仅进入短收益窗口推进普通E/A/特殊E；不要求Z1阶段必须把特殊E从零做完。
        Z已经确认消费后先锁phase，因此无论切人是否暂时失败，都绝不重放已消费的Z。
        """
        if state.get(self.ZANI_PRE_R_PREP_SLICE_DONE_KEY):
            state['phase'] = return_phase
            return False

        concerto_full = bool(self._concerto_effectively_full())
        if concerto_full and not allow_natural_intro:
            state[self.ZANI_PRE_R_PREP_SLICE_DONE_KEY] = True
            state[self.ZANI_PRE_R_EFORTE_READY_KEY] = False
            state['phase'] = return_phase
            self.logger.info(
                f'ZFG V4.4 Phoebe {tag}: skip PREP slice because concerto effectively full '
                'and this route forbids early special intro; later Zani EFORTE remains fallback'
            )
            return False

        return_step = state.get('step')
        state[self.ZANI_PRE_R_RETURN_STEP_KEY] = return_step
        state[self.ZANI_PRE_R_RETURN_PHASE_KEY] = return_phase
        state[self.ZANI_PRE_R_PREP_SOURCE_KEY] = tag

        if allow_natural_intro:
            # V4.3: lock ownership once, before any switch retry. False is a real locked value,
            # so key presence (not truthiness) distinguishes "not decided" from "locked ordinary".
            if self.P2_FIRST_Z_INTRO_USED_KEY not in state:
                state[self.P2_FIRST_Z_INTRO_USED_KEY] = bool(concerto_full)
                self.logger.info(
                    f'ZFG V4.4 Phoebe {tag}: P2 Z1 INTRO DECISION LOCKED = '
                    f'{"SPECIAL" if concerto_full else "ORDINARY"}'
                )
            intro_used = bool(state[self.P2_FIRST_Z_INTRO_USED_KEY])
            switch_mode = 'LOCKED-SPECIAL' if intro_used else 'LOCKED-ORDINARY'
            expect_intro = intro_used
        else:
            intro_used = False
            switch_mode = 'FORCED-NORMAL'
            expect_intro = False

        self.logger.info(
            f'ZFG V4.4 Phoebe {tag}: Starflash committed -> switch Zani PRECAST_SLICE '
            f'mode={switch_mode} concerto_full_now={concerto_full}; '
            f'will resume {return_step}/{return_phase}'
        )

        if not self._switch_to('Zani', expect_intro=expect_intro):
            self.logger.warning(
                f'ZFG V4.4 Phoebe {tag}: switch Zani PRECAST pending '
                f'mode={switch_mode}; locked ownership is preserved; NEVER replay consumed Starflash'
            )
            return False

        if allow_natural_intro:
            self.logger.info(
                f'ZFG V4.4 Phoebe {tag}: P2 Z1 INTRO LOCK COMMITTED = '
                f'{"SPECIAL" if intro_used else "ORDINARY"}; '
                f'P2 Z2 ROUTE LOCKED = {"ORDINARY" if intro_used else "SPECIAL"}'
            )

        self._advance_step(state, zani_step)
        return True

    def _try_p2_control_e1_once(self, state, tag):
        """V4.3 P2 E1 one-shot guarded by explicit E1/E2 recognition.

        E1 -> one input and lock this P2 cycle.
        E2 -> mark E1 already passed and never press E.
        UNKNOWN -> do nothing and allow a later safe re-probe while charging.
        """
        if state.get('step') != self.STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI:
            return False
        if state.get(self.P2_E1_ATTEMPTED_KEY):
            return False
        if state.get(self.PHOEBE_PREHOLD_E_KEY) or not self.is_current_char:
            return False

        self.task.next_frame()
        stage, scores = self._detect_phoebe_e_stage(log=False)
        if stage == 'E2':
            state[self.P2_E1_ATTEMPTED_KEY] = True
            state[self.P2_E1_CONFIRMED_KEY] = True
            state[self.P2_E1_PENDING_KEY] = False
            self.logger.info(
                f'ZFG V4.4 Phoebe {tag}: P2 E2 DETECTED -> E1 already passed; '
                'NO E INPUT / NO E2'
            )
            return False

        if stage != 'E1' or not self.resonance_available():
            return False

        try:
            if self.confession_ready():
                self.logger.debug(
                    f'ZFG V4.4 Phoebe {tag}: E1 detected but confession ring active -> skip'
                )
                return False
        except Exception as exc:
            self.logger.debug(
                f'ZFG V4.4 Phoebe {tag}: confession probe failed {exc} -> skip E1 safely'
            )
            return False

        state[self.P2_E1_ATTEMPTED_KEY] = True
        state[self.P2_E1_PENDING_KEY] = False
        state[self.P2_E1_CONFIRMED_KEY] = False
        state[self.P2_E1_INPUT_AT_KEY] = time.time()
        self.task.send_key(self.get_resonance_key())
        self.logger.info(
            f'ZFG V4.4 Phoebe {tag}: P2 E1 DETECTED -> INPUT_COMMITTED; '
            f'E1={scores["E1"]:.3f} E2={scores["E2"]:.3f}; one-shot / never E2'
        )
        return True

    def _p2_attack_until_con_with_e1(self, state, timeout):
        """P2纯补协奏：A为主动作；若本轮E1尚未尝试，只允许一次one-shot插入。"""
        start = time.time()
        attacks = 0
        while time.time() - start < timeout:
            self.task.next_frame()
            if self._raw_con_full():
                self.logger.info(
                    f'ZFG V4.4 Phoebe P2 fill concerto FULL attacks={attacks}'
                )
                return True

            self._try_p2_control_e1_once(state, 'P2 fill-con')
            self.task.click()
            attacks += 1
            self.sleep(0.08)

        ready = bool(self._raw_con_full())
        self.logger.info(
            f'ZFG V4.4 Phoebe P2 fill concerto slice end '
            f'ready={ready} attacks={attacks}'
        )
        return ready

    def _three_a(self, tag):
        """普通3A：只负责把A1/A2/A3完整打出，不主动把下一发重击消费掉。

        这个版本专门用于“3A后要存Z”的阶段。因为第二组3A的目的就是让
        Starflash进入可用状态并保留下来，所以这里绝不能偷偷长按A。
        """
        self.logger.info(f'ZFG V4.4 Phoebe {tag}: AAA start')
        for index in range(3):
            self.task.click()
            self.logger.debug(f'ZFG V4.4 Phoebe {tag}: A{index + 1} sent')
            self.sleep(self.THREE_A_GAP)
            self.task.next_frame()
        self.logger.info(f'ZFG V4.4 Phoebe {tag}: AAA end')


    def _cast_control_e_required(self, tag):
        start = time.time()

        while time.time() - start < self.REQUIRED_E_TIMEOUT:
            self.task.next_frame()

            if self.resonance_available():
                clicked, duration, animated = self.click_resonance(
                    send_click=False,
                    time_out=0.8,
                    click_f=False,
                )
                if clicked:
                    self.logger.info(
                        f'ZFG V4.4 Phoebe {tag}: control E confirmed '
                        f'duration={duration:.2f} animated={animated}'
                    )
                    return True

            self.sleep(self.POLL)

        self.logger.warning(
            f'ZFG V4.4 Phoebe {tag}: control E not confirmed'
        )
        return False

    def _cast_echo_required(self, tag):
        start = time.time()

        while time.time() - start < self.REQUIRED_Q_TIMEOUT:
            self.task.next_frame()

            if self.echo_available():
                base_result = self.click_echo(time_out=0.8)
                self.task.next_frame()
                consumed = not self.echo_available()

                if base_result or consumed:
                    self.logger.info(
                        f'ZFG V4.4 Phoebe {tag}: Q confirmed '
                        f'base_result={bool(base_result)} consumed={consumed}'
                    )
                    return True

            self.sleep(self.POLL)

        self.logger.warning(
            f'ZFG V4.4 Phoebe {tag}: Q not confirmed'
        )
        return False

    def _phoebe_e_template(self, stage):
        cache = getattr(self, '_zfg_e_stage_template_cache', None)
        if not isinstance(cache, dict):
            cache = {}
            self._zfg_e_stage_template_cache = cache
        if stage in cache:
            return cache[stage]

        encoded = (
            self.PHOEBE_E1_TEMPLATE_B64
            if stage == 'E1'
            else self.PHOEBE_E2_TEMPLATE_B64
        )
        raw = np.frombuffer(base64.b64decode(encoded), dtype=np.uint8)
        template = cv2.imdecode(raw, cv2.IMREAD_GRAYSCALE)
        if template is None or template.size == 0:
            return None
        template = cv2.equalizeHist(template)
        cache[stage] = template
        return template

    def _detect_phoebe_e_stage(self, log=False):
        """Return ('E1'|'E2'|'UNKNOWN', scores) from the current E icon.

        V4.3只在明确识别为E1时允许发送E；E2或UNKNOWN都不会触发E输入。
        这是防止“补E1”误按成E2的主安全门。
        """
        try:
            x1, y1, x2, y2 = self.PHOEBE_E_STAGE_ROI
            box = self.task.box_of_screen_scaled(
                1600, 900, x1, y1, x2, y2,
                name='phoebe_e_stage', hcenter=True,
            )
            cropped = box.crop_frame(self.task.frame)
            if cropped is None or getattr(cropped, 'size', 0) == 0:
                return 'UNKNOWN', {'E1': -1.0, 'E2': -1.0}

            gray = cv2.cvtColor(cropped, cv2.COLOR_BGR2GRAY)
            gray = cv2.resize(
                gray, self.PHOEBE_E_STAGE_BASE_SIZE,
                interpolation=cv2.INTER_AREA,
            )
            gray = cv2.equalizeHist(gray)

            scores = {}
            for stage in ('E1', 'E2'):
                template = self._phoebe_e_template(stage)
                if template is None or (
                    gray.shape[0] < template.shape[0]
                    or gray.shape[1] < template.shape[1]
                ):
                    scores[stage] = -1.0
                    continue
                result = cv2.matchTemplate(gray, template, cv2.TM_CCOEFF_NORMED)
                scores[stage] = float(cv2.minMaxLoc(result)[1])

            best = max(scores, key=scores.get)
            other = 'E2' if best == 'E1' else 'E1'
            margin = scores[best] - scores[other]
            stage = (
                best
                if scores[best] >= self.PHOEBE_E_STAGE_MIN_SCORE
                and margin >= self.PHOEBE_E_STAGE_MIN_MARGIN
                else 'UNKNOWN'
            )

            if log:
                self.logger.info(
                    f'ZFG V4.4 Phoebe E-STAGE detect={stage} '
                    f'E1={scores["E1"]:.3f} E2={scores["E2"]:.3f} margin={margin:.3f}'
                )
            return stage, scores
        except Exception as exc:
            self.logger.warning(
                f'ZFG V4.4 Phoebe E-STAGE detect failed {exc} -> UNKNOWN / no E input'
            )
            return 'UNKNOWN', {'E1': -1.0, 'E2': -1.0}

    def _try_e1_by_icon(self, tag, wait_window=0.18, confirm=False):
        """Safely cast E1 only when the E1 template is positively identified.

        E2 means E1 has already advanced and is a hard NO-PRESS. UNKNOWN is also
        a NO-PRESS; preserving the axis is preferable to accidentally firing E2.
        """
        start = time.time()
        while time.time() - start < max(0.02, wait_window):
            self.task.next_frame()
            stage, scores = self._detect_phoebe_e_stage(log=False)

            if stage == 'E2':
                self.logger.info(
                    f'ZFG V4.4 Phoebe {tag}: E2 DETECTED '
                    f'(E1={scores["E1"]:.3f} E2={scores["E2"]:.3f}) -> NEVER press E'
                )
                return 'E2'

            if stage == 'E1' and self.resonance_available():
                self.task.send_key(self.get_resonance_key())
                self.logger.info(
                    f'ZFG V4.4 Phoebe {tag}: E1 DETECTED -> INPUT_COMMITTED '
                    f'(E1={scores["E1"]:.3f} E2={scores["E2"]:.3f})'
                )
                if not confirm:
                    return 'CAST'

                confirm_start = time.time()
                while time.time() - confirm_start < self.PHOEBE_E1_CONFIRM_TIMEOUT:
                    self.sleep(self.PHOEBE_E_STAGE_POLL, check_combat=False)
                    self.task.next_frame()
                    after, after_scores = self._detect_phoebe_e_stage(log=False)
                    if after == 'E2' or not self.resonance_available():
                        self.logger.info(
                            f'ZFG V4.4 Phoebe {tag}: E1 RELEASE CONFIRMED via='
                            f'{"E1_TO_E2" if after == "E2" else "E_NOT_READY"} '
                            f'E1={after_scores["E1"]:.3f} E2={after_scores["E2"]:.3f}'
                        )
                        try:
                            self.record_resonance_use()
                        except Exception:
                            pass
                        return 'CAST_CONFIRMED'

                self.logger.warning(
                    f'ZFG V4.4 Phoebe {tag}: E1 input sent but transition unconfirmed; '
                    'DO NOT retry in this field window'
                )
                return 'CAST_UNCONFIRMED'

            self.sleep(self.PHOEBE_E_STAGE_POLL, check_combat=False)

        stage, scores = self._detect_phoebe_e_stage(log=True)
        self.logger.info(
            f'ZFG V4.4 Phoebe {tag}: no safe E1 window stage={stage} -> skip E; '
            'never guess E1 from generic resonance_available()'
        )
        return stage

    def _p1_soft_commit_echo(self, tag):
        """V4.3 P1 SOFT_COMMIT Q: current availability authorizes one input; result/consumption no longer blocks the axis."""
        start = time.time()
        while time.time() - start < self.P1_SOFT_COMMIT_READY_WINDOW:
            self.task.next_frame()
            if self.echo_available():
                api_result = self.click_echo(time_out=0)
                self.logger.info(
                    f'ZFG V4.4 Phoebe {tag}: SOFT_COMMIT Q INPUT_COMMITTED '
                    f'api_result={bool(api_result)}; skip consumption confirmation'
                )
                self.sleep(self.P1_SOFT_COMMIT_SETTLE, check_combat=False)
                return True
            self.sleep(self.P1_SOFT_COMMIT_POLL)
        self.logger.warning(
            f'ZFG V4.4 Phoebe {tag}: SOFT_COMMIT Q input window not ready -> keep phase'
        )
        return False

    def _wait_p1_confession_r_ready(self, tag):
        """等待P1告解后的菲比R真正READY。

        设计目的：
        - 旧版会在R图标尚未亮时直接调用可靠R输入，产生 no-effect + 长确认等待；
        - V4.3改为“READY是输入前置条件”，不再拿失败输入试CD；
        - 连续2帧READY才通过，过滤单帧UI抖动；
        - 一个slice没等到就返回False并保留r_cancel phase，下轮继续等，不推进STEP。
        """
        start = time.time()
        stable = 0
        first_log = True

        while time.time() - start < self.P1_CONFESSION_R_WAIT_SLICE:
            self.task.next_frame()
            ready = bool(self.liberation_available())

            if ready:
                stable += 1
                if stable >= self.P1_CONFESSION_R_READY_FRAMES:
                    self.logger.info(
                        f'ZFG V4.4 Phoebe {tag}: R READY stable '
                        f'{stable}/{self.P1_CONFESSION_R_READY_FRAMES} -> allow input'
                    )
                    return True
            else:
                stable = 0
                if first_log:
                    self.logger.info(
                        f'ZFG V4.4 Phoebe {tag}: R not ready -> WAIT, no blind input'
                    )
                    first_log = False

            self.sleep(self.POLL)

        self.logger.info(
            f'ZFG V4.4 Phoebe {tag}: R still cooling -> keep r_cancel phase'
        )
        return False

    def _record_phoebe_r_shared_time(self, input_time, tag):
        state = self._zfg_state()
        state[self.PHOEBE_LAST_R_CAST_TIME_KEY] = float(input_time)
        self.logger.info(
            f'ZFG V4.4 Phoebe {tag}: R cooldown timestamp armed at input'
        )

    def _cast_confession_r_required(self, tag):
        """通用可靠R：保留原版扩展确认；成功后记录共享R起始时刻供P2算25s CD。"""
        input_time = time.time()
        if not self._click_liberation_reliable(
            send_click=False,
            tag=f' {tag}',
        ):
            self.logger.warning(
                f'ZFG V4.4 Phoebe {tag}: R failed -> keep phase'
            )
            return False

        self._record_phoebe_r_shared_time(input_time, tag)
        self._record_liberation_cast()
        self.logger.info(
            f'ZFG V4.4 Phoebe {tag}: confession R confirmed (NO-A R input)'
        )
        return True

    def _cast_p1_confession_r_fast_required(self, tag):
        """P1四终夜专用：R第一次no-effect后不再固定等1s，图标重新READY就立刻retry。"""
        for attempt in (1, 2):
            if attempt > 1:
                start = time.time()
                stable = 0
                while time.time() - start < self.P1_CONFESSION_R_FAST_RETRY_WINDOW:
                    self.task.next_frame()
                    if self.liberation_available():
                        stable += 1
                        if stable >= 1:
                            self.logger.info(
                                f'ZFG V4.4 Phoebe {tag}: R re-READY -> FAST retry now'
                            )
                            break
                    else:
                        stable = 0
                    self.sleep(self.P1_CONFESSION_R_FAST_RETRY_POLL)
                else:
                    self.logger.warning(
                        f'ZFG V4.4 Phoebe {tag}: R fast-retry window expired -> keep phase'
                    )
                    return False

            if not self.liberation_available():
                self.logger.info(
                    f'ZFG V4.4 Phoebe {tag}: R not READY at attempt={attempt} -> keep phase'
                )
                return False

            input_time = time.time()
            self.logger.info(
                f'ZFG V4.4 Phoebe {tag}: R FAST input attempt={attempt}'
            )
            if self.click_liberation(
                send_click=False, wait_if_cd_ready=0, click_f=False
            ):
                self.state['liber_no_effect_at'] = 0
                self._record_phoebe_r_shared_time(input_time, tag)
                self._record_liberation_cast()
                self.logger.info(
                    f'ZFG V4.4 Phoebe {tag}: confession R FAST confirmed attempt={attempt}'
                )
                return True

            self.logger.warning(
                f'ZFG V4.4 Phoebe {tag}: R FAST no-effect attempt={attempt}; '
                'NO fixed 1.0s extended wait'
            )

        self._mark_liber_no_effect()
        return False

    def _cast_echo_soft(self, tag):
        """P1/P2脱手Q机会动作：SOFT_COMMIT，有就提交输入，没有直接通过。"""
        if not self.echo_available():
            self.logger.info(f'ZFG V4.4 Phoebe {tag}: SOFT_COMMIT Q skip cooldown')
            return False
        result = self.click_echo(time_out=0)
        self.logger.info(
            f'ZFG V4.4 Phoebe {tag}: SOFT_COMMIT Q INPUT_COMMITTED '
            f'api_result={bool(result)}; NON-BLOCKING'
        )
        return True

    def _charge_starflash_without_recover_e(self, timeout=5.0):
        """P2双Z保护：A充重击期间最多插入一次普通E(E1)，绝不重试到E2。"""
        state = self._zfg_state()
        start = time.time()
        attacks = 0
        while not self.is_forte_full() and time.time() - start < timeout:
            self._try_p2_control_e1_once(state, 'P2 star-charge')
            self.task.click()
            attacks += 1
            self.sleep(0.05)
            self.task.next_frame()
        self.logger.info(
            f'ZFG V4.4 Phoebe no-recover star charge end '
            f'ready={bool(self.is_forte_full())} attacks={attacks}'
        )
        return bool(self.is_forte_full())

    def _cast_star_required(self, tag, allow_recover_e=True):
        if not self.is_forte_full():
            if allow_recover_e:
                self._charge_starflash_until_full(
                    finish_with_right_click=False,
                )
            else:
                self._charge_starflash_without_recover_e()

        if not self.is_forte_full():
            self.logger.warning(
                f'ZFG V4.4 Phoebe {tag}: Starflash not ready'
            )
            return False

        self.starflash_combo()
        self.task.next_frame()

        if self.is_forte_full():
            self.logger.warning(
                f'ZFG V4.4 Phoebe {tag}: Starflash not consumed'
            )
            return False

        self.logger.info(
            f'ZFG V4.4 Phoebe {tag}: Starflash consumed'
        )
        return True

    def heavy_attack_ready(self):
        """兼容不同OK-WW版本：菲比特殊Z可用性统一映射到forte满判定。"""
        try:
            return bool(self.is_forte_full())
        except Exception:
            return False

    def _phoebe_star_ready(self):
        return self.heavy_attack_ready()

    def _read_p2_blue_forte_cells(self):
        """读取P2双Z阶段的两格蓝色特殊能量，识别异常时保守按2格处理。"""
        if self.attribute != 2:
            self.attribute = 2
        try:
            return max(0, min(2, int(self.judge_forte())))
        except Exception as exc:
            self.logger.warning(
                f'ZFG V4.4 Phoebe P2 blue-forte read failed: {exc}'
            )
            return 2

    def _confirm_p2_star_not_ready(self, before_count, tag):
        start = time.time()
        stable_not_ready = 0
        while time.time() - start < self.P2_STAR_CONFIRM_TIMEOUT:
            self.task.next_frame()
            ready = bool(self._phoebe_star_ready())
            try:
                after_count = int(self.state.get('starflash_combo', 0))
            except Exception:
                after_count = before_count
            count_advanced = after_count > before_count
            stable_not_ready = 0 if ready else stable_not_ready + 1
            if count_advanced and stable_not_ready >= 2:
                self.logger.info(
                    f'ZFG V4.4 Phoebe {tag}: Z VERIFIED counter={before_count}->{after_count} '
                    f'not-ready={stable_not_ready}'
                )
                return True
            if stable_not_ready >= self.P2_STAR_NOT_READY_CONFIRM_FRAMES:
                self.logger.info(
                    f'ZFG V4.4 Phoebe {tag}: Z VERIFIED by READY->stable NOT READY '
                    f'counter={before_count}->{after_count}'
                )
                return True
            self.sleep(0.04)
        self.logger.warning(f'ZFG V4.4 Phoebe {tag}: special Z still/again ready -> retry same phase')
        return False

    def _cast_p2_star_with_energy_guard(self, tag, target_max=None):
        """P2单发Z：READY->稳定NOT READY为主证据，原版计数为辅助。"""
        if not self._phoebe_star_ready():
            self._charge_starflash_without_recover_e()
        if not self._phoebe_star_ready():
            self.logger.warning(f'ZFG V4.4 Phoebe {tag}: Starflash not ready -> keep same phase')
            return False
        try:
            before_count = int(self.state.get('starflash_combo', 0))
        except Exception:
            before_count = 0
        self.logger.info(f'ZFG V4.4 Phoebe {tag}: special Z READY counter={before_count}')
        self.starflash_combo()
        return self._confirm_p2_star_not_ready(before_count, tag)


    def _confirm_p2_blue_forte_empty(self, tag='P2 double-star final'):
        start = time.time()
        stable = 0
        last = None
        while time.time() - start < self.P2_FINAL_EMPTY_TIMEOUT:
            self.task.next_frame()
            last = self._read_p2_blue_forte_cells()
            if last == 0:
                stable += 1
                if stable >= self.P2_FINAL_EMPTY_CONFIRM_FRAMES:
                    self.logger.info(
                        f'ZFG V4.4 Phoebe {tag}: FINAL BLUE-FORTE EMPTY stable={stable}'
                    )
                    return True
            else:
                stable = 0
            self.sleep(0.04)
        self.logger.warning(
            f'ZFG V4.4 Phoebe {tag}: blue forte not empty last={last}/2 -> need another Z'
        )
        return False

    def _fill_concerto_and_intro_zani(
        self,
        state,
        next_step,
        require_saved_star,
        tag,
    ):
        phase = state.get('phase')

        if phase == 'fill_con':
            if state.get('step') == self.STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI:
                ready = self._p2_attack_until_con_with_e1(
                    state,
                    self.CONCERTO_FILL_TIMEOUT,
                )
            else:
                ready = self._attack_until_con(
                    self.CONCERTO_FILL_TIMEOUT,
                    check_liber=False,
                    require_forte=require_saved_star,
                )

            if ready is None:
                return False

            if not ready:
                self.logger.warning(
                    f'ZFG V4.4 Phoebe {tag}: concerto fill timeout'
                )
                return False

            if require_saved_star and not self.is_forte_full():
                self.logger.warning(
                    f'ZFG V4.4 Phoebe {tag}: saved Starflash lost'
                )
                state['phase'] = 'save_star'
                return False

            if not self._raw_con_full():
                return False

            state['phase'] = 'full_tail'
            phase = 'full_tail'

        if phase == 'full_tail':
            self.continues_normal_attack(self.FULL_CON_TAIL)
            self.task.next_frame()

            if not self._raw_con_full():
                state['phase'] = 'fill_con'
                return False

            self.logger.info(
                f'ZFG V4.4 Phoebe {tag}: '
                'FULL concerto + 0.20s tail confirmed'
            )
            state['phase'] = 'switch_zani'
            phase = 'switch_zani'

        if phase == 'switch_zani':
            if not self._raw_con_full():
                state['phase'] = 'fill_con'
                return False

            switched = self._switch_route(
                state,
                'Zani',
                next_step,
                force_intro=True,
            )
            if switched:
                self.first_rotation_done = True
            return switched

        return False


    def _p1_confession_r_eq_to_rover(self, state):
        """V4.3 opening: Phoebe confession/R -> safe E1 -> Q -> Rover.

        Confession/R remain HARD_GATE. E1 is only pressed when the explicit E1 icon
        is recognized; E2/UNKNOWN never receive an E input.
        """
        phase = state.get('phase', 'entry')
        tag = 'P1 confession-cancel'

        if phase == 'entry':
            self._clear_p1_confession_proof(state)
            for key in (
                self.P1_PHOEBE_E1_PENDING_KEY,
                self.P1_PHOEBE_E1_CONFIRMED_KEY,
                self.P1_PHOEBE_E1_INPUT_AT_KEY,
                self.P1_PHOEBE_E1_RECOVERY_ATTEMPTED_KEY,
            ):
                state.pop(key, None)
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._ensure_grounded('P1 confession entry')
            state['phase'] = 'confession'
            phase = 'confession'

        if phase == 'confession':
            if (
                not state.get(self.PHOEBE_PREHOLD_E_KEY)
                and not self.resonance_available()
            ):
                self.sleep(self.POLL)
                self.task.next_frame()
                return

            if not self._hold_e_until_p1_confession_guarded(tag):
                return

            self.logger.info(
                f'ZFG V4.4 Phoebe {tag}: HARD_GATE confession PASSED; '
                'fresh proof may authorize R without duplicate pre-R scan'
            )
            state['phase'] = 'r_cancel'
            phase = 'r_cancel'

        if phase == 'r_cancel':
            self.task.next_frame()
            if not self.liberation_available():
                self.sleep(self.P1_SOFT_COMMIT_POLL)
                return

            proof_at = state.get(self.PHOEBE_LAST_CONFESSION_TIME_KEY)
            proof_age = (time.time() - proof_at) if isinstance(proof_at, (int, float)) else 999.0
            if proof_age <= self.P1_OPEN_CONFESSION_PROOF_FRESH:
                self.logger.info(
                    f'ZFG V4.4 Phoebe {tag}: HARD_GATE R authorized by fresh confession proof '
                    f'age={proof_age:.3f}s; skip duplicate current-state scan'
                )
            else:
                self.logger.info(
                    f'ZFG V4.4 Phoebe {tag}: HARD_GATE confession proof stale '
                    f'age={proof_age:.3f}s -> revalidate before R'
                )
                if not self._confirm_p1_confession_current_before_r(state, tag):
                    self._handle_p1_confession_pre_r_failure(state, tag)
                    return

            if not self._cast_p1_confession_r_fast_required(tag):
                return

            self.logger.info(f'ZFG V4.4 Phoebe {tag}: HARD_GATE R PASSED')
            self._clear_p1_confession_proof(state)
            state['phase'] = 'control_e'
            phase = 'control_e'

        if phase == 'control_e':
            self._try_e1_by_icon('P1 after-R', wait_window=0.22, confirm=False)
            state['phase'] = 'q'
            phase = 'q'

        if phase == 'q':
            if not self._p1_soft_commit_echo('P1 after-R'):
                return
            state['phase'] = 'switch_rover'
            phase = 'switch_rover'

        if phase == 'switch_rover':
            self._switch_route(
                state,
                'Rover',
                self.STEP_P1_ROVER_EQR_TO_ZANI,
            )


    def _p1_3a_star_save_fill_to_zani(self, state):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            self._reset_pre_r_prep_slice(state, source='P1-Z1')
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._ensure_grounded('P1 3A entry')
            self._try_e1_by_icon('P1 first-return', wait_window=0.10, confirm=False)
            state['phase'] = 'aaa_star'
            phase = 'aaa_star'

        if phase == 'aaa_star':
            self._three_a('P1 first')
            state['phase'] = 'star1'
            phase = 'star1'

        if phase == 'star1':
            if not self._cast_star_required('P1 first'):
                return
            # Z1已经确认消费：先锁phase，再切赞妮；切人失败也绝不重放Z1。
            state['phase'] = 'prep_after_star1'
            phase = 'prep_after_star1'

        if phase == 'prep_after_star1':
            if self._start_zani_pre_r_prep_slice(
                state,
                self.STEP_P1_ZANI_PRE_R_PREP_SLICE,
                return_phase='aaa_save',
                tag='P1-first-Z',
            ):
                return
            phase = state.get('phase', phase)
            if phase == 'prep_after_star1':
                return

        if phase == 'aaa_save':
            self._three_a('P1 save')
            state['phase'] = 'save_star'
            phase = 'save_star'

        if phase == 'save_star':
            if not self.is_forte_full():
                self._charge_starflash_until_full(
                    finish_with_right_click=False,
                )

            if not self.is_forte_full():
                return

            self.logger.info(
                'ZFG V4.4 Phoebe P1 saved Starflash READY; DO NOT CAST'
            )
            state['phase'] = 'fill_con'
            phase = 'fill_con'

        if phase in ('fill_con', 'full_tail', 'switch_zani'):
            self._fill_concerto_and_intro_zani(
                state,
                self.STEP_P1_ZANI_EFORTE_PREP,
                require_saved_star=True,
                tag='P1 setup',
            )


    def _p1_star_e1_to_zani(self, state):
        """V4.3 P1 N1: consume saved Star -> safe E1 -> Zani. No extra 3A.

        E1 provides the control/immobilize utility the user wants while avoiding the
        old 3A time cost that could squeeze N4 before R2.
        """
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._ensure_grounded('P1-N1 Star+E1')
            state['phase'] = 'star'
            phase = 'star'

        if phase == 'star':
            if not self._cast_star_required('P1-N1 Star+E1'):
                return
            state[self.P1_PHOEBE_FORTE_EXPECTED_EMPTY_KEY] = True
            self.logger.info(
                'ZFG V4.4 Phoebe P1-N1 Star+E1: HARD_GATE Star consumed -> probe explicit E1 icon'
            )
            state['phase'] = 'e1'
            phase = 'e1'

        if phase == 'e1':
            result = self._try_e1_by_icon(
                'P1-N1 Star+E1', wait_window=0.22, confirm=True,
            )
            self.logger.info(
                f'ZFG V4.4 Phoebe P1-N1 Star+E1 result={result} -> switch Zani; NO 3A'
            )
            state['phase'] = 'switch'
            phase = 'switch'

        if phase == 'switch':
            self._switch_route(
                state,
                'Zani',
                self.STEP_P1_ZANI_N2_TO_ROVER_R,
            )


    def _single_star_to_target(
        self,
        state,
        target,
        next_step,
        tag,
    ):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._ensure_grounded(tag)
            state['phase'] = 'star'
            phase = 'star'

        if phase == 'star':
            if not self._cast_star_required(tag):
                return

            if tag == 'P1-N1-insert':
                state[self.P1_PHOEBE_FORTE_EXPECTED_EMPTY_KEY] = True
                self.logger.info(
                    'ZFG V4.4 Phoebe P1-N1-insert: forte expected EMPTY armed '
                    'for legacy compatibility; V4.3 current-state confession check no longer needs transition history'
                )

            state['phase'] = 'switch'
            phase = 'switch'

        if phase == 'switch':
            self._switch_route(
                state,
                target,
                next_step,
            )


    def _p2_confession_remaining(self, state):
        """Prayer理论24s剩余；只用于调度，不直接宣告告解成功。"""
        last = state.get(self.PHOEBE_LAST_CONFESSION_TIME_KEY)
        if not isinstance(last, (int, float)) or last <= 0:
            return None, None
        elapsed = max(0.0, time.time() - last)
        remaining = max(0.0, self.P2_CONFESSION_PRAYER_REFILL - elapsed)
        return elapsed, remaining

    def _p2_phoebe_r_remaining(self, state):
        """按上一次真实R输入时刻，以freeze-aware计时估算25s RCD。"""
        last = state.get(self.PHOEBE_LAST_R_CAST_TIME_KEY)
        if not isinstance(last, (int, float)) or last <= 0:
            return 0.0 if self.liberation_available() else None
        elapsed = max(0.0, float(self.time_elapsed_accounting_for_freeze(last)))
        return max(0.0, self.PHOEBE_R_COOLDOWN - elapsed)

    def _p2_r2_fill_room(self, state):
        """还能拿多少秒去光主填轴，同时保证赞妮R2尾端留6s保护。"""
        start = float(state.get('zani_r1_timer_start', 0) or 0)
        if start <= 0:
            return None, None
        elapsed = max(0.0, float(self.time_elapsed_accounting_for_freeze(start)))
        r2_left = max(0.0, self.ZANI_R2_HARD_DEADLINE_SHARED - elapsed)
        fill_room = max(0.0, r2_left - self.P2_CONFESSION_R2_RESERVE)
        return r2_left, fill_room

    def _p2_confession_e_stably_available(self):
        ready_frames = 0
        for _ in range(3):
            self.task.next_frame()
            if self.resonance_available():
                ready_frames += 1
            else:
                ready_frames = 0
            if ready_frames >= self.P2_CONFESSION_E_READY_FRAMES:
                return True
            self.sleep(0.03)
        return False

    def _p2_wait_budget(self, state):
        elapsed, prayer = self._p2_confession_remaining(state)
        r_rem = self._p2_phoebe_r_remaining(state)
        retry_after = float(state.get(self.P2_CONFESSION_RETRY_AFTER_KEY, 0.0) or 0.0)
        retry_wait = max(0.0, retry_after - time.time())
        known = [x for x in (prayer, r_rem) if isinstance(x, (int, float))]
        if retry_wait > 0:
            known.append(retry_wait)
        need = max(known) if known else None
        r2_left, fill_room = self._p2_r2_fill_room(state)
        return elapsed, prayer, r_rem, retry_wait, need, r2_left, fill_room

    def _p2_plan_rover_az(self, state, reason, force_one=False):
        """按剩余等待与R2截止计算本次光主最多AZ数量；Rover每发后还会再次重算。"""
        _, prayer, r_rem, retry_wait, need, r2_left, fill_room = self._p2_wait_budget(state)
        total_done = int(state.get(self.P2_CONFESSION_AZ_COUNT_KEY, 0) or 0)
        remaining_total = max(0, self.P2_CONFESSION_MAX_AZ - total_done)
        if remaining_total <= 0:
            return False

        if need is None:
            n = 1 if force_one else 0
        else:
            effective = need
            if fill_room is not None:
                effective = min(effective, fill_room)
            usable = effective - self.P2_CONFESSION_SWITCH_TOTAL - self.P2_CONFESSION_PLAN_SAFETY
            n = int(max(0.0, usable) // self.P2_CONFESSION_AZ_COST)
            if force_one and n <= 0 and (fill_room is None or fill_room >= self.P2_CONFESSION_AZ_COST):
                n = 1
        n = max(0, min(n, remaining_total))
        if n <= 0:
            return False

        state[self.P2_CONFESSION_AZ_USED_KEY] = True
        state[self.P2_CONFESSION_AZ_TARGET_KEY] = total_done + n
        self._release_phoebe_prehold(state, reason='p2-confession-dynamic-rover')
        self.logger.info(
            f'ZFG V4.4 P2 confession -> Rover dynamic fill reason={reason} '
            f'Prayer={prayer} Rrem={r_rem} retry={retry_wait:.2f}s '
            f'R2left={r2_left} fill_room={fill_room} AZ_plan={n} '
            f'total_target={total_done + n}'
        )
        self._switch_route(state, 'Rover', self.STEP_P2_ROVER_AZ_WAIT_CONFESSION)
        return True

    def _p2_confession_check(self, state):
        """P2三终夜：Prayer/RCD长就光主动态AZ填轴，短就菲比A；E/R真正就绪后再告解/R。"""
        phase = state.get('phase', 'entry')
        if phase == 'entry':
            self._release_phoebe_prehold(state, reason='p2-confession-check-entry')
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._ensure_grounded('P2 confession check')
            state['phase'] = 'decide'
            phase = 'decide'

        if phase == 'decide':
            elapsed, prayer, r_rem, retry_wait, need, r2_left, fill_room = self._p2_wait_budget(state)
            e_ready = self._p2_confession_e_stably_available()
            az_done = int(state.get(self.P2_CONFESSION_AZ_COUNT_KEY, 0) or 0)
            self.logger.info(
                f'ZFG V4.4 P2 confession CHECK Prayer_elapsed={elapsed} '
                f'Prayer_rem={prayer} R_rem={r_rem} E={e_ready} '
                f'retry={retry_wait:.2f}s R2_left={r2_left} fill_room={fill_room} AZ_done={az_done}'
            )

            if need is None:
                if not e_ready and self._p2_plan_rover_az(state, 'timer-unknown-E-cooldown', force_one=True):
                    return
            elif need > self.P2_CONFESSION_AZ_THRESHOLD:
                if self._p2_plan_rover_az(state, f'wait-budget-{need:.2f}s'):
                    return

            if (need is not None and need > 0) or retry_wait > 0:
                self.logger.info(
                    f'ZFG V4.4 P2 confession A-WAIT need≈{0.0 if need is None else need:.2f}s'
                )
                self.task.click()
                self.sleep(self.P2_CONFESSION_A_WAIT_GAP)
                self.task.next_frame()
                return

            if not e_ready:
                if self._p2_plan_rover_az(state, 'Prayer/R-ready-but-E-cooldown', force_one=True):
                    return
                self.task.click()
                self.sleep(self.P2_CONFESSION_A_WAIT_GAP)
                self.task.next_frame()
                return

            self.logger.info(
                'ZFG V4.4 P2 confession CHECK -> hold E and confirm CURRENT confession state'
            )
            self._advance_step(state, self.STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI)
            return

    def _p2_confession_r_to_zani(self, state):
        """P2双硬门：先确认真正进入告解，R输入前再确认当前仍处于告解。"""
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            self._release_phoebe_prehold(state, reason='p2-confession-attempt-entry')
            self._clear_p2_confession_proof(state)
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._ensure_grounded('P2-before-N3')
            state['phase'] = 'confession'
            phase = 'confession'

        if phase == 'confession':
            if not self._p2_confession_e_stably_available():
                self._clear_p2_confession_proof(state)
                self.logger.info(
                    'ZFG V4.4 P2 confession attempt blocked: E unavailable -> CHECK'
                )
                self._advance_step(state, self.STEP_P2_PHOEBE_CONFESSION_CHECK)
                return

            if not self._hold_e_until_p2_confession_strict():
                state[self.P2_CONFESSION_RETRY_AFTER_KEY] = (
                    time.time() + self.P2_CONFESSION_FAILED_PROBE_BACKOFF
                )
                self.logger.warning(
                    'ZFG V4.4 P2 confession STRICT entry proof missing '
                    '-> recalc dynamic Rover/A wait'
                )
                if self._p2_plan_rover_az(
                    state, reason='confession-probe-failed', force_one=True
                ):
                    return
                self._advance_step(state, self.STEP_P2_PHOEBE_CONFESSION_CHECK)
                return

            state.pop(self.P2_CONFESSION_RETRY_AFTER_KEY, None)
            state['phase'] = 'r_cancel'
            phase = 'r_cancel'

        if phase == 'r_cancel':
            if not self._wait_p1_confession_r_ready('P2-before-N3'):
                return

            # R READY只是按键前置条件，绝不能作为告解证据。
            if not self._confirm_p2_confession_current_before_r(
                state, 'P2-before-N3'
            ):
                failed = int(
                    state.get('p2_confession_pre_r_failed_slices', 0) or 0
                ) + 1
                state['p2_confession_pre_r_failed_slices'] = failed

                if failed >= self.P2_CONFESSION_PRE_R_MAX_FAILED_SLICES:
                    self.logger.warning(
                        f'ZFG V4.4 P2 confession pre-R gate failed {failed} slices '
                        '-> restart confession proof'
                    )
                    self._clear_p2_confession_proof(state)
                    state['phase'] = 'confession'
                else:
                    self.logger.info(
                        f'ZFG V4.4 P2 confession pre-R gate failed '
                        f'{failed}/{self.P2_CONFESSION_PRE_R_MAX_FAILED_SLICES} '
                        '-> keep r_cancel and recheck; R remains blocked'
                    )
                return

            state['p2_confession_pre_r_failed_slices'] = 0
            if not self._cast_confession_r_required('P2-before-N3'):
                return

            self._cast_echo_soft('P2-before-N3-after-R')
            self._clear_p2_confession_proof(state)
            state.pop(self.P2_CONFESSION_AZ_USED_KEY, None)
            state.pop(self.P2_CONFESSION_AZ_COUNT_KEY, None)
            state.pop(self.P2_CONFESSION_AZ_TARGET_KEY, None)
            state.pop(self.P2_CONFESSION_RETRY_AFTER_KEY, None)
            state['phase'] = 'switch'
            phase = 'switch'

        if phase == 'switch':
            self._switch_route(
                state,
                'Zani',
                self.STEP_P2_ZANI_N3_R2_EA_TO_PHOEBE,
            )


    def _confession_r_to_target(
        self,
        state,
        target,
        next_step,
        tag,
    ):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            self._clear_p1_confession_proof(state)
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._ensure_grounded(tag)
            state['phase'] = 'confession'
            phase = 'confession'

        if phase == 'confession':
            if not state.get(self.PHOEBE_PREHOLD_E_KEY):
                ready_frames = 0
                for _ in range(3):
                    self.task.next_frame()
                    if self.resonance_available():
                        ready_frames += 1
                    else:
                        ready_frames = 0
                    self.sleep(0.03)

                if ready_frames < 2:
                    self.sleep(self.POLL)
                    return

            if not self._hold_e_until_p1_confession_guarded(tag):
                self.sleep(0.20)
                return

            state['phase'] = 'r_cancel'
            phase = 'r_cancel'

        if phase == 'r_cancel':
            if not self._wait_p1_confession_r_ready(tag):
                return

            if not self._confirm_p1_confession_current_before_r(state, tag):
                self._handle_p1_confession_pre_r_failure(state, tag)
                return

            if not self._cast_p1_confession_r_fast_required(tag):
                return

            self._clear_p1_confession_proof(state)
            self._cast_echo_soft(f'{tag}-after-R')
            state['phase'] = 'switch'
            phase = 'switch'

        if phase == 'switch':
            self._switch_route(
                state,
                target,
                next_step,
            )


    def _p2_double_star_fill_to_zani(self, state):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            precharge_seeded = bool(state.pop(self.P2_ZANI_PRECHARGE_SEEDED_KEY, False))
            self._reset_pre_r_prep_slice(state, source='P2-Z1')
            self.logger.info(
                f'ZFG V4.4 Phoebe P2 entry: Zani precharge_from_previous_R2_tail={precharge_seeded}; '
                'Z1 PRECAST is stage-2 progress, Z2-final EFORTE is fallback only'
            )
            for key in (
                self.P2_E1_ATTEMPTED_KEY,
                self.P2_E1_PENDING_KEY,
                self.P2_E1_CONFIRMED_KEY,
                self.P2_E1_INPUT_AT_KEY,
            ):
                state.pop(key, None)
            state.pop('p2_phoebe_e1_last_attempt', None)  # 清理旧版热重载遗留键
            state['p2_double_star_done'] = False
            if state.pop('new_cycle_pending', False):
                state['cycle'] = int(state.get('cycle', 1)) + 1
                self.logger.info(f'ZFG V4.4 enter P2 cycle {state["cycle"]}')
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._ensure_grounded('P2 double-star entry')
            state['phase'] = 'star1'
            phase = 'star1'

        if phase == 'star1':
            if not self._cast_p2_star_with_energy_guard('P2 star1'):
                return
            # Z1 READY->NOT READY已经硬确认；合轴失败也不允许重放这发Z。
            state['phase'] = 'prep_after_star1'
            phase = 'prep_after_star1'

        if phase == 'prep_after_star1':
            if self._start_zani_pre_r_prep_slice(
                state,
                self.STEP_P2_ZANI_PRE_R_PREP_SLICE,
                return_phase='star2',
                tag='P2-first-Z',
                allow_natural_intro=True,
            ):
                return
            phase = state.get('phase', phase)
            if phase == 'prep_after_star1':
                return

        if phase == 'star2':
            if not self._cast_p2_star_with_energy_guard('P2 star2'):
                return
            state['phase'] = 'verify_empty'
            phase = 'verify_empty'

        if phase == 'verify_empty':
            if not self._confirm_p2_blue_forte_empty():
                state['phase'] = 'star2'
                return
            state['p2_double_star_done'] = True
            first_z_intro_used = bool(state.get(self.P2_FIRST_Z_INTRO_USED_KEY, False))
            self.logger.info(
                'ZFG V4.4 Phoebe P2 DOUBLE-STAR HARD GUARD satisfied: '
                'two Z ready-transitions + final blue forte 0/2; '
                f'first-Z intro used={first_z_intro_used}'
            )
            if first_z_intro_used:
                state['phase'] = 'switch_zani_natural'
                phase = 'switch_zani_natural'
                self.logger.info(
                    'ZFG V4.4 Phoebe P2 Z2 ROUTE LOCKED = ORDINARY because Z1 consumed special intro; '
                    'NO concerto refill requirement'
                )
            else:
                state['phase'] = 'fill_con'
                phase = 'fill_con'
                self.logger.info(
                    'ZFG V4.4 Phoebe P2 Z2 ROUTE LOCKED = SPECIAL because Z1 was ordinary; '
                    'fill concerto to FULL before Zani'
                )

        if phase == 'switch_zani_natural':
            if not state.get('p2_double_star_done'):
                state['phase'] = 'star2'
                return
            # Z1已经消费特殊变奏时，Z2必须锁死为普通切。
            # 不能再走通用_switch_route(expect_intro=None)，否则协奏意外满时会再次升级成特殊变奏。
            if self._switch_to('Zani', expect_intro=False):
                self.logger.info(
                    'ZFG V4.4 Phoebe P2 Z2 LOCKED-ORDINARY switch committed -> Zani'
                )
                self._advance_step(state, self.STEP_P2_ZANI_EFORTE_PREP)
                self.first_rotation_done = True
            return

        if phase in ('fill_con', 'full_tail', 'switch_zani'):
            if not state.get('p2_double_star_done'):
                state['phase'] = 'star2'
                return
            self._fill_concerto_and_intro_zani(
                state,
                self.STEP_P2_ZANI_EFORTE_PREP,
                require_saved_star=False,
                tag='P2 double-star',
            )
