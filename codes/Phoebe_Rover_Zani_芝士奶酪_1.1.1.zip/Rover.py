"""
赞菲光固定轴 V4.6 - Spectro Rover（衍射漂泊者 / 光主）

定位：
- V4.6 Frozen Runtime：高频BaseChar/角色私有helper冻结到赞菲光自身，FSM直接接task/frame/input底层；上游中层helper改名/签名变化不再直接影响固定轴。
- V4.4与V4.3_rev1在本角色上的执行逻辑一致；仅同步版本标识与共享PRECAST状态注释。
- 兼容新版ok-ww：固定轴落地等待统一走_zfg_ensure_grounded()，以后上游落地接口变化只维护兼容层。
- V4.3把SOFT_COMMIT从P1 E/Q下放到P2机会槽：Q、强化E、普通E输入提交即记本槽已用；R继续HARD_GATE。
- P2优先级仍为F>R>Q>强化E>普通E>AZ；F成功后不再额外wait_intro/wait_down罚站，直接进入REQ队列。
- P1开场改为菲比 -> 光主EQR -> 赞妮EA -> 菲比；N2后的第二发R使用最多1.0s硬优先窗口，一次失败不再直接放弃。
- P2特殊变奏归属锁定、满协奏安全detour与R2尾巴预充等既有结构保持。
"""


import time
import math

import cv2
import numpy as np

from src import text_white_color
from src.char.BaseChar import SwitchPriority, Elements
from src.char.Rover import Rover as BuiltinRover


class _ZFGFSM:
    ACTOR = None

    # =========================================================
    # ZFG Frozen Runtime V1
    # 目标：FSM只依赖本层；本层再直接接ok-ww task/frame/input底层。
    # 上游角色/BaseChar helper改名或改签名时，不再直接影响固定轴。
    # =========================================================
    ZFG_RUNTIME_REV = 1
    ZFG_SKILL_TIME_OUT = 15.0
    ZFG_FORTE_WHITE_COLOR = {
        'r': (244, 255), 'g': (246, 255), 'b': (250, 255),
    }

    def sleep(self, sec, check_combat=True):
        sec = max(0.0, float(sec))
        if not check_combat:
            self.task.skip_combat_check = True
        try:
            self.task.sleep(sec)
        finally:
            if not check_combat:
                self.task.skip_combat_check = False

    def check_combat(self):
        return self.task.check_combat()

    def _zfg_f_break_raw(self, check_f_on_switch=False, force=False):
        """直接接task.f_break，不再经过BaseChar/角色helper。"""
        if force:
            self.task.send_key('f', after_sleep=0.05)
        if check_f_on_switch and not bool(getattr(self, 'check_f_on_switch', False)):
            return False
        return bool(self.task.f_break())

    def add_freeze_duration(self, start, duration=-1.0, freeze_time=0.1):
        return self.task.add_freeze_duration(start, duration, freeze_time)

    def time_elapsed_accounting_for_freeze(self, start, intro_motion_freeze=False):
        return self.task.time_elapsed_accounting_for_freeze(start, intro_motion_freeze)

    def get_resonance_key(self):
        return self.task.get_resonance_key()

    def get_liberation_key(self):
        return self.task.get_liberation_key()

    def get_echo_key(self):
        return self.task.get_echo_key()

    def click(self, *args, **kwargs):
        kwargs['down_time'] = 0.01
        return self.task.click(*args, **kwargs)

    def click_with_interval(self, interval=0.1):
        return self.click(interval=interval)

    def has_cd(self, box_name):
        return self.task.has_cd(box_name)

    def available(self, box, check_color=True, check_cd=True):
        if self.is_current_char:
            return self.task.available(box, check_color=check_color, check_cd=check_cd)
        return not self.task.has_cd(box, self.index)

    def resonance_available(self):
        return self.available('resonance', check_color=False)

    def echo_available(self):
        return self.available('echo', check_color=False)

    def liberation_available(self, check_color=True):
        return self.available('liberation', check_color=check_color)

    def get_current_con(self):
        if getattr(self, 'current_con', 0) == 1:
            return 1
        self.current_con = self.task.get_current_con()
        return self.current_con

    def is_con_full(self):
        if getattr(self, 'current_con', 0) == 1:
            return True
        return bool(self.task.is_con_full())

    def is_mouse_forte_full(self):
        return bool(self.task.find_mouse_forte())

    def is_e_forte_full(self):
        return bool(self.task.find_e_forte())

    def is_forte_full(self):
        # 菲比告解形态的特殊Z使用鼠标forte图标；其余角色使用通用白色forte条。
        if self.ACTOR == 'Phoebe' and bool(getattr(self, 'star_available', False)):
            return self.is_mouse_forte_full()
        box = self.task.box_of_screen_scaled(
            3840, 2160, 2251, 1993, 2311, 2016,
            name='zfg_forte_full', hcenter=True,
        )
        white_percent = self.task.calculate_color_percentage(self.ZFG_FORTE_WHITE_COLOR, box)
        box.confidence = white_percent
        try:
            self.task.draw_boxes('zfg_forte_full', box)
        except Exception:
            pass
        return white_percent > 0.08

    def current_resonance(self):
        return self.task.calculate_color_percentage(
            text_white_color, self.task.get_box_by_name('box_resonance')
        )

    def current_liberation(self):
        return self.task.calculate_color_percentage(
            text_white_color, self.task.get_box_by_name('box_liberation')
        )

    def flying(self):
        if not getattr(self.task, 'has_lavitator', False):
            return False
        percent = self.task.calculate_color_percentage(
            text_white_color, self.task.get_box_by_name('edge_levitator')
        )
        return percent < 0.1

    def down(self):
        return (
            self.current_resonance() > 0 and not self.has_cd('resonance')
        ) or (
            self.current_liberation() > 0 and not self.has_cd('liberation')
        )

    def wait_down(self, click=True):
        # 冻结自ok-ww落地思路，不再引用BaseChar.wait_down。
        if not getattr(self.task, 'has_lavitator', False) and self.has_intro:
            duration = float(getattr(self, 'intro_motion_freeze_duration', 0.9) or 0.9)
            if click:
                self.continues_normal_attack(duration)
            else:
                self.sleep(duration)
            return
        start = time.time()
        while self.flying() and time.time() - start < 2.5:
            if click:
                self.task.click(interval=0.2)
            else:
                self.sleep(0.2)
            self.task.next_frame()

    def wait_intro(self, time_out=1.2, click=True):
        if self.has_intro:
            return self.task.wait_until(
                self.down,
                post_action=self.click_with_interval if click else None,
                time_out=time_out,
            )
        return True

    def _zfg_ensure_grounded(self, tag=''):
        """赞菲光冻结落地入口；不再调用上游 _ensure_grounded/wait_down。"""
        try:
            if not self.flying():
                return True
        except Exception:
            pass
        self.logger.debug(f'ZFG V4.6 {tag}: frozen grounded wait')
        self.wait_down(click=False)
        try:
            return not self.flying()
        except Exception:
            return bool(self.down())

    def record_resonance_use(self):
        self.last_res = time.time()

    def record_liberation_use(self):
        self.last_liberation = time.time()

    def record_echo_use(self):
        self.last_echo = time.time()

    def send_resonance_key(self, post_sleep=0, interval=-1, down_time=0.01):
        self._resonance_available = False
        return self.task.send_key(
            self.get_resonance_key(), interval=interval,
            down_time=down_time, after_sleep=post_sleep,
        )

    def send_echo_key(self, after_sleep=0, interval=-1, down_time=0.01):
        self._echo_available = False
        return self.task.send_key(
            self.get_echo_key(), interval=interval,
            down_time=down_time, after_sleep=after_sleep,
        )

    def send_liberation_key(self, after_sleep=0, interval=-1, down_time=0.01):
        self._liberation_available = False
        return self.task.send_key(
            self.get_liberation_key(), interval=interval,
            down_time=down_time, after_sleep=after_sleep,
        )

    def alert_skill_failed(self):
        try:
            self.task.log_error(
                'ZFG: skill input failed; check ok-ww keybinding / bottom input API.',
                notify=True,
            )
            self.task.screenshot('zfg_skill_input_failed')
        except Exception:
            pass

    def click_resonance(
        self, post_sleep=0, has_animation=False, send_click=True,
        animation_min_duration=0, check_cd=False, time_out=0, click_f=True,
    ):
        """冻结E输入事务；直接使用task可用性、按键和帧循环。"""
        clicked = False
        last_click = 0.0
        last_op = 'click'
        resonance_click_time = 0.0
        start = time.time()
        animation_start = 0.0
        last_f_click = 0.0
        timeout = self.ZFG_SKILL_TIME_OUT if time_out == 0 else max(0.05, float(time_out))

        while True:
            now = time.time()
            if now - start > timeout:
                self.task.in_liberation = False
                if time_out == 0:
                    self.alert_skill_failed()
                break
            if self.task.in_liberation and now - start > 6:
                self.task.in_liberation = False
                break

            if has_animation:
                if not self.task.in_team()[0]:
                    self.task.in_liberation = True
                    if animation_start == 0:
                        animation_start = now
                    timeout = self.ZFG_SKILL_TIME_OUT
                    if now - resonance_click_time > 6:
                        self.task.in_liberation = False
                        break
                    if (
                        click_f
                        and now - animation_start >= animation_min_duration
                        and now - last_f_click >= 0.1
                    ):
                        self.task.send_key('f')
                        last_f_click = now
                    self.task.next_frame()
                    self.check_combat()
                    continue
                elif self.task.in_liberation:
                    self.task.in_liberation = False
                    break

            self.check_combat()
            now = time.time()
            if not self.resonance_available() and (
                not has_animation or now - start > animation_min_duration
            ):
                break

            if now - last_click > 0.1:
                if send_click and last_op == 'resonance':
                    self.task.click()
                    last_op = 'click'
                    continue
                if self.resonance_available():
                    if resonance_click_time == 0:
                        clicked = True
                        resonance_click_time = now
                        self.record_resonance_use()
                    last_op = 'resonance'
                    self.send_resonance_key()
                    if has_animation:
                        self.sleep(0.2, check_combat=False)
                last_click = now
            self.task.next_frame()

        self.task.in_liberation = False
        if clicked:
            self.sleep(post_sleep)
        duration = time.time() - resonance_click_time if resonance_click_time else 0.0
        if animation_start > 0 and resonance_click_time > 0:
            self.add_freeze_duration(
                resonance_click_time, time.time() - animation_start
            )
        return clicked, duration, animation_start > 0

    def click_echo(self, duration=0, sleep_time=0, time_out=1):
        """冻结Q输入事务；直接使用task。"""
        if time_out == 0 and self.echo_available():
            self.send_echo_key()
            self.record_echo_use()
            return True
        try:
            if self.task.is_open_world_auto_combat() and self.ring_index == Elements.FIRE:
                return False
        except Exception:
            pass
        if self.has_cd('echo'):
            return False
        clicked = False
        start = time.time()
        last_click = 0.0
        deadline = max(0.0, float(time_out)) + max(0.0, float(duration))
        while True:
            now = time.time()
            if now - start > deadline:
                return False
            if not self.echo_available() and (duration == 0 or not clicked):
                break
            if duration > 0 and now - start > duration:
                break
            if now - last_click > 0.1:
                if not clicked:
                    self.record_echo_use()
                    clicked = True
                self.send_echo_key()
                last_click = now
            if now - start > self.ZFG_SKILL_TIME_OUT:
                self.alert_skill_failed()
                break
            self.task.next_frame()
        return clicked

    def click_liberation(
        self, con_less_than=-1, send_click=False, wait_if_cd_ready=0.1,
        animation_min_duration=0, click_f=True,
    ):
        """冻结R输入事务；直接使用task的in_team/按键/帧循环。"""
        if not getattr(self.task, 'use_liberation', True):
            return False
        if con_less_than > 0 and self.get_current_con() > con_less_than:
            return False

        start = time.time()
        last_click = 0.0
        clicked = False
        if not getattr(self.task, 'in_liberation', False):
            while self.liberation_available():
                if send_click:
                    self.click(interval=0.1)
                now = time.time()
                if now - last_click > 0.1:
                    self.send_liberation_key()
                    clicked = True
                    last_click = now
                if now - start > self.ZFG_SKILL_TIME_OUT:
                    self.alert_skill_failed()
                    self.task.raise_not_in_combat('ZFG: too long clicking liberation')
                self.task.next_frame()

            if clicked:
                if self.task.wait_until(
                    lambda: not self.task.in_team()[0],
                    time_out=0.4,
                    post_action=self.click_with_interval if send_click else None,
                ):
                    self.task.in_liberation = True
                else:
                    self.task.in_liberation = False
                    return False
            else:
                probe_start = time.time()
                while (
                    not self.has_cd('liberation')
                    and time.time() - probe_start < wait_if_cd_ready
                ):
                    self.send_liberation_key(after_sleep=0.05)
                    if self.task.wait_until(
                        lambda: not self.task.in_team()[0], time_out=0.1
                    ):
                        self.task.in_liberation = True
                if not self.task.in_liberation:
                    return False

        animation_start = time.time()
        last_f_click = 0.0
        while not self.task.in_team()[0]:
            self.task.in_liberation = True
            clicked = True
            if send_click:
                self.click(interval=0.1)
            now = time.time()
            if (
                click_f
                and now - animation_start >= animation_min_duration
                and now - last_f_click >= 0.1
            ):
                self.task.send_key('f')
                last_f_click = now
            if now - animation_start > 7:
                self.task.in_liberation = False
                self.task.raise_not_in_combat(
                    'ZFG: liberation animation too long / target may be dead'
                )
            self.task.next_frame()

        duration = time.time() - animation_start
        self.add_freeze_duration(animation_start, duration)
        self.record_liberation_use()
        self.task.in_liberation = False
        self._liberation_available = False
        return clicked

    def continues_normal_attack(
        self, duration, interval=0.1, after_sleep=0,
        click_resonance_if_ready_and_return=False, until_con_full=False,
    ):
        start = time.time()
        while time.time() - start < duration:
            if click_resonance_if_ready_and_return and self.resonance_available():
                return self.click_resonance()
            if until_con_full and self.is_con_full():
                return
            self.task.click()
            self.sleep(interval)
        self.sleep(after_sleep)

    def continues_right_click(self, duration, interval=0.1, direction_key=None):
        if direction_key is not None:
            self.task.send_key_down(direction_key)
            self.task.next_frame()
        try:
            start = time.time()
            while time.time() - start < duration:
                self.task.click(interval=interval, key='right')
        finally:
            if direction_key is not None:
                self.task.send_key_up(direction_key)

    def heavy_attack(self, duration=0.6):
        self.check_combat()
        self.task.mouse_down()
        try:
            self.sleep(duration)
        finally:
            self.task.mouse_up()
        self.sleep(0.01)

    def switch_out(self, con_full=False):
        """冻结切下场bookkeeping；实际切人仍由固定轴自己的_switch_to控制。"""
        self.last_switch_time = time.time()
        switched_with_full_con = bool(con_full or getattr(self, 'current_con', 0) == 1)
        self.is_current_char = False
        self.has_intro = False
        self.has_sub_dps_intro = False
        if switched_with_full_con:
            buff_time = float(getattr(self, '_buff_time', 0) or 0)
            if buff_time > 0:
                self.last_buff_time = self.last_switch_time
            self.current_con = 0


    STATE_KEY = 'zanfei_rotation_state'  # 共享FSM主体：step/phase/cycle等都放这里
    TEAM_SIGNATURE_KEY = 'zanfei_rotation_team_signature'  # 队伍变化检测；换队后重置固定轴
    SWITCH_LOG_KEY = 'zanfei_rotation_switch_logged'  # 避免重复刷同一条切人日志
    PHOEBE_PREHOLD_E_KEY = 'phoebe_prehold_e_active'  # 跨角色按住E：是否仍应保持按键
    PHOEBE_PREHOLD_SOURCE_KEY = 'phoebe_prehold_e_source'  # 记录是谁发起的预输入，便于查日志
    P1_PHOEBE_FORTE_EXPECTED_EMPTY_KEY = 'p1_phoebe_forte_expected_empty'
    P1_PHOEBE_E1_PENDING_KEY = 'p1_phoebe_e1_pending'
    P1_PHOEBE_E1_CONFIRMED_KEY = 'p1_phoebe_e1_confirmed'
    P1_PHOEBE_E1_INPUT_AT_KEY = 'p1_phoebe_e1_input_at'
    P1_PHOEBE_E1_RECOVERY_ATTEMPTED_KEY = 'p1_phoebe_e1_recovery_attempted'

    # P1/P2第一次Z后的赞妮quick-swap：普通E -> A/resource -> 强化E预释放 -> 切菲比。
    ZANI_PRE_R_PREP_SLICE_DONE_KEY = 'zani_pre_r_prep_slice_done'  # 赞妮quick-swap：本次PRECAST是否已结束并切回菲比
    ZANI_PRE_R_EFORTE_READY_KEY = 'zani_pre_r_eforte_ready'  # 赞妮强化E：PRECAST过程中是否观察到强化E READY
    ZANI_PRE_R_RETURN_STEP_KEY = 'zani_pre_r_return_step'  # 赞妮quick-swap：切回菲比后恢复到哪个STEP
    ZANI_PRE_R_RETURN_PHASE_KEY = 'zani_pre_r_return_phase'  # 赞妮quick-swap：切回菲比后恢复到STEP内哪个phase
    ZANI_PRE_R_PREP_SOURCE_KEY = 'zani_pre_r_prep_source'  # 赞妮quick-swap：记录本次PRECAST来自P1还是P2流程
    ZANI_PRE_R_PRECAST_E_ATTEMPTED_KEY = 'zani_pre_r_precast_e_attempted'  # 赞妮强化E：是否已开始尝试释放
    ZANI_PRE_R_PRECAST_E_CONSUMED_KEY = 'zani_pre_r_precast_e_consumed'  # 赞妮强化E识别：READY稳定消失或专属Buff连续2帧，任一成功即确认已释放
    ZANI_PRE_R_PRECAST_NORMAL_E_LAST_CAST_KEY = 'zani_pre_r_precast_normal_e_last_cast'  # 赞妮普通E：quick-swap最近一次成功释放时间
    ZANI_PRE_R_PRECAST_NORMAL_E_CASTS_KEY = 'zani_pre_r_precast_normal_e_casts'  # 赞妮普通E：本次quick-swap已成功释放次数
    P2_FIRST_Z_INTRO_USED_KEY = 'p2_first_z_intro_used'  # P2赞妮Z1/Z2：特殊变奏归属锁；True=Z1特殊/Z2普通，False=Z1普通/Z2特殊
    P2_ZANI_PRECHARGE_SEEDED_KEY = 'p2_zani_precharge_seeded'  # 上一轮R2后赞妮EA：是否已为下一轮P2完成强化E资源预充

    PHOEBE_LAST_CONFESSION_TIME_KEY = 'phoebe_last_confession_time'
    PHOEBE_LAST_R_CAST_TIME_KEY = 'phoebe_last_r_cast_time'
    P2_CONFESSION_AZ_USED_KEY = 'p2_confession_az_detour_used'  # 兼容旧日志：本轮是否至少走过一次光主等待槽
    P2_CONFESSION_AZ_COUNT_KEY = 'p2_confession_az_count'
    P2_CONFESSION_AZ_TARGET_KEY = 'p2_confession_az_target'
    P2_CONFESSION_RETRY_AFTER_KEY = 'p2_confession_retry_after'

    PHOEBE_R_COOLDOWN = 25.0
    ZANI_R2_HARD_DEADLINE_SHARED = 19.50
    P2_CONFESSION_R2_RESERVE = 6.00  # 给告解+R动画+切赞妮+N3/R2留出的尾端保护
    P2_CONFESSION_AZ_COST = 0.85
    P2_CONFESSION_SWITCH_TOTAL = 0.35
    P2_CONFESSION_PLAN_SAFETY = 0.25
    P2_CONFESSION_MAX_AZ = 6


    # P1开头按V4.3真实执行顺序排列：菲比 -> 光主 -> 赞妮 -> 菲比
    STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER = 'P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER'
    STEP_P1_ZANI_OPEN_EA_TO_PHOEBE = 'P1_ZANI_OPEN_EA_TO_PHOEBE'
    STEP_P1_ROVER_EQR_TO_ZANI = 'P1_ROVER_EQR_TO_ZANI'
    STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI = 'P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI'
    STEP_P1_ZANI_PRE_R_PREP_SLICE = 'P1_ZANI_PRE_R_PREP_SLICE'

    STEP_P1_ZANI_EFORTE_PREP = 'P1_ZANI_EFORTE_PREP'
    STEP_P1_ZANI_R1_N1_TO_ROVER = 'P1_ZANI_R1_N1_TO_ROVER'
    STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE = 'P1_ROVER_OPPORTUNITY_E_TO_PHOEBE'
    STEP_P1_PHOEBE_STAR_E1_TO_ZANI = 'P1_PHOEBE_STAR_E1_TO_ZANI'
    STEP_P1_ZANI_N2_TO_ROVER_R = 'P1_ZANI_N2_TO_ROVER_R'
    STEP_P1_ROVER_R_TO_ZANI = 'P1_ROVER_R_TO_ZANI'
    STEP_P1_ZANI_N3_TO_PHOEBE = 'P1_ZANI_N3_TO_PHOEBE'
    STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI = 'P1_PHOEBE_CONFESSION_R_TO_ZANI'
    STEP_P1_ZANI_N4_R2_EA_TO_PHOEBE = 'P1_ZANI_N4_R2_EA_TO_PHOEBE'

    STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI = 'P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI'
    STEP_P2_ZANI_PRE_R_PREP_SLICE = 'P2_ZANI_PRE_R_PREP_SLICE'
    STEP_P2_ZANI_EFORTE_PREP = 'P2_ZANI_EFORTE_PREP'
    STEP_P2_ZANI_R1_N1_TO_ROVER = 'P2_ZANI_R1_N1_TO_ROVER'
    STEP_P2_ROVER_SLOT_TO_ZANI = 'P2_ROVER_SLOT_TO_ZANI'
    STEP_P2_ZANI_N2_TO_PHOEBE = 'P2_ZANI_N2_TO_PHOEBE'

    STEP_P2_PHOEBE_CONFESSION_CHECK = 'P2_PHOEBE_CONFESSION_CHECK'
    STEP_P2_ROVER_AZ_WAIT_CONFESSION = 'P2_ROVER_AZ_WAIT_CONFESSION'
    STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI = 'P2_PHOEBE_CONFESSION_R_TO_ZANI'
    STEP_P2_ZANI_N3_R2_EA_TO_PHOEBE = 'P2_ZANI_N3_R2_EA_TO_PHOEBE'

    STEP_RECOVER_ZANI_LIBERATION = 'RECOVER_ZANI_LIBERATION'
    STEP_RECOVER_P2_PHOEBE = 'RECOVER_P2_PHOEBE'

    STEP_ACTOR = {
        STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER: 'Phoebe',
        STEP_P1_ZANI_OPEN_EA_TO_PHOEBE: 'Zani',
        STEP_P1_ROVER_EQR_TO_ZANI: 'Rover',
        STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI: 'Phoebe',
        STEP_P1_ZANI_PRE_R_PREP_SLICE: 'Zani',

        STEP_P1_ZANI_EFORTE_PREP: 'Zani',
        STEP_P1_ZANI_R1_N1_TO_ROVER: 'Zani',
        STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE: 'Rover',
        STEP_P1_PHOEBE_STAR_E1_TO_ZANI: 'Phoebe',
        STEP_P1_ZANI_N2_TO_ROVER_R: 'Zani',
        STEP_P1_ROVER_R_TO_ZANI: 'Rover',
        STEP_P1_ZANI_N3_TO_PHOEBE: 'Zani',
        STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI: 'Phoebe',
        STEP_P1_ZANI_N4_R2_EA_TO_PHOEBE: 'Zani',

        STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI: 'Phoebe',
        STEP_P2_ZANI_PRE_R_PREP_SLICE: 'Zani',
        STEP_P2_ZANI_EFORTE_PREP: 'Zani',
        STEP_P2_ZANI_R1_N1_TO_ROVER: 'Zani',
        STEP_P2_ROVER_SLOT_TO_ZANI: 'Rover',
        STEP_P2_ZANI_N2_TO_PHOEBE: 'Zani',
        STEP_P2_PHOEBE_CONFESSION_CHECK: 'Phoebe',
        STEP_P2_ROVER_AZ_WAIT_CONFESSION: 'Rover',
        STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI: 'Phoebe',
        STEP_P2_ZANI_N3_R2_EA_TO_PHOEBE: 'Zani',

        STEP_RECOVER_ZANI_LIBERATION: 'Zani',
        STEP_RECOVER_P2_PHOEBE: 'Phoebe',
    }

    SPECIAL_INTRO_TARGET = {
        'Phoebe': 'Zani',
        'Zani': 'Rover',
        'Rover': 'Phoebe',
    }

    CONCERTO_EFFECTIVE_FULL = 0.99
    INTRO_CONFIRM_FRAMES = 3
    INTRO_CONFIRM_TIMEOUT = 1.0
    POLL = 0.05

    SWITCH_TIMEOUT = 6.0
    SWITCH_RETRY_INTERVAL = 0.04

    def _release_phoebe_prehold(self, state, reason='cleanup'):
        if not isinstance(state, dict) or not state.get(self.PHOEBE_PREHOLD_E_KEY):
            return False
        try:
            self.task.send_key_up(self.get_resonance_key())
        except Exception:
            pass
        source = state.pop(self.PHOEBE_PREHOLD_SOURCE_KEY, None)
        state.pop(self.PHOEBE_PREHOLD_E_KEY, None)
        self.logger.info(
            f'ZFG Phoebe-E prehold RELEASE reason={reason} source={source}'
        )
        return True

    def _reedge_phoebe_prehold_on_entry(self, target_name, has_intro=False):
        """V4.3: Phoebe预输入E在切人确认首帧做一次UP->DOWN重新沿触发。

        赞妮侧的跨角色key_down负责把E提前送进输入队列；但部分实机会在角色切换期间
        吞掉持续按键的首个触发。确认current_index已经变成Phoebe后，立刻重建一次
        按键边沿，让告解长按尽可能从菲比登场首帧开始。特殊变奏入场不做此操作。
        """
        if target_name != 'Phoebe' or has_intro:
            return False

        state = getattr(self.task, self.STATE_KEY, None)
        if not isinstance(state, dict) or not state.get(self.PHOEBE_PREHOLD_E_KEY):
            return False

        try:
            key = self.get_resonance_key()
            self.task.send_key_up(key)
            self.task.send_key_down(key)
            self.logger.info(
                f'ZFG V4.6 Phoebe-E PREHOLD re-edge on entry source='
                f'{state.get(self.PHOEBE_PREHOLD_SOURCE_KEY)}'
            )
            return True
        except Exception as exc:
            self.logger.warning(
                f'ZFG V4.6 Phoebe-E PREHOLD re-edge failed: {exc}'
            )
            return False

    def _clear_zfg_state(self):
        state = getattr(self.task, self.STATE_KEY, None)
        self._release_phoebe_prehold(state, reason='clear-zfg-state')
        for key in (self.STATE_KEY, self.SWITCH_LOG_KEY):
            if hasattr(self.task, key):
                delattr(self.task, key)

    def _zfg_team_matches(self):
        chars = getattr(self.task, 'chars', None)
        if not isinstance(chars, (list, tuple)):
            return False

        chars = tuple(char for char in chars if char is not None)

        signature = tuple(
            (
                str(getattr(char, 'char_name', '') or '')
                .casefold()
                .removeprefix('labels.'),
                getattr(char, 'index', None),
            )
            for char in chars
        )

        required = {
            'char_zani',
            'char_phoebe',
            'char_rover',
        }

        identity_ok = (
            len(chars) == 3
            and {name for name, _ in signature} == required
            and any(char is self for char in chars)
        )

        rover = None
        for char in chars:
            name = (
                str(getattr(char, 'char_name', '') or '')
                .casefold()
                .removeprefix('labels.')
            )
            if name == 'char_rover':
                rover = char
                break

        rover_form = -1
        if rover is not None:
            try:
                if hasattr(self.task, 'get_known_ring_index'):
                    rover_form = self.task.get_known_ring_index(rover)
                else:
                    rover_form = getattr(rover, 'ring_index', -1)
            except Exception:
                rover_form = getattr(rover, 'ring_index', -1)

        form_ok = rover_form < 0 or rover_form == Elements.SPECTRO
        matched = identity_ok and form_ok

        previous = getattr(self.task, self.TEAM_SIGNATURE_KEY, None)

        if signature != previous:
            self._clear_zfg_state()
            setattr(self.task, self.TEAM_SIGNATURE_KEY, signature)
            self.logger.info(
                f'ZFG team changed matched={matched} '
                f'rover_form={rover_form} members={signature}'
            )
        elif not matched:
            self._clear_zfg_state()

        return matched

    def _zfg_state(self):
        """Return shared FSM state.

        First creation starts from P1.  If an already-existing state is damaged,
        do not replay the one-time opening: route to the agreed recovery entry.
        """
        state = getattr(self.task, self.STATE_KEY, None)

        if state is None:
            state = {
                'step': self.STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER,
                'cycle': 1,
                'nightfall_count': 0,
            }
            setattr(self.task, self.STATE_KEY, state)
            self.logger.info(
                'ZFG FSM initialize -> P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER'
            )
            return state

        if not isinstance(state, dict) or 'step' not in state:
            old_cycle = state.get('cycle', 1) if isinstance(state, dict) else 1
            state = {
                'cycle': old_cycle,
                'nightfall_count': 0,
            }
            setattr(self.task, self.STATE_KEY, state)
            self._route_broken_state_to_recovery(
                state,
                reason='state-missing-step',
            )

        return state


    def _advance_step(self, state, next_step):
        old = state.get('step')
        state['step'] = next_step
        state.pop('phase', None)
        state.pop('phase_started_at', None)

        self.logger.info(
            f'ZFG FSM advance {old} -> {next_step} '
            f'cycle={state.get("cycle", 1)} '
            f'nightfall={state.get("nightfall_count", 0)}'
        )

    def _expected_actor(self, state):
        if state.get('detour_active'):
            return state.get('detour_actor')
        return self.STEP_ACTOR.get(state.get('step'))

    def _route_broken_state_to_recovery(self, state, reason='unknown'):
        """Route a damaged FSM without replaying the one-time P1 opening.

        - Zani still in R state -> RECOVER_ZANI_LIBERATION.
        - Otherwise -> RECOVER_P2_PHOEBE.
        """
        if not isinstance(state, dict):
            return 'Phoebe'

        self._clear_detour(state)
        state.pop('phase', None)
        state.pop('phase_started_at', None)

        zani = self if self.ACTOR == 'Zani' else self._find_target_char('Zani')
        if zani is not None and getattr(zani, 'in_liberation', False):
            state['step'] = self.STEP_RECOVER_ZANI_LIBERATION
            actor = 'Zani'
        else:
            state['step'] = self.STEP_RECOVER_P2_PHOEBE
            actor = 'Phoebe'

        self.logger.error(
            f'ZFG broken FSM recovery reason={reason} '
            f'-> step={state.get("step")} actor={actor}'
        )
        return actor

    def get_switch_priority(
        self,
        current_char=None,
        has_intro=False,
        target_low_con=False,
    ):
        if not self._zfg_team_matches():
            return super().get_switch_priority(
                current_char,
                has_intro,
                target_low_con,
            )

        state = self._zfg_state()
        expected = self._expected_actor(state)

        if expected is None:
            expected = self._route_broken_state_to_recovery(
                state,
                reason=f'unknown-step:{state.get("step")}',
            )

        if not getattr(self.task, self.SWITCH_LOG_KEY, False):
            self.logger.info(
                f'ZFG FSM-exclusive switching enabled '
                f'step={state.get("step")} expected={expected}'
            )
            setattr(self.task, self.SWITCH_LOG_KEY, True)

        return (
            SwitchPriority.MUST
            if expected == self.ACTOR
            else SwitchPriority.NO
        )

    def _find_target_char(self, target_name):
        target_name = target_name.casefold()

        for char in getattr(self.task, 'chars', []):
            if char is None or char is self:
                continue

            names = (
                getattr(char, 'name', None),
                char.__class__.__name__,
                getattr(char, 'display_name', None),
            )

            for name in names:
                if name and str(name).casefold() == target_name:
                    return char

        return None

    def _raw_con_full(self):
        try:
            return bool(self.task.is_con_full())
        except Exception:
            return bool(self.is_con_full())

    def _read_concerto(self):
        if self._raw_con_full():
            return 1.0

        try:
            value = float(self.get_current_con())
        except Exception:
            try:
                value = float(self.task.get_current_con())
            except Exception:
                value = 0.0

        return max(0.0, min(1.0, value))

    def _concerto_effectively_full(self):
        return (
            self._raw_con_full()
            or self._read_concerto() >= self.CONCERTO_EFFECTIVE_FULL
        )

    def _confirm_hard_intro_ready(self, target_name):
        start = time.time()
        full_frames = 0

        while time.time() - start < self.INTRO_CONFIRM_TIMEOUT:
            if self._raw_con_full():
                full_frames += 1

                if full_frames >= self.INTRO_CONFIRM_FRAMES:
                    self.logger.info(
                        f'ZFG hard-intro guard passed '
                        f'{self.ACTOR}->{target_name} '
                        f'{full_frames}/{self.INTRO_CONFIRM_FRAMES}'
                    )
                    return True
            else:
                full_frames = 0

            self.sleep(self.POLL)
            self.task.next_frame()

        self.logger.warning(
            f'ZFG hard-intro guard failed '
            f'{self.ACTOR}->{target_name}'
        )
        return False

    def _switch_to(self, target_name, expect_intro=None):
        target = self._find_target_char(target_name)

        if target is None:
            self.logger.error(
                f'ZFG {self.ACTOR}: target not found -> {target_name}'
            )
            return False

        if expect_intro is True:
            allowed = self.SPECIAL_INTRO_TARGET.get(self.ACTOR)

            if target_name != allowed:
                self.logger.error(
                    f'ZFG invalid special intro '
                    f'{self.ACTOR}->{target_name}; '
                    f'allowed={allowed}'
                )
                return False

            if not self._confirm_hard_intro_ready(target_name):
                return False

            has_intro = True

        elif expect_intro is False:
            if self._concerto_effectively_full():
                self.logger.warning(
                    f'ZFG block forced-normal switch '
                    f'{self.ACTOR}->{target_name}: concerto full'
                )
                return False
            has_intro = False

        else:
            has_intro = self._concerto_effectively_full()

        target.has_intro = has_intro
        target.has_sub_dps_intro = (
            has_intro and getattr(self, 'is_sub_dps', False)
        )

        start = time.time()
        last_send = 0.0

        while time.time() - start < self.SWITCH_TIMEOUT:
            self.check_combat()

            try:
                in_team, current_index, _ = self.task.in_team()
            except Exception:
                in_team, current_index = False, -1

            if in_team and current_index == target.index:
                # V4.3: 若此前已经跨角色预按菲比E，在确认菲比成为当前角色的首帧
                # 立即做一次UP->DOWN re-edge，再进入常规切人bookkeeping。
                self._reedge_phoebe_prehold_on_entry(target_name, has_intro)

                self.task.in_liberation = False
                target.is_current_char = True

                self.switch_out(con_full=has_intro)
                target.last_switch_in_time = time.time()

                if has_intro:
                    now = time.time()
                    self.add_freeze_duration(
                        now,
                        target.intro_motion_freeze_duration,
                        -100,
                    )
                    self.last_outro_time = now

                self.logger.info(
                    f'ZFG exact switch success '
                    f'{self.ACTOR}->{target_name} '
                    f'intro={has_intro}'
                )
                return True

            if (
                in_team
                and current_index == self.index
                and not target.wait_switch()
            ):
                now = time.time()

                if now - last_send >= self.SWITCH_RETRY_INTERVAL:
                    self.task.send_key(target.index + 1)
                    last_send = now

            self.sleep(self.SWITCH_RETRY_INTERVAL)
            self.task.next_frame()

        self.logger.error(
            f'ZFG exact switch timeout '
            f'{self.ACTOR}->{target_name}'
        )
        return False

    def _clear_detour(self, state):
        for key in (
            'detour_active',
            'detour_actor',
            'detour_final_target',
            'detour_next_step',
            'detour_next_phase',
            'detour_resume_step',
            'detour_resume_phase',
        ):
            state.pop(key, None)

    def _switch_route(
        self,
        state,
        planned_target,
        next_step,
        force_intro=False,
    ):
        """
        正常切人入口。

        若协奏满，但planned_target不是当前角色正确的特殊变奏目标：
        保存主轴step/phase -> 先让正确角色吃特殊变奏
        -> 再自然切planned_target -> 进入next_step。
        """

        if force_intro:
            if self._switch_to(planned_target, expect_intro=True):
                self._advance_step(state, next_step)
                return True
            return False

        full = self._concerto_effectively_full()
        special_target = self.SPECIAL_INTRO_TARGET.get(self.ACTOR)

        if (
            full
            and special_target
            and planned_target != special_target
        ):
            if planned_target == 'Phoebe' and state.get(self.PHOEBE_PREHOLD_E_KEY):
                self.logger.info(
                    f'ZFG Phoebe-E prehold PRESERVE across detour '
                    f'{self.ACTOR}->{special_target}->Phoebe'
                )
            resume_step = state.get('step')
            resume_phase = state.get('phase')

            self.logger.warning(
                f'ZFG intro detour required: '
                f'source={self.ACTOR} '
                f'planned={planned_target} '
                f'correct_intro={special_target} '
                f'resume={resume_step}/{resume_phase}'
            )

            if not self._switch_to(
                special_target,
                expect_intro=None,
            ):
                return False

            state['detour_active'] = True
            state['detour_actor'] = special_target
            state['detour_final_target'] = planned_target
            state['detour_next_step'] = next_step
            state['detour_resume_step'] = resume_step
            state['detour_resume_phase'] = resume_phase
            return True

        if self._switch_to(planned_target, expect_intro=None):
            self._advance_step(state, next_step)
            return True

        return False

    def _run_detour_if_needed(self, state):
        if not state.get('detour_active'):
            return False

        expected = state.get('detour_actor')

        if expected != self.ACTOR:
            self._recover_wrong_actor(state)
            return True

        final_target = state.get('detour_final_target')
        next_step = state.get('detour_next_step')
        next_phase = state.get('detour_next_phase')
        resume_step = state.get('detour_resume_step')
        resume_phase = state.get('detour_resume_phase')

        self.logger.info(
            f'ZFG detour actor={self.ACTOR} '
            f'return={final_target} '
            f'resume={resume_step}/{resume_phase}'
        )

        if self._switch_to(final_target, expect_intro=None):
            self._clear_detour(state)
            self._advance_step(state, next_step)
            if next_phase is not None:
                state['phase'] = next_phase
                self.logger.info(
                    f'ZFG V4.6 detour resume phase restored -> {next_step}/{next_phase}'
                )

        return True

    def _recover_wrong_actor(self, state):
        expected = self._expected_actor(state)

        if expected and expected != self.ACTOR:
            self.logger.warning(
                f'ZFG wrong actor: current={self.ACTOR} '
                f'step={state.get("step")} expected={expected}'
            )
            return self._switch_to(
                expected,
                expect_intro=None,
            )

        recovery_actor = self._route_broken_state_to_recovery(
            state,
            reason=f'unhandled-step:{state.get("step")}',
        )

        if recovery_actor != self.ACTOR:
            return self._switch_to(
                recovery_actor,
                expect_intro=None,
            )

        return False


    def on_combat_end(self, chars):
        self._clear_zfg_state()

        if hasattr(self.task, self.TEAM_SIGNATURE_KEY):
            delattr(self.task, self.TEAM_SIGNATURE_KEY)

        return None


class Rover(_ZFGFSM, BuiltinRover):
    ACTOR = 'Rover'


    def init(self):
        """冻结光主形态初始化；只接task的ring识别底层。"""
        previous = getattr(self, 'ring_index', -1)
        ensure = getattr(self.task, '_ensure_ring_index', None)
        if callable(ensure):
            ensure()
        current = getattr(self, 'ring_index', -1)
        if current != previous:
            bind = getattr(self, '_bind_form_logger', None)
            if callable(bind):
                try:
                    bind()
                except Exception:
                    pass
        return current


    R_TO_Q_SETTLE = 0.60  # R后给UI恢复的短稳定窗；只用于需要继续判Q/E的阶段
    ROVER_R_COOLDOWN = 20.0
    ROVER_LAST_R_CAST_KEY = 'rover_last_r_cast_time'
    P1_R_WAIT_MAX = 1.00  # V4.3: R near-ready hard-priority protection ceiling
    P1_R_HARD_PRIORITY_WINDOW = 1.00
    P1_INTRO_R_UNLOCK_WAIT_MAX = 1.20  # Spectro Rover特殊变奏动作锁约0.92s，留少量UI余量
    P1_R_WAIT_POLL = 0.03
    ROVER_R_ENERGY_READY = 0.95
    ROVER_R_RING_BINS = 72
    ROVER_R_RING_HSV_LOWER = (14, 50, 85)
    ROVER_R_RING_HSV_UPPER = (44, 255, 255)
    ROVER_R_ICON_RADIUS_SCALE = 1.35
    ROVER_R_RING_INNER_RATIO = 0.88
    ROVER_R_RING_OUTER_RATIO = 1.10
    ROVER_R_ROI_SCALE = 1.60
    ROVER_R_BIN_MIN_COVERAGE = 0.05
    ROVER_R_BIN_RELATIVE_COVERAGE = 0.25
    AZ_A_TO_Z_GAP = 0.08
    AZ_SETTLE = 0.12

    P2_R_ACTION_SETTLE = 0.12
    P2_E_ACTION_SETTLE = 0.08
    P2_QUEUE_MAX_PASSES = 8

    REQUIRED_E_TIMEOUT = 1.8
    REQUIRED_Q_TIMEOUT = 1.8
    REQUIRED_R_TIMEOUT = 2.8

    # V4.3 confirmation tiers: P1 E/Q and P2 opportunity E/Q use SOFT_COMMIT; R remains HARD_GATE.
    SOFT_COMMIT_POLL = 0.02
    SOFT_COMMIT_READY_WINDOW = 0.30
    SOFT_COMMIT_SETTLE = 0.04
    P1_SOFT_COMMIT_POLL = SOFT_COMMIT_POLL
    P1_SOFT_COMMIT_READY_WINDOW = SOFT_COMMIT_READY_WINDOW
    P1_SOFT_COMMIT_SETTLE = SOFT_COMMIT_SETTLE
    P1_R_HARD_GATE_TIMEOUT = 2.20
    REQUIRED_EFORTE_TIMEOUT = 2.2

    F_CHECK_INTERVAL = 0.18
    F_POST_ACTION_SETTLE_TIME = 0.12

    def f_break(
        self,
        check_f_on_switch=False,
        force=False,
    ):
        if self._zfg_team_matches():
            return False
        return self._zfg_f_break_raw(
            check_f_on_switch=check_f_on_switch,
            force=force,
        )

    def do_perform(self):
        self.init()

        if not self._zfg_team_matches():
            return super().do_perform()

        state = self._zfg_state()

        if self._run_detour_if_needed(state):
            return

        step = state.get('step')

        if (
            step not in (
                self.STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE,
                self.STEP_P1_ROVER_R_TO_ZANI,
                self.STEP_P2_ROVER_SLOT_TO_ZANI,
                self.STEP_P2_ROVER_AZ_WAIT_CONFESSION,
            )
            and self._field_f_check(resume_label=f'step={step}')
        ):
            return

        self.logger.info(
            f'ZFG V4.6 Rover step={step} phase={state.get("phase")} '
            f'intro={self.has_intro} forte={self.is_forte_full()} '
            f'E={self.resonance_available()} R={self.liberation_available()}'
        )

        if step == self.STEP_P1_ROVER_EQR_TO_ZANI:
            return self._p1_eqr_to_zani(state)

        if step == self.STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE:
            return self._p1_opportunity_e_to_phoebe(state)

        if step == self.STEP_P1_ROVER_R_TO_ZANI:
            return self._p1_r_to_zani(state)

        if step == self.STEP_P2_ROVER_SLOT_TO_ZANI:
            return self._p2_rover_slot(
                state,
                self.STEP_P2_ZANI_N2_TO_PHOEBE,
            )

        if step == self.STEP_P2_ROVER_AZ_WAIT_CONFESSION:
            return self._p2_az_wait_confession(state)

        return self._recover_wrong_actor(state)


    def _run_f_break_with_freeze(self, label):
        f_start = time.time()
        if not self._zfg_f_break_raw(check_f_on_switch=False, force=False):
            return False
        f_duration = max(0.0, time.time() - f_start)
        if self.F_POST_ACTION_SETTLE_TIME > 0:
            self.sleep(self.F_POST_ACTION_SETTLE_TIME)
            self.task.next_frame()
        blocked = max(0.0, time.time() - f_start)
        self.add_freeze_duration(f_start, blocked)
        self.logger.info(
            f'ZFG V4.6 Rover F execution during {label}; '
            f'F={f_duration:.2f}s freeze={blocked:.2f}s'
        )
        return True

    def _field_f_check(self, force=False, resume_label='Rover on-field'):
        if not self.is_current_char:
            return False
        now = time.time()
        last = getattr(self, '_zfg_last_f_check', -100.0)
        if not force and now - last < self.F_CHECK_INTERVAL:
            return False
        self._zfg_last_f_check = now
        self.task.next_frame()
        return self._run_f_break_with_freeze(resume_label)


    def _cast_normal_e_once(self):
        if not self.resonance_available():
            return False

        clicked, _, _ = self.click_resonance(
            send_click=True,
            time_out=0.8,
        )
        if clicked:
            self.logger.info('ZFG V4.6 Rover normal/available E confirmed')
        return bool(clicked)

    def _cast_enhanced_e_once(self):
        if not (
            self.is_forte_full()
            and self.resonance_available()
        ):
            return False

        clicked, _, _ = self.click_resonance(
            send_click=True,
            time_out=0.8,
        )
        if clicked:
            self.logger.info('ZFG V4.6 Rover enhanced E confirmed')
        return bool(clicked)

    def _cast_any_e_required(self, tag):
        start = time.time()

        while time.time() - start < self.REQUIRED_E_TIMEOUT:
            self.task.next_frame()

            if self.is_forte_full() and self.resonance_available():
                if self._cast_enhanced_e_once():
                    return True

            if self.resonance_available():
                if self._cast_normal_e_once():
                    return True

            self.task.click()
            self.sleep(self.POLL)

        self.logger.warning(
            f'ZFG V4.6 Rover {tag}: E not confirmed'
        )
        return False

    def _cast_q_required(self, tag):
        start = time.time()

        while time.time() - start < self.REQUIRED_Q_TIMEOUT:
            self.task.next_frame()

            if self.echo_available():
                result = self.click_echo(time_out=0.8)
                self.task.next_frame()
                consumed = not self.echo_available()

                if result or consumed:
                    self.logger.info(
                        f'ZFG V4.6 Rover {tag}: Q confirmed '
                        f'base_result={bool(result)} consumed={consumed}'
                    )
                    return True

            self.sleep(self.POLL)

        self.logger.warning(
            f'ZFG V4.6 Rover {tag}: Q not confirmed'
        )
        return False


    def _p1_soft_commit_e(self, tag):
        """P1 E SOFT_COMMIT: wait only for a legal input window; do not block on E icon/CD confirmation."""
        start = time.time()
        while time.time() - start < self.P1_SOFT_COMMIT_READY_WINDOW:
            self.task.next_frame()
            if self.resonance_available():
                enhanced = bool(self.is_forte_full())
                self.task.send_key(self.get_resonance_key())
                self.logger.info(
                    f'ZFG V4.6 Rover {tag}: SOFT_COMMIT '
                    f'{"ENHANCED_E" if enhanced else "NORMAL_E"} INPUT_COMMITTED; '
                    'skip post-cast confirmation'
                )
                self.sleep(self.P1_SOFT_COMMIT_SETTLE, check_combat=False)
                return True
            self.sleep(self.P1_SOFT_COMMIT_POLL)
        self.logger.warning(f'ZFG V4.6 Rover {tag}: SOFT_COMMIT E input window not ready -> keep phase')
        return False

    def _p1_soft_commit_q(self, tag):
        """P1 Q SOFT_COMMIT: one available-frame input is enough; consumption result is diagnostic only."""
        start = time.time()
        while time.time() - start < self.P1_SOFT_COMMIT_READY_WINDOW:
            self.task.next_frame()
            if self.echo_available():
                api_result = self.click_echo(time_out=0)
                self.logger.info(
                    f'ZFG V4.6 Rover {tag}: SOFT_COMMIT Q INPUT_COMMITTED '
                    f'api_result={bool(api_result)}; skip consumption confirmation'
                )
                self.sleep(self.P1_SOFT_COMMIT_SETTLE, check_combat=False)
                return True
            self.sleep(self.P1_SOFT_COMMIT_POLL)
        self.logger.warning(f'ZFG V4.6 Rover {tag}: SOFT_COMMIT Q input window not ready -> keep phase')
        return False

    def _soft_commit_e_once(self, tag):
        """Shared P1/P2 SOFT_COMMIT E: one legal frame authorizes one input, no post-cast proof."""
        self.task.next_frame()
        if not self.resonance_available():
            return False
        enhanced = bool(self.is_forte_full())
        self.task.send_key(self.get_resonance_key())
        self.logger.info(
            f'ZFG V4.6 Rover {tag}: SOFT_COMMIT '
            f'{"ENHANCED_E" if enhanced else "NORMAL_E"} INPUT_COMMITTED; '
            'post-cast confirmation skipped'
        )
        return True

    def _soft_commit_q_once(self, tag):
        """Shared P1/P2 SOFT_COMMIT Q: send once when available; API result is diagnostic only."""
        self.task.next_frame()
        if not self.echo_available():
            return False
        api_result = self.click_echo(time_out=0)
        self.logger.info(
            f'ZFG V4.6 Rover {tag}: SOFT_COMMIT Q INPUT_COMMITTED '
            f'api_result={bool(api_result)}; consumption confirmation skipped'
        )
        return True

    def _p1_r_hard_gate(self, tag):
        """P1 R HARD_GATE: wait for real R-ready and confirm the cast, but do not inject filler A while waiting."""
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < self.P1_R_HARD_GATE_TIMEOUT:
            self.task.next_frame()
            if self._field_f_check(resume_label=f'{tag}-wait-R'):
                continue
            if self.liberation_available():
                input_time = time.time()
                result = self.click_liberation(send_click=True)
                if result:
                    self._record_rover_r_cast(input_time, tag)
                    self.logger.info(f'ZFG V4.6 Rover {tag}: HARD_GATE R PASSED')
                    return True
            self.sleep(self.P1_SOFT_COMMIT_POLL)
        self.logger.warning(f'ZFG V4.6 Rover {tag}: HARD_GATE R not confirmed')
        return False

    def _record_rover_r_cast(self, input_time, tag):
        state = self._zfg_state()
        state[self.ROVER_LAST_R_CAST_KEY] = float(input_time)
        self.logger.info(f'ZFG V4.6 Rover {tag}: R cooldown timestamp armed at input')

    def _rover_r_remaining(self, state):
        predicted = None
        last = state.get(self.ROVER_LAST_R_CAST_KEY)
        if isinstance(last, (int, float)) and last > 0:
            elapsed = max(0.0, float(self.time_elapsed_accounting_for_freeze(last)))
            predicted = max(0.0, self.ROVER_R_COOLDOWN - elapsed)
        try:
            ui_cd = max(0.0, float(self.task.get_cd('liberation', self.index)))
        except Exception:
            ui_cd = None
        if ui_cd is not None and ui_cd > 0.0:
            return ui_cd
        if predicted is not None:
            return predicted
        return ui_cd

    def _sample_rover_r_energy(self):
        """72-bin黄色外环占用率；>=95%才认为有足够R能量。"""
        try:
            box = self.task.get_box_by_name('box_liberation')
            frame = self.task.frame
            bx, by = float(box.x), float(box.y)
            bw, bh = float(box.width), float(box.height)
        except Exception:
            return None
        if frame is None or getattr(frame, 'ndim', 0) < 3:
            return None

        base_r = min(bw, bh) / 2.0
        if base_r < 4:
            return None
        cx0, cy0 = bx + bw / 2.0, by + bh / 2.0
        half = base_r * self.ROVER_R_ROI_SCALE
        fh, fw = frame.shape[:2]
        x0 = max(0, int(math.floor(cx0 - half)))
        x1 = min(fw, int(math.ceil(cx0 + half)))
        y0 = max(0, int(math.floor(cy0 - half)))
        y1 = min(fh, int(math.ceil(cy0 + half)))
        if x1 - x0 < 8 or y1 - y0 < 8:
            return None

        image = frame[y0:y1, x0:x1, :3]
        cx, cy = cx0 - x0, cy0 - y0
        hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(
            hsv,
            np.array(self.ROVER_R_RING_HSV_LOWER, dtype=np.uint8),
            np.array(self.ROVER_R_RING_HSV_UPPER, dtype=np.uint8),
        )
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

        h, w = mask.shape[:2]
        yy, xx = np.ogrid[:h, :w]
        dx = xx - float(cx)
        dy = yy - float(cy)
        radius = np.sqrt(dx ** 2 + dy ** 2)
        true_r = base_r * self.ROVER_R_ICON_RADIUS_SCALE
        annulus = (
            (radius >= true_r * self.ROVER_R_RING_INNER_RATIO)
            & (radius <= true_r * self.ROVER_R_RING_OUTER_RATIO)
        )
        angle = (np.arctan2(dy, dx) + 2 * np.pi) % (2 * np.pi)
        colored = mask > 0
        bins = int(self.ROVER_R_RING_BINS)
        coverages = []
        for i in range(bins):
            lo = 2 * np.pi * i / bins
            hi = 2 * np.pi * (i + 1) / bins
            sector = annulus & (angle >= lo) & (angle < hi)
            total = int(np.count_nonzero(sector))
            if total <= 0:
                coverages.append(0.0)
            else:
                coverages.append(int(np.count_nonzero(colored & sector)) / total)
        if not coverages:
            return None
        peak = max(coverages)
        threshold = max(self.ROVER_R_BIN_MIN_COVERAGE, peak * self.ROVER_R_BIN_RELATIVE_COVERAGE)
        active_bins = sum(1 for value in coverages if value >= threshold)
        energy = max(0.0, min(1.0, active_bins / float(bins)))
        self.logger.info(
            f'ZFG V4.6 Rover R-energy arc={active_bins}/{bins} energy={energy:.3f} '
            f'gate={self.ROVER_R_ENERGY_READY:.2f}'
        )
        return energy

    def _cast_r_required(self, tag):
        start = time.time()
        while self.time_elapsed_accounting_for_freeze(start) < self.REQUIRED_R_TIMEOUT:
            self.task.next_frame()
            if self._field_f_check(resume_label=f'{tag}-wait-R'):
                continue
            if self.liberation_available():
                input_time = time.time()
                result = self.click_liberation(send_click=True)
                if result:
                    self._record_rover_r_cast(input_time, tag)
                    self.logger.info(f'ZFG V4.6 Rover {tag}: R confirmed')
                    return True
            self.task.click()
            self.sleep(self.POLL)
        self.logger.warning(f'ZFG V4.6 Rover {tag}: R not confirmed')
        return False

    def _cast_q_soft(self, tag):
        if not self.echo_available():
            self.logger.info(f'ZFG V4.6 Rover {tag}: soft Q skip cooldown')
            return False
        result = self.click_echo(time_out=0)
        self.logger.info(f'ZFG V4.6 Rover {tag}: soft Q result={result}')
        return bool(result)

    def _cast_az_slot(self):
        self.logger.info('ZFG V4.6 Rover AZ start')
        self.task.click()
        self.sleep(self.AZ_A_TO_Z_GAP)
        self.task.next_frame()
        self.heavy_attack()
        self.sleep(self.AZ_SETTLE)
        self.logger.info('ZFG V4.6 Rover AZ end')
        return True


    def _p1_eqr_to_zani(self, state):
        """V4.3 P1 opening Rover: E -> Q -> R, then forced-normal switch Zani.

        Opening order is now Phoebe -> Rover -> Zani -> Phoebe so the first Rover R
        happens before Zani EA instead of being delayed by an extra Zani field segment.
        """
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._zfg_ensure_grounded('P1 opening EQR')
            state['phase'] = 'e'
            phase = 'e'

        if phase == 'e':
            if not self._p1_soft_commit_e('P1 opening EQR'):
                return
            state['phase'] = 'q'
            phase = 'q'

        if phase == 'q':
            if not self._p1_soft_commit_q('P1 opening EQR'):
                return
            state['phase'] = 'r'
            phase = 'r'

        if phase == 'r':
            if not self._p1_r_hard_gate('P1 opening EQR'):
                return
            state['phase'] = 'switch_zani'
            phase = 'switch_zani'

        if phase == 'switch_zani':
            self.logger.info(
                'ZFG V4.6 Rover P1 opening EQR complete -> forced-normal Zani; '
                'next Zani performs deterministic EA then Phoebe'
            )
            if self._switch_to('Zani', expect_intro=False):
                self._advance_step(state, self.STEP_P1_ZANI_OPEN_EA_TO_PHOEBE)
            return

    def _p1_opportunity_e_to_phoebe(self, state):
        """
        P1 N1后的光主只做“当前帧机会动作”，绝不为了强化E站场等待。

        优先级：
          1) 当前已经满足强化E条件 -> 尝试一次强化E；
          2) 否则当前普通E可用 -> 尝试一次普通E；
          3) 两者都没有 -> 空过。

        明确禁止：AZ、A补回路、等待未来CD、等待强化E、R、Q、主动F。
        不论E是否成功，随后都立即切菲比。
        """
        phase = state.get('phase', 'snapshot')

        if phase == 'snapshot':
            if self.has_intro:
                self.wait_intro(time_out=0.8, click=False)

            self.task.next_frame()
            forte_now = bool(self.is_forte_full())
            e_now = bool(self.resonance_available())
            primary = 'NONE'

            if forte_now and e_now:
                clicked, _, _ = self.click_resonance(
                    send_click=False,
                    time_out=0.55,
                )
                primary = 'ENHANCED_E' if clicked else 'ENHANCED_E_ATTEMPT_FAILED'
            elif e_now:
                clicked, _, _ = self.click_resonance(
                    send_click=False,
                    time_out=0.55,
                )
                primary = 'NORMAL_E' if clicked else 'NORMAL_E_ATTEMPT_FAILED'

            self.logger.info(
                f'ZFG V4.6 Rover P1 N1 OPPORTUNITY-SLOT '
                f'forte_now={forte_now} e_now={e_now} primary={primary}; '
                f'NO-AZ NO-WAIT NO-Q NO-F -> Phoebe'
            )

            state['phase'] = 'switch_phoebe'
            phase = 'switch_phoebe'

        if phase == 'switch_phoebe':
            self._switch_route(
                state,
                'Phoebe',
                self.STEP_P1_PHOEBE_STAR_E1_TO_ZANI,
            )


    def _p1_r_to_zani(self, state):
        """V4.3 P1 N2 Rover slot: R is a hard priority when it is within 1.0s.

        If energy is sufficient and R is READY/near-ready, spend up to one second
        doing only R checks/attempts. A failed click no longer downgrades immediately
        to Q/E. If the 1.0s slice expires, keep this phase for the next perform call.
        After a successful R, opportunistically submit Q and then enhanced/normal E.
        """
        phase = state.get('phase', 'r_gate')

        if phase == 'r_gate':
            self.task.next_frame()
            energy = self._sample_rover_r_energy()
            r_left = self._rover_r_remaining(state)
            ready_now = bool(self.liberation_available())
            energy_ok = energy is None or energy >= self.ROVER_R_ENERGY_READY
            near_ready = ready_now or (
                energy_ok
                and r_left is not None
                and r_left <= self.P1_R_HARD_PRIORITY_WINDOW
            ) or (energy_ok and self.has_intro and r_left is None)

            self.logger.info(
                f'ZFG V4.6 Rover P1 R HARD-PRIORITY decision ready_now={ready_now} '
                f'intro={self.has_intro} energy={"unknown" if energy is None else f"{energy:.3f}"} '
                f'R_left={"unknown" if r_left is None else f"{r_left:.3f}"} '
                f'near_ready={near_ready} protect={self.P1_R_HARD_PRIORITY_WINDOW:.2f}s'
            )

            if near_ready:
                start = time.time()
                attempts = 0
                r_cast = False
                while time.time() - start < self.P1_R_HARD_PRIORITY_WINDOW:
                    self.task.next_frame()
                    if self.liberation_available():
                        attempts += 1
                        input_time = time.time()
                        result = self.click_liberation(send_click=False, click_f=False)
                        if result:
                            self._record_rover_r_cast(input_time, 'P1 N2 HARD-PRIORITY')
                            self.logger.info(
                                f'ZFG V4.6 Rover P1 R HARD-PRIORITY PASSED attempts={attempts}'
                            )
                            r_cast = True
                            break
                        self.logger.warning(
                            f'ZFG V4.6 Rover P1 R attempt failed attempts={attempts}; '
                            'keep guarding R, DO NOT downgrade yet'
                        )
                    self.sleep(self.P1_R_WAIT_POLL, check_combat=False)

                if not r_cast:
                    self.logger.warning(
                        f'ZFG V4.6 Rover P1 R HARD-PRIORITY 1.0s slice expired; '
                        'keep phase=r_gate for retry, DO NOT leave without R'
                    )
                    return

                state['p1_n2_rover_r_cast'] = True
                state['phase'] = 'post_r'
                phase = 'post_r'
            else:
                # Only allow a no-R fallback when R is genuinely not within the
                # protected window (e.g. energy low or CD still >1s).
                self.logger.warning(
                    'ZFG V4.6 Rover P1 R not within protected window -> opportunity fallback only'
                )
                state['p1_n2_rover_r_cast'] = False
                state['phase'] = 'post_r'
                phase = 'post_r'

        if phase == 'post_r':
            actions = []
            if self._soft_commit_q_once('P1 N2 post-R'):
                actions.append('Q_SOFT')

            self.task.next_frame()
            if self.resonance_available():
                enhanced = bool(self.is_forte_full())
                if self._soft_commit_e_once('P1 N2 post-R'):
                    actions.append('ENHANCED_E_SOFT' if enhanced else 'NORMAL_E_SOFT')

            self.logger.info(
                f'ZFG V4.6 Rover P1 N2 post-R actions={actions} '
                f'R_cast={bool(state.get("p1_n2_rover_r_cast"))} -> Zani'
            )
            state['phase'] = 'switch_zani'
            phase = 'switch_zani'

        if phase == 'switch_zani':
            state.pop('p1_n2_rover_r_cast', None)
            self._switch_route(state, 'Zani', self.STEP_P1_ZANI_N3_TO_PHOEBE)

    def _p2_confession_prayer_remaining_rover(self, state):
        last = state.get(self.PHOEBE_LAST_CONFESSION_TIME_KEY)
        if not isinstance(last, (int, float)) or last <= 0:
            return None
        return max(0.0, 24.0 - max(0.0, time.time() - last))

    def _p2_confession_r_remaining_rover(self, state):
        last = state.get(self.PHOEBE_LAST_R_CAST_TIME_KEY)
        if not isinstance(last, (int, float)) or last <= 0:
            return None
        elapsed = max(0.0, float(self.time_elapsed_accounting_for_freeze(last)))
        return max(0.0, self.PHOEBE_R_COOLDOWN - elapsed)

    def _p2_confession_fill_room_rover(self, state):
        start = float(state.get('zani_r1_timer_start', 0) or 0)
        if start <= 0:
            return None, None
        elapsed = max(0.0, float(self.time_elapsed_accounting_for_freeze(start)))
        r2_left = max(0.0, self.ZANI_R2_HARD_DEADLINE_SHARED - elapsed)
        return r2_left, max(0.0, r2_left - self.P2_CONFESSION_R2_RESERVE)

    def _p2_az_wait_confession(self, state):
        """V4.3动态填轴：AZ×n，每发后重算；离场前E可用则E->立刻切菲比。"""
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._zfg_ensure_grounded('P2 confession-wait entry')
            state['phase'] = 'az_loop'
            phase = 'az_loop'

        if phase == 'az_loop':
            target = int(state.get(self.P2_CONFESSION_AZ_TARGET_KEY, 0) or 0)
            done = int(state.get(self.P2_CONFESSION_AZ_COUNT_KEY, 0) or 0)

            while done < target and done < self.P2_CONFESSION_MAX_AZ:
                prayer = self._p2_confession_prayer_remaining_rover(state)
                r_rem = self._p2_confession_r_remaining_rover(state)
                retry_after = float(state.get(self.P2_CONFESSION_RETRY_AFTER_KEY, 0.0) or 0.0)
                retry_wait = max(0.0, retry_after - time.time())
                known = [x for x in (prayer, r_rem) if isinstance(x, (int, float))]
                if retry_wait > 0:
                    known.append(retry_wait)
                need = max(known) if known else None
                r2_left, fill_room = self._p2_confession_fill_room_rover(state)

                if need is not None and need <= self.P2_CONFESSION_AZ_COST + self.P2_CONFESSION_PLAN_SAFETY:
                    self.logger.info(
                        f'ZFG V4.6 Rover P2 CONFESSION-WAIT stop AZ: need={need:.2f}s too short'
                    )
                    break
                if fill_room is not None and fill_room < self.P2_CONFESSION_AZ_COST + self.P2_CONFESSION_PLAN_SAFETY:
                    self.logger.warning(
                        f'ZFG V4.6 Rover P2 CONFESSION-WAIT stop AZ for R2 reserve '
                        f'R2_left={r2_left:.2f}s fill_room={fill_room:.2f}s'
                    )
                    break

                self.logger.info(
                    f'ZFG V4.6 Rover P2 CONFESSION-WAIT AZ #{done + 1}/{target} start '
                    f'Prayer={prayer} Rrem={r_rem} need={need} R2left={r2_left}'
                )
                self._cast_az_slot()
                done += 1
                state[self.P2_CONFESSION_AZ_COUNT_KEY] = done
                state[self.P2_CONFESSION_AZ_USED_KEY] = True

            state['phase'] = 'exit_e'
            phase = 'exit_e'

        if phase == 'exit_e':
            if self.resonance_available():
                enhanced = bool(self.is_forte_full())
                committed = self._soft_commit_e_once('P2 CONFESSION-WAIT exit')
                e_kind = (
                    'ENHANCED_E_SOFT' if committed and enhanced else
                    'NORMAL_E_SOFT' if committed else
                    'E_WINDOW_LOST'
                )
            else:
                e_kind = 'NONE'
            self.logger.info(
                f'ZFG V4.6 Rover P2 CONFESSION-WAIT exit E={e_kind}; '
                'SOFT_COMMIT / NO post-cast wait -> Phoebe immediately'
            )
            state['phase'] = 'switch_phoebe'
            phase = 'switch_phoebe'

        if phase == 'switch_phoebe':
            state.pop(self.P2_CONFESSION_AZ_TARGET_KEY, None)
            self._switch_route(
                state, 'Phoebe', self.STEP_P2_PHOEBE_CONFESSION_CHECK,
            )


    def _cast_r_slot(self):
        if not self.liberation_available():
            return False
        input_time = time.time()
        result = self.click_liberation(send_click=True)
        if result:
            self._record_rover_r_cast(input_time, 'P2 PRIORITY-SLOT')
        self.logger.info(f'ZFG V4.6 Rover P2 SLOT=R result={result}')
        return bool(result)

    def _p2_rover_slot(self, state, zani_next_step):
        """V4.3 P2机会槽：F > R > Q > 强化E > 普通E > AZ；F后直接串REQ。

        每个高优先级技能本槽最多消费一次；只有R/Q/E都没有产生收益时才打一发AZ。
        AZ之后只重新检查E，不再用连续A等待未来技能，避免无意义站场。
        """
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            # F显式第一优先级。V4.3关键修正：F成功返回后已经完成F动画，
            # 不再额外wait_intro()/wait_down()，直接进入R/Q/E队列，消除肉眼罚站。
            f_used = self._field_f_check(force=True, resume_label='P2 PRIORITY-SLOT entry')
            state['p2_slot_f_used'] = bool(f_used)
            if f_used:
                self.logger.info(
                    'ZFG V4.6 Rover P2 F complete -> DIRECT PRIORITY CHAIN; '
                    'skip wait_intro/wait_down, next action should be R if READY'
                )
                self.task.next_frame()
            else:
                if self.has_intro:
                    self.wait_intro(time_out=1.20, click=False)
                    self.task.next_frame()
                self._zfg_ensure_grounded('P2 priority-slot entry')
            state['p2_slot_r_used'] = False
            state['p2_slot_q_used'] = False
            state['p2_slot_e_used'] = False
            state['p2_slot_az_used'] = False
            state['p2_slot_productive'] = False
            state['p2_slot_actions'] = []
            state['phase'] = 'priority'
            phase = 'priority'

        if phase == 'priority':
            actions = state.setdefault('p2_slot_actions', [])
            passes = 0
            while passes < self.P2_QUEUE_MAX_PASSES:
                passes += 1
                self.task.next_frame()

                az_used = bool(state.get('p2_slot_az_used'))

                # AZ之后只重查E：不再等待/补放R或Q，避免最低优先级动作反过来延长高优先级窗口。
                # 1) R
                if (not az_used) and not state.get('p2_slot_r_used') and self.liberation_available():
                    if not self._cast_r_slot():
                        self.logger.warning('ZFG V4.6 Rover P2 PRIORITY R available but cast failed -> retry next perform')
                        return
                    state['p2_slot_r_used'] = True
                    state['p2_slot_productive'] = True
                    actions.append('R')
                    self.sleep(self.P2_R_ACTION_SETTLE)
                    continue

                # 2) Q：V4.3下放SOFT_COMMIT。输入提交即记本槽已用，不等待消费确认。
                if (not az_used) and not state.get('p2_slot_q_used') and self.echo_available():
                    if self._soft_commit_q_once('P2 PRIORITY-SLOT'):
                        state['p2_slot_q_used'] = True
                        state['p2_slot_productive'] = True
                        actions.append('Q_SOFT')
                        self.task.next_frame()
                        continue

                # 3) 强化E；4) 普通E：同样只按一次，输入提交后继续队列。
                if not state.get('p2_slot_e_used') and self.resonance_available():
                    enhanced = bool(self.is_forte_full())
                    if self._soft_commit_e_once('P2 PRIORITY-SLOT'):
                        e_kind = 'ENHANCED_E_SOFT' if enhanced else 'NORMAL_E_SOFT'
                        state['p2_slot_e_used'] = True
                        state['p2_slot_productive'] = True
                        actions.append(e_kind)
                        self.sleep(self.P2_E_ACTION_SETTLE, check_combat=False)
                        continue

                if az_used:
                    break

                # 5) AZ只在此前R/Q/E均没有收益时作为最后fallback；打一发后只重查E。
                if not state.get('p2_slot_productive') and not state.get('p2_slot_az_used'):
                    self._cast_az_slot()
                    state['p2_slot_az_used'] = True
                    actions.append('AZ')
                    self._field_f_check(force=True, resume_label='P2 PRIORITY-SLOT after AZ')
                    self.task.next_frame()
                    # AZ可能立即填出强化E，回到循环只让E有机会吃掉。
                    continue

                break

            self.logger.info(
                f'ZFG V4.6 Rover P2 PRIORITY-SLOT done actions={actions} '
                f'productive={bool(state.get("p2_slot_productive"))} '
                f'AZ={bool(state.get("p2_slot_az_used"))} -> Zani'
            )
            if getattr(self, 'buff_time', 0) > 0:
                self.last_buff_time = time.time()
            state['phase'] = 'switch_zani'
            phase = 'switch_zani'

        if phase == 'switch_zani':
            for key in (
                'p2_slot_f_used', 'p2_slot_r_used', 'p2_slot_q_used', 'p2_slot_e_used',
                'p2_slot_az_used', 'p2_slot_productive', 'p2_slot_actions',
            ):
                state.pop(key, None)
            self._switch_route(
                state,
                'Zani',
                zani_next_step,
            )

