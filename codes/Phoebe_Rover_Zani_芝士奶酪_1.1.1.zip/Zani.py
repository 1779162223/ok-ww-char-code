"""
赞菲光固定轴 V4.6 - Zani（赞妮）

定位：
- V4.6 Frozen Runtime：高频BaseChar/角色私有helper冻结到赞菲光自身，FSM直接接task/frame/input底层；上游中层helper改名/签名变化不再直接影响固定轴。
- V4.4基于V4.3_rev1：只改第一次Z后的PRECAST强化E确认；特殊E实际发送后，READY稳定消失或特殊E专属Buff连续两帧识别成功，任一成功即确认并切菲比。
- 兼容新版ok-ww：预置统一_zfg_ensure_grounded()落地兼容层；当前赞妮流程无需额外落地等待，但后续新增动作统一走该接口。
- V4.3继续保留P1确认分层，并把SOFT_COMMIT下放到P2的低风险机会动作；特殊E、R、Nightfall/R2等主状态门仍保持HARD_GATE。
- P1开场改为菲比告解R-E1-Q -> 光主E-Q-R -> 赞妮E-A -> 菲比；赞妮EA继续保留70ms/180ms提交保护。
- P1 N1后的菲比改为Star -> E1，不再额外3A；赞妮R1前普通E恢复释放成功确认，P1 N1首A加入W 0.20s抑制后撤。
- P2 Z1/Z2特殊变奏归属锁定保持；后续EFORTE既有固定槽判断保持V4.3_rev1原样，本版PRECAST只新增专属Buff连续2帧确认；P1/P2 R2后EA统一70ms/180ms提交保护。
- V4.3 rev1：最终终夜追加伤害落地保护；P2 N3固定0.50s，P1 N4按19.90s安全上限动态补足。
"""


import time
import math

import cv2
import numpy as np

from ok import color_range_to_bound
from src import text_white_color
from src.char.BaseChar import SwitchPriority, Elements
from src.char.Zani import Zani as BuiltinZani


class _ZFGFSM:
    ACTOR = None

    # =========================================================
    # ZFG Frozen Runtime V1
    # 目标：FSM只依赖本层；本层再直接接ok-ww task/frame/input底层。
    # 上游角色/BaseChar helper改名或改签名时，不再直接影响固定轴。
    # =========================================================
    ZFG_RUNTIME_REV = 1
    ZFG_SKILL_TIME_OUT = 15.0
    ZFG_FORTE_WHITE_COLOR = {
        'r': (244, 255), 'g': (246, 255), 'b': (250, 255),
    }

    def sleep(self, sec, check_combat=True):
        sec = max(0.0, float(sec))
        if not check_combat:
            self.task.skip_combat_check = True
        try:
            self.task.sleep(sec)
        finally:
            if not check_combat:
                self.task.skip_combat_check = False

    def check_combat(self):
        return self.task.check_combat()

    def _zfg_f_break_raw(self, check_f_on_switch=False, force=False):
        """直接接task.f_break，不再经过BaseChar/角色helper。"""
        if force:
            self.task.send_key('f', after_sleep=0.05)
        if check_f_on_switch and not bool(getattr(self, 'check_f_on_switch', False)):
            return False
        return bool(self.task.f_break())

    def add_freeze_duration(self, start, duration=-1.0, freeze_time=0.1):
        return self.task.add_freeze_duration(start, duration, freeze_time)

    def time_elapsed_accounting_for_freeze(self, start, intro_motion_freeze=False):
        return self.task.time_elapsed_accounting_for_freeze(start, intro_motion_freeze)

    def get_resonance_key(self):
        return self.task.get_resonance_key()

    def get_liberation_key(self):
        return self.task.get_liberation_key()

    def get_echo_key(self):
        return self.task.get_echo_key()

    def click(self, *args, **kwargs):
        kwargs['down_time'] = 0.01
        return self.task.click(*args, **kwargs)

    def click_with_interval(self, interval=0.1):
        return self.click(interval=interval)

    def has_cd(self, box_name):
        return self.task.has_cd(box_name)

    def available(self, box, check_color=True, check_cd=True):
        if self.is_current_char:
            return self.task.available(box, check_color=check_color, check_cd=check_cd)
        return not self.task.has_cd(box, self.index)

    def resonance_available(self):
        return self.available('resonance', check_color=False)

    def echo_available(self):
        return self.available('echo', check_color=False)

    def liberation_available(self, check_color=True):
        return self.available('liberation', check_color=check_color)

    def get_current_con(self):
        if getattr(self, 'current_con', 0) == 1:
            return 1
        self.current_con = self.task.get_current_con()
        return self.current_con

    def is_con_full(self):
        if getattr(self, 'current_con', 0) == 1:
            return True
        return bool(self.task.is_con_full())

    def is_mouse_forte_full(self):
        return bool(self.task.find_mouse_forte())

    def is_e_forte_full(self):
        return bool(self.task.find_e_forte())

    def is_forte_full(self):
        # 菲比告解形态的特殊Z使用鼠标forte图标；其余角色使用通用白色forte条。
        if self.ACTOR == 'Phoebe' and bool(getattr(self, 'star_available', False)):
            return self.is_mouse_forte_full()
        box = self.task.box_of_screen_scaled(
            3840, 2160, 2251, 1993, 2311, 2016,
            name='zfg_forte_full', hcenter=True,
        )
        white_percent = self.task.calculate_color_percentage(self.ZFG_FORTE_WHITE_COLOR, box)
        box.confidence = white_percent
        try:
            self.task.draw_boxes('zfg_forte_full', box)
        except Exception:
            pass
        return white_percent > 0.08

    def current_resonance(self):
        return self.task.calculate_color_percentage(
            text_white_color, self.task.get_box_by_name('box_resonance')
        )

    def current_liberation(self):
        return self.task.calculate_color_percentage(
            text_white_color, self.task.get_box_by_name('box_liberation')
        )

    def flying(self):
        if not getattr(self.task, 'has_lavitator', False):
            return False
        percent = self.task.calculate_color_percentage(
            text_white_color, self.task.get_box_by_name('edge_levitator')
        )
        return percent < 0.1

    def down(self):
        return (
            self.current_resonance() > 0 and not self.has_cd('resonance')
        ) or (
            self.current_liberation() > 0 and not self.has_cd('liberation')
        )

    def wait_down(self, click=True):
        # 冻结自ok-ww落地思路，不再引用BaseChar.wait_down。
        if not getattr(self.task, 'has_lavitator', False) and self.has_intro:
            duration = float(getattr(self, 'intro_motion_freeze_duration', 0.9) or 0.9)
            if click:
                self.continues_normal_attack(duration)
            else:
                self.sleep(duration)
            return
        start = time.time()
        while self.flying() and time.time() - start < 2.5:
            if click:
                self.task.click(interval=0.2)
            else:
                self.sleep(0.2)
            self.task.next_frame()

    def wait_intro(self, time_out=1.2, click=True):
        if self.has_intro:
            return self.task.wait_until(
                self.down,
                post_action=self.click_with_interval if click else None,
                time_out=time_out,
            )
        return True

    def _zfg_ensure_grounded(self, tag=''):
        """赞菲光冻结落地入口；不再调用上游 _ensure_grounded/wait_down。"""
        try:
            if not self.flying():
                return True
        except Exception:
            pass
        self.logger.debug(f'ZFG V4.6 {tag}: frozen grounded wait')
        self.wait_down(click=False)
        try:
            return not self.flying()
        except Exception:
            return bool(self.down())

    def record_resonance_use(self):
        self.last_res = time.time()

    def record_liberation_use(self):
        self.last_liberation = time.time()

    def record_echo_use(self):
        self.last_echo = time.time()

    def send_resonance_key(self, post_sleep=0, interval=-1, down_time=0.01):
        self._resonance_available = False
        return self.task.send_key(
            self.get_resonance_key(), interval=interval,
            down_time=down_time, after_sleep=post_sleep,
        )

    def send_echo_key(self, after_sleep=0, interval=-1, down_time=0.01):
        self._echo_available = False
        return self.task.send_key(
            self.get_echo_key(), interval=interval,
            down_time=down_time, after_sleep=after_sleep,
        )

    def send_liberation_key(self, after_sleep=0, interval=-1, down_time=0.01):
        self._liberation_available = False
        return self.task.send_key(
            self.get_liberation_key(), interval=interval,
            down_time=down_time, after_sleep=after_sleep,
        )

    def alert_skill_failed(self):
        try:
            self.task.log_error(
                'ZFG: skill input failed; check ok-ww keybinding / bottom input API.',
                notify=True,
            )
            self.task.screenshot('zfg_skill_input_failed')
        except Exception:
            pass

    def click_resonance(
        self, post_sleep=0, has_animation=False, send_click=True,
        animation_min_duration=0, check_cd=False, time_out=0, click_f=True,
    ):
        """冻结E输入事务；直接使用task可用性、按键和帧循环。"""
        clicked = False
        last_click = 0.0
        last_op = 'click'
        resonance_click_time = 0.0
        start = time.time()
        animation_start = 0.0
        last_f_click = 0.0
        timeout = self.ZFG_SKILL_TIME_OUT if time_out == 0 else max(0.05, float(time_out))

        while True:
            now = time.time()
            if now - start > timeout:
                self.task.in_liberation = False
                if time_out == 0:
                    self.alert_skill_failed()
                break
            if self.task.in_liberation and now - start > 6:
                self.task.in_liberation = False
                break

            if has_animation:
                if not self.task.in_team()[0]:
                    self.task.in_liberation = True
                    if animation_start == 0:
                        animation_start = now
                    timeout = self.ZFG_SKILL_TIME_OUT
                    if now - resonance_click_time > 6:
                        self.task.in_liberation = False
                        break
                    if (
                        click_f
                        and now - animation_start >= animation_min_duration
                        and now - last_f_click >= 0.1
                    ):
                        self.task.send_key('f')
                        last_f_click = now
                    self.task.next_frame()
                    self.check_combat()
                    continue
                elif self.task.in_liberation:
                    self.task.in_liberation = False
                    break

            self.check_combat()
            now = time.time()
            if not self.resonance_available() and (
                not has_animation or now - start > animation_min_duration
            ):
                break

            if now - last_click > 0.1:
                if send_click and last_op == 'resonance':
                    self.task.click()
                    last_op = 'click'
                    continue
                if self.resonance_available():
                    if resonance_click_time == 0:
                        clicked = True
                        resonance_click_time = now
                        self.record_resonance_use()
                    last_op = 'resonance'
                    self.send_resonance_key()
                    if has_animation:
                        self.sleep(0.2, check_combat=False)
                last_click = now
            self.task.next_frame()

        self.task.in_liberation = False
        if clicked:
            self.sleep(post_sleep)
        duration = time.time() - resonance_click_time if resonance_click_time else 0.0
        if animation_start > 0 and resonance_click_time > 0:
            self.add_freeze_duration(
                resonance_click_time, time.time() - animation_start
            )
        return clicked, duration, animation_start > 0

    def click_echo(self, duration=0, sleep_time=0, time_out=1):
        """冻结Q输入事务；直接使用task。"""
        if time_out == 0 and self.echo_available():
            self.send_echo_key()
            self.record_echo_use()
            return True
        try:
            if self.task.is_open_world_auto_combat() and self.ring_index == Elements.FIRE:
                return False
        except Exception:
            pass
        if self.has_cd('echo'):
            return False
        clicked = False
        start = time.time()
        last_click = 0.0
        deadline = max(0.0, float(time_out)) + max(0.0, float(duration))
        while True:
            now = time.time()
            if now - start > deadline:
                return False
            if not self.echo_available() and (duration == 0 or not clicked):
                break
            if duration > 0 and now - start > duration:
                break
            if now - last_click > 0.1:
                if not clicked:
                    self.record_echo_use()
                    clicked = True
                self.send_echo_key()
                last_click = now
            if now - start > self.ZFG_SKILL_TIME_OUT:
                self.alert_skill_failed()
                break
            self.task.next_frame()
        return clicked

    def click_liberation(
        self, con_less_than=-1, send_click=False, wait_if_cd_ready=0.1,
        animation_min_duration=0, click_f=True,
    ):
        """冻结R输入事务；直接使用task的in_team/按键/帧循环。"""
        if not getattr(self.task, 'use_liberation', True):
            return False
        if con_less_than > 0 and self.get_current_con() > con_less_than:
            return False

        start = time.time()
        last_click = 0.0
        clicked = False
        if not getattr(self.task, 'in_liberation', False):
            while self.liberation_available():
                if send_click:
                    self.click(interval=0.1)
                now = time.time()
                if now - last_click > 0.1:
                    self.send_liberation_key()
                    clicked = True
                    last_click = now
                if now - start > self.ZFG_SKILL_TIME_OUT:
                    self.alert_skill_failed()
                    self.task.raise_not_in_combat('ZFG: too long clicking liberation')
                self.task.next_frame()

            if clicked:
                if self.task.wait_until(
                    lambda: not self.task.in_team()[0],
                    time_out=0.4,
                    post_action=self.click_with_interval if send_click else None,
                ):
                    self.task.in_liberation = True
                else:
                    self.task.in_liberation = False
                    return False
            else:
                probe_start = time.time()
                while (
                    not self.has_cd('liberation')
                    and time.time() - probe_start < wait_if_cd_ready
                ):
                    self.send_liberation_key(after_sleep=0.05)
                    if self.task.wait_until(
                        lambda: not self.task.in_team()[0], time_out=0.1
                    ):
                        self.task.in_liberation = True
                if not self.task.in_liberation:
                    return False

        animation_start = time.time()
        last_f_click = 0.0
        while not self.task.in_team()[0]:
            self.task.in_liberation = True
            clicked = True
            if send_click:
                self.click(interval=0.1)
            now = time.time()
            if (
                click_f
                and now - animation_start >= animation_min_duration
                and now - last_f_click >= 0.1
            ):
                self.task.send_key('f')
                last_f_click = now
            if now - animation_start > 7:
                self.task.in_liberation = False
                self.task.raise_not_in_combat(
                    'ZFG: liberation animation too long / target may be dead'
                )
            self.task.next_frame()

        duration = time.time() - animation_start
        self.add_freeze_duration(animation_start, duration)
        self.record_liberation_use()
        self.task.in_liberation = False
        self._liberation_available = False
        return clicked

    def continues_normal_attack(
        self, duration, interval=0.1, after_sleep=0,
        click_resonance_if_ready_and_return=False, until_con_full=False,
    ):
        start = time.time()
        while time.time() - start < duration:
            if click_resonance_if_ready_and_return and self.resonance_available():
                return self.click_resonance()
            if until_con_full and self.is_con_full():
                return
            self.task.click()
            self.sleep(interval)
        self.sleep(after_sleep)

    def continues_right_click(self, duration, interval=0.1, direction_key=None):
        if direction_key is not None:
            self.task.send_key_down(direction_key)
            self.task.next_frame()
        try:
            start = time.time()
            while time.time() - start < duration:
                self.task.click(interval=interval, key='right')
        finally:
            if direction_key is not None:
                self.task.send_key_up(direction_key)

    def heavy_attack(self, duration=0.6):
        self.check_combat()
        self.task.mouse_down()
        try:
            self.sleep(duration)
        finally:
            self.task.mouse_up()
        self.sleep(0.01)

    def switch_out(self, con_full=False):
        """冻结切下场bookkeeping；实际切人仍由固定轴自己的_switch_to控制。"""
        self.last_switch_time = time.time()
        switched_with_full_con = bool(con_full or getattr(self, 'current_con', 0) == 1)
        self.is_current_char = False
        self.has_intro = False
        self.has_sub_dps_intro = False
        if switched_with_full_con:
            buff_time = float(getattr(self, '_buff_time', 0) or 0)
            if buff_time > 0:
                self.last_buff_time = self.last_switch_time
            self.current_con = 0


    STATE_KEY = 'zanfei_rotation_state'  # 共享FSM主体：step/phase/cycle等都放这里
    TEAM_SIGNATURE_KEY = 'zanfei_rotation_team_signature'  # 队伍变化检测；换队后重置固定轴
    SWITCH_LOG_KEY = 'zanfei_rotation_switch_logged'  # 避免重复刷同一条切人日志
    PHOEBE_PREHOLD_E_KEY = 'phoebe_prehold_e_active'  # 跨角色按住E：是否仍应保持按键
    PHOEBE_PREHOLD_SOURCE_KEY = 'phoebe_prehold_e_source'  # 记录是谁发起的预输入，便于查日志
    P1_PHOEBE_FORTE_EXPECTED_EMPTY_KEY = 'p1_phoebe_forte_expected_empty'
    P1_PHOEBE_E1_PENDING_KEY = 'p1_phoebe_e1_pending'
    P1_PHOEBE_E1_CONFIRMED_KEY = 'p1_phoebe_e1_confirmed'
    P1_PHOEBE_E1_INPUT_AT_KEY = 'p1_phoebe_e1_input_at'
    P1_PHOEBE_E1_RECOVERY_ATTEMPTED_KEY = 'p1_phoebe_e1_recovery_attempted'

    # P1/P2第一次Z后的赞妮quick-swap：普通E -> A/resource -> 强化E预释放 -> 切菲比。
    ZANI_PRE_R_PREP_SLICE_DONE_KEY = 'zani_pre_r_prep_slice_done'  # 赞妮quick-swap：本次PRECAST是否已结束并切回菲比
    ZANI_PRE_R_EFORTE_READY_KEY = 'zani_pre_r_eforte_ready'  # 赞妮强化E：PRECAST过程中是否观察到强化E READY
    ZANI_PRE_R_RETURN_STEP_KEY = 'zani_pre_r_return_step'  # 赞妮quick-swap：切回菲比后恢复到哪个STEP
    ZANI_PRE_R_RETURN_PHASE_KEY = 'zani_pre_r_return_phase'  # 赞妮quick-swap：切回菲比后恢复到STEP内哪个phase
    ZANI_PRE_R_PREP_SOURCE_KEY = 'zani_pre_r_prep_source'  # 赞妮quick-swap：记录本次PRECAST来自P1还是P2流程
    ZANI_PRE_R_PRECAST_E_ATTEMPTED_KEY = 'zani_pre_r_precast_e_attempted'  # 赞妮强化E：是否已开始尝试释放
    ZANI_PRE_R_PRECAST_E_CONSUMED_KEY = 'zani_pre_r_precast_e_consumed'  # 赞妮强化E识别：READY稳定消失或专属Buff连续2帧，任一成功即确认已释放
    ZANI_PRE_R_PRECAST_NORMAL_E_LAST_CAST_KEY = 'zani_pre_r_precast_normal_e_last_cast'  # 赞妮普通E：quick-swap最近一次成功释放时间
    ZANI_PRE_R_PRECAST_NORMAL_E_CASTS_KEY = 'zani_pre_r_precast_normal_e_casts'  # 赞妮普通E：本次quick-swap已成功释放次数
    P2_FIRST_Z_INTRO_USED_KEY = 'p2_first_z_intro_used'  # P2赞妮Z1/Z2：特殊变奏归属锁；True=Z1特殊/Z2普通，False=Z1普通/Z2特殊
    P2_ZANI_PRECHARGE_SEEDED_KEY = 'p2_zani_precharge_seeded'  # 上一轮R2后赞妮EA：是否已为下一轮P2完成强化E资源预充

    PHOEBE_LAST_CONFESSION_TIME_KEY = 'phoebe_last_confession_time'
    PHOEBE_LAST_R_CAST_TIME_KEY = 'phoebe_last_r_cast_time'
    P2_CONFESSION_AZ_USED_KEY = 'p2_confession_az_detour_used'  # 兼容旧日志：本轮是否至少走过一次光主等待槽
    P2_CONFESSION_AZ_COUNT_KEY = 'p2_confession_az_count'
    P2_CONFESSION_AZ_TARGET_KEY = 'p2_confession_az_target'
    P2_CONFESSION_RETRY_AFTER_KEY = 'p2_confession_retry_after'

    PHOEBE_R_COOLDOWN = 25.0
    ZANI_R2_HARD_DEADLINE_SHARED = 19.50
    P2_CONFESSION_R2_RESERVE = 6.00  # 给告解+R动画+切赞妮+N3/R2留出的尾端保护
    P2_CONFESSION_AZ_COST = 0.85
    P2_CONFESSION_SWITCH_TOTAL = 0.35
    P2_CONFESSION_PLAN_SAFETY = 0.25
    P2_CONFESSION_MAX_AZ = 6


    # P1开头按V4.3真实执行顺序排列：菲比 -> 光主 -> 赞妮 -> 菲比
    STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER = 'P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER'
    STEP_P1_ZANI_OPEN_EA_TO_PHOEBE = 'P1_ZANI_OPEN_EA_TO_PHOEBE'
    STEP_P1_ROVER_EQR_TO_ZANI = 'P1_ROVER_EQR_TO_ZANI'
    STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI = 'P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI'
    STEP_P1_ZANI_PRE_R_PREP_SLICE = 'P1_ZANI_PRE_R_PREP_SLICE'

    STEP_P1_ZANI_EFORTE_PREP = 'P1_ZANI_EFORTE_PREP'
    STEP_P1_ZANI_R1_N1_TO_ROVER = 'P1_ZANI_R1_N1_TO_ROVER'
    STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE = 'P1_ROVER_OPPORTUNITY_E_TO_PHOEBE'
    STEP_P1_PHOEBE_STAR_E1_TO_ZANI = 'P1_PHOEBE_STAR_E1_TO_ZANI'
    STEP_P1_ZANI_N2_TO_ROVER_R = 'P1_ZANI_N2_TO_ROVER_R'
    STEP_P1_ROVER_R_TO_ZANI = 'P1_ROVER_R_TO_ZANI'
    STEP_P1_ZANI_N3_TO_PHOEBE = 'P1_ZANI_N3_TO_PHOEBE'
    STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI = 'P1_PHOEBE_CONFESSION_R_TO_ZANI'
    STEP_P1_ZANI_N4_R2_EA_TO_PHOEBE = 'P1_ZANI_N4_R2_EA_TO_PHOEBE'

    STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI = 'P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI'
    STEP_P2_ZANI_PRE_R_PREP_SLICE = 'P2_ZANI_PRE_R_PREP_SLICE'
    STEP_P2_ZANI_EFORTE_PREP = 'P2_ZANI_EFORTE_PREP'
    STEP_P2_ZANI_R1_N1_TO_ROVER = 'P2_ZANI_R1_N1_TO_ROVER'
    STEP_P2_ROVER_SLOT_TO_ZANI = 'P2_ROVER_SLOT_TO_ZANI'
    STEP_P2_ZANI_N2_TO_PHOEBE = 'P2_ZANI_N2_TO_PHOEBE'

    STEP_P2_PHOEBE_CONFESSION_CHECK = 'P2_PHOEBE_CONFESSION_CHECK'
    STEP_P2_ROVER_AZ_WAIT_CONFESSION = 'P2_ROVER_AZ_WAIT_CONFESSION'
    STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI = 'P2_PHOEBE_CONFESSION_R_TO_ZANI'
    STEP_P2_ZANI_N3_R2_EA_TO_PHOEBE = 'P2_ZANI_N3_R2_EA_TO_PHOEBE'

    STEP_RECOVER_ZANI_LIBERATION = 'RECOVER_ZANI_LIBERATION'
    STEP_RECOVER_P2_PHOEBE = 'RECOVER_P2_PHOEBE'

    STEP_ACTOR = {
        STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER: 'Phoebe',
        STEP_P1_ZANI_OPEN_EA_TO_PHOEBE: 'Zani',
        STEP_P1_ROVER_EQR_TO_ZANI: 'Rover',
        STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI: 'Phoebe',
        STEP_P1_ZANI_PRE_R_PREP_SLICE: 'Zani',

        STEP_P1_ZANI_EFORTE_PREP: 'Zani',
        STEP_P1_ZANI_R1_N1_TO_ROVER: 'Zani',
        STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE: 'Rover',
        STEP_P1_PHOEBE_STAR_E1_TO_ZANI: 'Phoebe',
        STEP_P1_ZANI_N2_TO_ROVER_R: 'Zani',
        STEP_P1_ROVER_R_TO_ZANI: 'Rover',
        STEP_P1_ZANI_N3_TO_PHOEBE: 'Zani',
        STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI: 'Phoebe',
        STEP_P1_ZANI_N4_R2_EA_TO_PHOEBE: 'Zani',

        STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI: 'Phoebe',
        STEP_P2_ZANI_PRE_R_PREP_SLICE: 'Zani',
        STEP_P2_ZANI_EFORTE_PREP: 'Zani',
        STEP_P2_ZANI_R1_N1_TO_ROVER: 'Zani',
        STEP_P2_ROVER_SLOT_TO_ZANI: 'Rover',
        STEP_P2_ZANI_N2_TO_PHOEBE: 'Zani',
        STEP_P2_PHOEBE_CONFESSION_CHECK: 'Phoebe',
        STEP_P2_ROVER_AZ_WAIT_CONFESSION: 'Rover',
        STEP_P2_PHOEBE_CONFESSION_R_TO_ZANI: 'Phoebe',
        STEP_P2_ZANI_N3_R2_EA_TO_PHOEBE: 'Zani',

        STEP_RECOVER_ZANI_LIBERATION: 'Zani',
        STEP_RECOVER_P2_PHOEBE: 'Phoebe',
    }

    SPECIAL_INTRO_TARGET = {
        'Phoebe': 'Zani',
        'Zani': 'Rover',
        'Rover': 'Phoebe',
    }

    CONCERTO_EFFECTIVE_FULL = 0.99
    INTRO_CONFIRM_FRAMES = 3
    INTRO_CONFIRM_TIMEOUT = 1.0
    POLL = 0.05

    SWITCH_TIMEOUT = 6.0
    SWITCH_RETRY_INTERVAL = 0.04

    def _release_phoebe_prehold(self, state, reason='cleanup'):
        if not isinstance(state, dict) or not state.get(self.PHOEBE_PREHOLD_E_KEY):
            return False
        try:
            self.task.send_key_up(self.get_resonance_key())
        except Exception:
            pass
        source = state.pop(self.PHOEBE_PREHOLD_SOURCE_KEY, None)
        state.pop(self.PHOEBE_PREHOLD_E_KEY, None)
        self.logger.info(
            f'ZFG Phoebe-E prehold RELEASE reason={reason} source={source}'
        )
        return True

    def _reedge_phoebe_prehold_on_entry(self, target_name, has_intro=False):
        """V4.3: Phoebe预输入E在切人确认首帧做一次UP->DOWN重新沿触发。

        赞妮侧的跨角色key_down负责把E提前送进输入队列；但部分实机会在角色切换期间
        吞掉持续按键的首个触发。确认current_index已经变成Phoebe后，立刻重建一次
        按键边沿，让告解长按尽可能从菲比登场首帧开始。特殊变奏入场不做此操作。
        """
        if target_name != 'Phoebe' or has_intro:
            return False

        state = getattr(self.task, self.STATE_KEY, None)
        if not isinstance(state, dict) or not state.get(self.PHOEBE_PREHOLD_E_KEY):
            return False

        try:
            key = self.get_resonance_key()
            self.task.send_key_up(key)
            self.task.send_key_down(key)
            self.logger.info(
                f'ZFG V4.6 Phoebe-E PREHOLD re-edge on entry source='
                f'{state.get(self.PHOEBE_PREHOLD_SOURCE_KEY)}'
            )
            return True
        except Exception as exc:
            self.logger.warning(
                f'ZFG V4.6 Phoebe-E PREHOLD re-edge failed: {exc}'
            )
            return False

    def _clear_zfg_state(self):
        state = getattr(self.task, self.STATE_KEY, None)
        self._release_phoebe_prehold(state, reason='clear-zfg-state')
        for key in (self.STATE_KEY, self.SWITCH_LOG_KEY):
            if hasattr(self.task, key):
                delattr(self.task, key)

    def _zfg_team_matches(self):
        chars = getattr(self.task, 'chars', None)
        if not isinstance(chars, (list, tuple)):
            return False

        chars = tuple(char for char in chars if char is not None)

        signature = tuple(
            (
                str(getattr(char, 'char_name', '') or '')
                .casefold()
                .removeprefix('labels.'),
                getattr(char, 'index', None),
            )
            for char in chars
        )

        required = {
            'char_zani',
            'char_phoebe',
            'char_rover',
        }

        identity_ok = (
            len(chars) == 3
            and {name for name, _ in signature} == required
            and any(char is self for char in chars)
        )

        rover = None
        for char in chars:
            name = (
                str(getattr(char, 'char_name', '') or '')
                .casefold()
                .removeprefix('labels.')
            )
            if name == 'char_rover':
                rover = char
                break

        rover_form = -1
        if rover is not None:
            try:
                if hasattr(self.task, 'get_known_ring_index'):
                    rover_form = self.task.get_known_ring_index(rover)
                else:
                    rover_form = getattr(rover, 'ring_index', -1)
            except Exception:
                rover_form = getattr(rover, 'ring_index', -1)

        form_ok = rover_form < 0 or rover_form == Elements.SPECTRO
        matched = identity_ok and form_ok

        previous = getattr(self.task, self.TEAM_SIGNATURE_KEY, None)

        if signature != previous:
            self._clear_zfg_state()
            setattr(self.task, self.TEAM_SIGNATURE_KEY, signature)
            self.logger.info(
                f'ZFG team changed matched={matched} '
                f'rover_form={rover_form} members={signature}'
            )
        elif not matched:
            self._clear_zfg_state()

        return matched

    def _zfg_state(self):
        """Return shared FSM state.

        First creation starts from P1.  If an already-existing state is damaged,
        do not replay the one-time opening: route to the agreed recovery entry.
        """
        state = getattr(self.task, self.STATE_KEY, None)

        if state is None:
            state = {
                'step': self.STEP_P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER,
                'cycle': 1,
                'nightfall_count': 0,
            }
            setattr(self.task, self.STATE_KEY, state)
            self.logger.info(
                'ZFG FSM initialize -> P1_PHOEBE_CONFESSION_R_EQ_TO_ROVER'
            )
            return state

        if not isinstance(state, dict) or 'step' not in state:
            old_cycle = state.get('cycle', 1) if isinstance(state, dict) else 1
            state = {
                'cycle': old_cycle,
                'nightfall_count': 0,
            }
            setattr(self.task, self.STATE_KEY, state)
            self._route_broken_state_to_recovery(
                state,
                reason='state-missing-step',
            )

        return state


    def _advance_step(self, state, next_step):
        old = state.get('step')
        state['step'] = next_step
        state.pop('phase', None)
        state.pop('phase_started_at', None)

        self.logger.info(
            f'ZFG FSM advance {old} -> {next_step} '
            f'cycle={state.get("cycle", 1)} '
            f'nightfall={state.get("nightfall_count", 0)}'
        )

    def _expected_actor(self, state):
        if state.get('detour_active'):
            return state.get('detour_actor')
        return self.STEP_ACTOR.get(state.get('step'))

    def _route_broken_state_to_recovery(self, state, reason='unknown'):
        """Route a damaged FSM without replaying the one-time P1 opening.

        - Zani still in R state -> RECOVER_ZANI_LIBERATION.
        - Otherwise -> RECOVER_P2_PHOEBE.
        """
        if not isinstance(state, dict):
            return 'Phoebe'

        self._clear_detour(state)
        state.pop('phase', None)
        state.pop('phase_started_at', None)

        zani = self if self.ACTOR == 'Zani' else self._find_target_char('Zani')
        if zani is not None and getattr(zani, 'in_liberation', False):
            state['step'] = self.STEP_RECOVER_ZANI_LIBERATION
            actor = 'Zani'
        else:
            state['step'] = self.STEP_RECOVER_P2_PHOEBE
            actor = 'Phoebe'

        self.logger.error(
            f'ZFG broken FSM recovery reason={reason} '
            f'-> step={state.get("step")} actor={actor}'
        )
        return actor

    def get_switch_priority(
        self,
        current_char=None,
        has_intro=False,
        target_low_con=False,
    ):
        if not self._zfg_team_matches():
            return super().get_switch_priority(
                current_char,
                has_intro,
                target_low_con,
            )

        state = self._zfg_state()
        expected = self._expected_actor(state)

        if expected is None:
            expected = self._route_broken_state_to_recovery(
                state,
                reason=f'unknown-step:{state.get("step")}',
            )

        if not getattr(self.task, self.SWITCH_LOG_KEY, False):
            self.logger.info(
                f'ZFG FSM-exclusive switching enabled '
                f'step={state.get("step")} expected={expected}'
            )
            setattr(self.task, self.SWITCH_LOG_KEY, True)

        return (
            SwitchPriority.MUST
            if expected == self.ACTOR
            else SwitchPriority.NO
        )

    def _find_target_char(self, target_name):
        target_name = target_name.casefold()

        for char in getattr(self.task, 'chars', []):
            if char is None or char is self:
                continue

            names = (
                getattr(char, 'name', None),
                char.__class__.__name__,
                getattr(char, 'display_name', None),
            )

            for name in names:
                if name and str(name).casefold() == target_name:
                    return char

        return None

    def _raw_con_full(self):
        try:
            return bool(self.task.is_con_full())
        except Exception:
            return bool(self.is_con_full())

    def _read_concerto(self):
        if self._raw_con_full():
            return 1.0

        try:
            value = float(self.get_current_con())
        except Exception:
            try:
                value = float(self.task.get_current_con())
            except Exception:
                value = 0.0

        return max(0.0, min(1.0, value))

    def _concerto_effectively_full(self):
        return (
            self._raw_con_full()
            or self._read_concerto() >= self.CONCERTO_EFFECTIVE_FULL
        )

    def _confirm_hard_intro_ready(self, target_name):
        start = time.time()
        full_frames = 0

        while time.time() - start < self.INTRO_CONFIRM_TIMEOUT:
            if self._raw_con_full():
                full_frames += 1

                if full_frames >= self.INTRO_CONFIRM_FRAMES:
                    self.logger.info(
                        f'ZFG hard-intro guard passed '
                        f'{self.ACTOR}->{target_name} '
                        f'{full_frames}/{self.INTRO_CONFIRM_FRAMES}'
                    )
                    return True
            else:
                full_frames = 0

            self.sleep(self.POLL)
            self.task.next_frame()

        self.logger.warning(
            f'ZFG hard-intro guard failed '
            f'{self.ACTOR}->{target_name}'
        )
        return False

    def _switch_to(self, target_name, expect_intro=None):
        target = self._find_target_char(target_name)

        if target is None:
            self.logger.error(
                f'ZFG {self.ACTOR}: target not found -> {target_name}'
            )
            return False

        if expect_intro is True:
            allowed = self.SPECIAL_INTRO_TARGET.get(self.ACTOR)

            if target_name != allowed:
                self.logger.error(
                    f'ZFG invalid special intro '
                    f'{self.ACTOR}->{target_name}; '
                    f'allowed={allowed}'
                )
                return False

            if not self._confirm_hard_intro_ready(target_name):
                return False

            has_intro = True

        elif expect_intro is False:
            if self._concerto_effectively_full():
                self.logger.warning(
                    f'ZFG block forced-normal switch '
                    f'{self.ACTOR}->{target_name}: concerto full'
                )
                return False
            has_intro = False

        else:
            has_intro = self._concerto_effectively_full()

        target.has_intro = has_intro
        target.has_sub_dps_intro = (
            has_intro and getattr(self, 'is_sub_dps', False)
        )

        start = time.time()
        last_send = 0.0

        while time.time() - start < self.SWITCH_TIMEOUT:
            self.check_combat()

            try:
                in_team, current_index, _ = self.task.in_team()
            except Exception:
                in_team, current_index = False, -1

            if in_team and current_index == target.index:
                # V4.3: 若此前已经跨角色预按菲比E，在确认菲比成为当前角色的首帧
                # 立即做一次UP->DOWN re-edge，再进入常规切人bookkeeping。
                self._reedge_phoebe_prehold_on_entry(target_name, has_intro)

                self.task.in_liberation = False
                target.is_current_char = True

                self.switch_out(con_full=has_intro)
                target.last_switch_in_time = time.time()

                if has_intro:
                    now = time.time()
                    self.add_freeze_duration(
                        now,
                        target.intro_motion_freeze_duration,
                        -100,
                    )
                    self.last_outro_time = now

                self.logger.info(
                    f'ZFG exact switch success '
                    f'{self.ACTOR}->{target_name} '
                    f'intro={has_intro}'
                )
                return True

            if (
                in_team
                and current_index == self.index
                and not target.wait_switch()
            ):
                now = time.time()

                if now - last_send >= self.SWITCH_RETRY_INTERVAL:
                    self.task.send_key(target.index + 1)
                    last_send = now

            self.sleep(self.SWITCH_RETRY_INTERVAL)
            self.task.next_frame()

        self.logger.error(
            f'ZFG exact switch timeout '
            f'{self.ACTOR}->{target_name}'
        )
        return False

    def _clear_detour(self, state):
        for key in (
            'detour_active',
            'detour_actor',
            'detour_final_target',
            'detour_next_step',
            'detour_next_phase',
            'detour_resume_step',
            'detour_resume_phase',
        ):
            state.pop(key, None)

    def _switch_route(
        self,
        state,
        planned_target,
        next_step,
        force_intro=False,
    ):
        """
        正常切人入口。

        若协奏满，但planned_target不是当前角色正确的特殊变奏目标：
        保存主轴step/phase -> 先让正确角色吃特殊变奏
        -> 再自然切planned_target -> 进入next_step。
        """

        if force_intro:
            if self._switch_to(planned_target, expect_intro=True):
                self._advance_step(state, next_step)
                return True
            return False

        full = self._concerto_effectively_full()
        special_target = self.SPECIAL_INTRO_TARGET.get(self.ACTOR)

        if (
            full
            and special_target
            and planned_target != special_target
        ):
            if planned_target == 'Phoebe' and state.get(self.PHOEBE_PREHOLD_E_KEY):
                self.logger.info(
                    f'ZFG Phoebe-E prehold PRESERVE across detour '
                    f'{self.ACTOR}->{special_target}->Phoebe'
                )
            resume_step = state.get('step')
            resume_phase = state.get('phase')

            self.logger.warning(
                f'ZFG intro detour required: '
                f'source={self.ACTOR} '
                f'planned={planned_target} '
                f'correct_intro={special_target} '
                f'resume={resume_step}/{resume_phase}'
            )

            if not self._switch_to(
                special_target,
                expect_intro=None,
            ):
                return False

            state['detour_active'] = True
            state['detour_actor'] = special_target
            state['detour_final_target'] = planned_target
            state['detour_next_step'] = next_step
            state['detour_resume_step'] = resume_step
            state['detour_resume_phase'] = resume_phase
            return True

        if self._switch_to(planned_target, expect_intro=None):
            self._advance_step(state, next_step)
            return True

        return False

    def _run_detour_if_needed(self, state):
        if not state.get('detour_active'):
            return False

        expected = state.get('detour_actor')

        if expected != self.ACTOR:
            self._recover_wrong_actor(state)
            return True

        final_target = state.get('detour_final_target')
        next_step = state.get('detour_next_step')
        next_phase = state.get('detour_next_phase')
        resume_step = state.get('detour_resume_step')
        resume_phase = state.get('detour_resume_phase')

        self.logger.info(
            f'ZFG detour actor={self.ACTOR} '
            f'return={final_target} '
            f'resume={resume_step}/{resume_phase}'
        )

        if self._switch_to(final_target, expect_intro=None):
            self._clear_detour(state)
            self._advance_step(state, next_step)
            if next_phase is not None:
                state['phase'] = next_phase
                self.logger.info(
                    f'ZFG V4.6 detour resume phase restored -> {next_step}/{next_phase}'
                )

        return True

    def _recover_wrong_actor(self, state):
        expected = self._expected_actor(state)

        if expected and expected != self.ACTOR:
            self.logger.warning(
                f'ZFG wrong actor: current={self.ACTOR} '
                f'step={state.get("step")} expected={expected}'
            )
            return self._switch_to(
                expected,
                expect_intro=None,
            )

        recovery_actor = self._route_broken_state_to_recovery(
            state,
            reason=f'unhandled-step:{state.get("step")}',
        )

        if recovery_actor != self.ACTOR:
            return self._switch_to(
                recovery_actor,
                expect_intro=None,
            )

        return False


    def on_combat_end(self, chars):
        self._clear_zfg_state()

        if hasattr(self.task, self.TEAM_SIGNATURE_KEY):
            delattr(self.task, self.TEAM_SIGNATURE_KEY)

        return None


class Zani(_ZFGFSM, BuiltinZani):
    ACTOR = 'Zani'

    # =========================================================
    # Zani role-local frozen helpers
    # =========================================================
    def _start_liberation(self):
        """R1确认后的本地状态武装；不依赖已从新版上游消失的私有helper。"""
        now = time.time()
        self.in_liberation = True
        self.liberation_time = now
        self.last_liberation = now
        self.nightfall_time = -1
        self.state = 1
        return True

    def liberation_time_left(self):
        if not self.in_liberation or getattr(self, 'liberation_time', 0) <= 0:
            return 0
        return 20 - self.time_elapsed_accounting_for_freeze(self.liberation_time)

    def nightfall_time_left(self):
        if getattr(self, 'nightfall_time', -1) <= 0:
            return 0
        return 2.2 - self.time_elapsed_accounting_for_freeze(
            self.nightfall_time, intro_motion_freeze=True
        )

    def check_liber(self):
        if not self.task.in_team_and_world():
            return bool(self.in_liberation)
        not_liber_box = self.task.box_of_screen_scaled(
            2560, 1440, 1909, 1274, 1957, 1322,
            name='zfg_zani_not_liber_box', hcenter=True,
        )
        liber_box = self.task.box_of_screen_scaled(
            2560, 1440, 1779, 1273, 1830, 1322,
            name='zfg_zani_liber_box', hcenter=True,
        )
        if self.task.find_one('box_target_enemy_inner', box=not_liber_box, threshold=0.75):
            self.in_liberation = False
        elif self.task.find_one('box_target_enemy_inner', box=liber_box, threshold=0.75):
            self.in_liberation = True
        return bool(self.in_liberation)


    ZFG_ZANI_LIGHT_COLOR = {
        'r': (245, 255), 'g': (245, 255), 'b': (205, 225),
    }

    def _zfg_color_percentage_in_ring(self, target_color, box, r1_ratio=0.0, r2_ratio=0.0):
        cropped = box.crop_frame(self.task.frame)
        if cropped is None or getattr(cropped, 'size', 0) == 0:
            return 0.0
        h, w = cropped.shape[:2]
        r1 = int(math.floor(h * r1_ratio))
        r2 = int(math.ceil(h * r2_ratio))
        if r2 <= r1:
            return 0.0
        center = (w // 2, h // 2)
        ring_mask = np.zeros((h, w), dtype=np.uint8)
        cv2.circle(ring_mask, center, r2, 255, -1)
        if r1 > 0:
            cv2.circle(ring_mask, center, r1, 0, -1)
        lower, upper = color_range_to_bound(target_color)
        color_mask = cv2.inRange(cropped, lower, upper)
        combined = cv2.bitwise_and(color_mask, ring_mask)
        total = cv2.countNonZero(ring_mask)
        return 0.0 if total <= 0 else cv2.countNonZero(combined) / float(total)

    def is_nightfall_ready(self, threshold=0.15):
        """冻结终夜图标识别；直接读固定ROI。"""
        box = self.task.box_of_screen_scaled(
            2560, 1440, 1853, 1233, 1964, 1344,
            name='zfg_zani_nightfall', hcenter=True,
        )
        try:
            self.task.draw_boxes(box.name, box)
        except Exception:
            pass
        light = self._zfg_color_percentage_in_ring(
            self.ZFG_ZANI_LIGHT_COLOR, box, 0.425, 0.490
        )
        return light > threshold

    def crisis_time_left(self):
        crisis = float(getattr(self, 'crisis_time', -1) or -1)
        if crisis <= 0:
            return 0.0
        return 1.6 - self.time_elapsed_accounting_for_freeze(
            crisis, intro_motion_freeze=True
        )

    def wait_crisis_protocol_end(self):
        """冻结强化E动作/Buff建立窗口；只依赖本地crisis_time与frame循环。"""
        if self.crisis_time_left() <= 0:
            return True
        start = time.time()
        while self.crisis_time_left() > 0 and time.time() - start < 2.0:
            self.task.next_frame()
            self.sleep(0.03)
        return self.crisis_time_left() <= 0

    def should_end_liberation(self, time_only=False, force_finish=False):
        """固定轴只需要时间门和恢复强制结束；不再依赖官方Zani helper签名。"""
        if force_finish:
            return True
        if self.liberation_time_left() < 1.7:
            return True
        if time_only:
            return False
        if self.is_nightfall_ready():
            return False
        return not self.is_mouse_forte_full()

    def click_liber2(self):
        """冻结赞妮R2提交；保留原本目标UI位置与时停记账。"""
        start = time.time()
        self.task.in_liberation = True
        send_key = True
        not_liber_box = self.task.box_of_screen_scaled(
            2560, 1440, 1909, 1274, 1957, 1322,
            name='zfg_zani_not_liber_box', hcenter=True,
        )
        while not self.task.find_one(
            'box_target_enemy_inner', box=not_liber_box, threshold=0.75
        ):
            if time.time() - start > 6:
                self.task.in_liberation = False
                self.check_liber()
                return False
            if self.current_resonance() == 0:
                start = time.time()
            elif time.time() - start > 1.5:
                send_key = False
            if send_key:
                self.send_liberation_key()
            self.task.next_frame()
        self.task.in_liberation = False
        current = time.time()
        duration = 2.25
        if current - start >= duration:
            self.last_liber2 = current
            self.add_freeze_duration(current - duration, duration, 0)
        self.in_liberation = False
        self.blazes = -1
        self.liberation_time = -1
        self.state = 0
        return True


    OPEN_E_TO_A_GAP = 0.07  # V4.3：E消费确认不等于A输入窗已开放；给约70ms进入可接受A的动作窗口
    OPEN_A_COMMIT_GAP = 0.18  # V4.3：A发出后给约180ms独占提交窗，再切光主，避免A派生链尚未建立就被换人吞掉

    ENHANCED_E_PREP_TIMEOUT = 7.0
    ENHANCED_E_CONFIRM_TIMEOUT = 1.50
    ENHANCED_E_CLEAR_STABLE_SECONDS = 0.35
    ENHANCED_E_AMBIGUOUS_SETTLE_TIMEOUT = 0.70

    EFORTE_NORMAL_E_LAST_CAST_KEY = 'zani_eforte_normal_e_last_cast'
    EFORTE_NORMAL_E_CASTS_KEY = 'zani_eforte_normal_e_casts'
    EFORTE_ENHANCED_READY_SEEN_KEY = 'zani_eforte_enhanced_ready_seen'
    EFORTE_COMMIT_LOCK_KEY = 'zani_eforte_commit_lock'
    EFORTE_FIRST_INPUT_TIME_KEY = 'zani_eforte_first_input_time'
    EFORTE_COMMIT_ATTEMPTS_KEY = 'zani_eforte_commit_attempts'

    NORMAL_E_REAL_CD = 5.0
    NORMAL_E_RECAST_MIN_ELAPSED = 4.80
    NORMAL_E_ATTACK_INTERVAL = 0.08
    NORMAL_E_POST_CAST_SETTLE = 0.08
    NORMAL_E_CONFIRM_TIMEOUT = 0.45
    NORMAL_E_CLEAR_CONFIRM_FRAMES = 2

    LIBERATION_READY_TIMEOUT = 2.5  # R1等待上限；失败不推进phase
    POST_R2_E_TIMEOUT = 2.5         # R2后普通E的硬等待上限
    POST_R2_E_TO_A_GAP = OPEN_E_TO_A_GAP  # V4.3: 与开场EA完全一致
    POST_R2_A_COMMIT_GAP = OPEN_A_COMMIT_GAP

    # V4.3 P1/P2：第一次Z后的赞妮quick-swap均以“尽量真正打出特殊E”为正常离场门。
    # hard-cap只防异常；使用freeze-aware有效时间，脚本F造成的时停不消耗保护窗。
    P1_PRE_R_PRECAST_HARD_CAP = 11.00
    P1_PRE_R_PRECAST_ATTACK_INTERVAL = 0.08
    P1_PRE_R_PRECAST_E_CONFIRM_TIMEOUT = 1.80
    P1_PRE_R_PRECAST_E_RETRY_INTERVAL = 0.06
    P1_PRE_R_PRECAST_E_CLEAR_STABLE_SECONDS = 0.20  # 主真值：特殊E资源图标持续消失才算已消费
    P1_PRE_R_PRECAST_E_FINAL_COMMIT_GRACE = 1.80     # hard-cap时若特殊E已READY，再给一次强提交窗口
    P2_PRE_R_PRECAST_ACTIVE_BUDGET = 4.00             # P2 Z1只做中段推进；到点未READY就带着资源回菲比打Z2


    # 赞妮特殊E成功后的14s专属Buff：只在赞妮登场时显示。
    # ROI来自用户提供的1600x900实机截图，使用2560x1440基准坐标缩放。
    SPECIAL_E_BUFF_BOX = (1220, 1200, 1305, 1265)
    SPECIAL_E_BUFF_OLIVE_COLOR = {
        'r': (120, 215),
        'g': (115, 210),
        'b': (45, 145),
    }
    SPECIAL_E_BUFF_WHITE_COLOR = {
        'r': (175, 255),
        'g': (175, 255),
        'b': (150, 255),
    }
    SPECIAL_E_BUFF_MIN_OLIVE_RATIO = 0.060
    SPECIAL_E_BUFF_MIN_COMPONENT_RATIO = 0.035
    SPECIAL_E_BUFF_MIN_CENTER_WHITE_RATIO = 0.180
    SPECIAL_E_BUFF_SLOT_MIN_BRIGHT_RATIO = 0.055
    SPECIAL_E_BUFF_SLOT_MIN_CONTENT_RATIO = 0.120
    SPECIAL_E_BUFF_SLOT_MIN_COMPONENT_RATIO = 0.020
    SPECIAL_E_BUFF_SLOT_MIN_EDGE_RATIO = 0.040

    P1_N1_FORWARD_A_PENDING_KEY = 'p1_n1_forward_a_pending'
    P1_N1_FORWARD_HOLD = 0.20

    N1_ICON_ACQUIRE_TIMEOUT = 3.5
    NIGHTFALL_COMMIT_MIN_AFTER_TRIGGER = 0.25
    NIGHTFALL_COMMIT_TIMEOUT = 1.25
    # V4.3主判据：终夜触发后E图标由亮变灰。Builtin Zani也以current_resonance白色比例判E亮度。
    NIGHTFALL_E_BRIGHT_MIN = 0.050
    NIGHTFALL_E_GRAY_ABS_MAX = 0.030
    NIGHTFALL_E_GRAY_RELATIVE = 0.50
    NIGHTFALL_E_GRAY_CONFIRM_FRAMES = 2
    # 旧available下降沿保留为诊断/次级证据，不再作为最快主判据。
    NIGHTFALL_E_FALL_CONFIRM_FRAMES = 2
    NIGHTFALL_ICON_CLEAR_CONFIRM_FRAMES = 4
    NIGHTFALL_ICON_AUX_MIN_AFTER_TRIGGER = 0.35
    NIGHTFALL_TIME_AUX_AFTER_TRIGGER = 0.95
    LIBER_ECHO_WATCH_INTERVAL = 0.10
    LIBER_ECHO_DEADLINE_GUARD = 0.35
    NIGHTFALL_COMMIT_CTX_KEY = 'zani_nightfall_commit_ctx'

    F_CHECK_INTERVAL = 0.20
    F_POST_ACTION_SETTLE_TIME = 0.12

    FINAL_N_ICON_TIMEOUT = 3.0
    R2_HARD_DEADLINE = 19.50  # 从R1确认时刻计时；给20s形态尾端留0.5s输入安全余量
    FINAL_N_SMASH_DONE_LEFT = 0.08
    P1_FINAL_N_DAMAGE_SETTLE = 0.50  # V4.3 rev1: P1 N4最终伤害落地保护请求值；实际受19.90s安全上限裁剪
    P2_FINAL_N_DAMAGE_SETTLE = 0.50  # V4.3 rev1: P2 N3完整下砸后固定追加的伤害落地有效时间
    P1_R2_SAFE_LATEST = 19.90        # V4.3 rev1: P1动态落地保护最晚只拖到R1后19.90s，避免顶到20s形态边界

    NIGHTFALL_DONE = 'DONE'
    NIGHTFALL_FAILED = 'FAILED'
    NIGHTFALL_LIBERATION_ENDED = 'LIBERATION_ENDED'
    NIGHTFALL_R2_TRIGGERED = 'R2_TRIGGERED'
    NIGHTFALL_R2_DEADLINE = 'R2_DEADLINE'

    def _clear_pre_r_prep_markers(self, state):
        for key in (
            self.ZANI_PRE_R_PREP_SLICE_DONE_KEY,
            self.ZANI_PRE_R_EFORTE_READY_KEY,
            self.ZANI_PRE_R_RETURN_STEP_KEY,
            self.ZANI_PRE_R_RETURN_PHASE_KEY,
            self.ZANI_PRE_R_PREP_SOURCE_KEY,
            self.ZANI_PRE_R_PRECAST_E_ATTEMPTED_KEY,
            self.ZANI_PRE_R_PRECAST_E_CONSUMED_KEY,
            self.ZANI_PRE_R_PRECAST_NORMAL_E_LAST_CAST_KEY,
            self.ZANI_PRE_R_PRECAST_NORMAL_E_CASTS_KEY,
        ):
            state.pop(key, None)

    def _complete_pre_r_return_to_phoebe(self, state, target, tag, elapsed):
        """检测到已切回菲比后，补齐与_switch_to一致的角色状态bookkeeping。"""
        self.task.in_liberation = False
        target.is_current_char = True
        self.switch_out(con_full=False)
        target.last_switch_in_time = time.time()

        return_step = state.get(self.ZANI_PRE_R_RETURN_STEP_KEY)
        return_phase = state.get(self.ZANI_PRE_R_RETURN_PHASE_KEY)
        if not return_step or not return_phase:
            self.logger.error(
                f'ZFG V4.6 {tag}: missing return route after prep slice; '
                'route to recovery instead of guessing'
            )
            self._route_broken_state_to_recovery(
                state,
                reason=f'{tag}-missing-prep-return',
            )
            return False

        state[self.ZANI_PRE_R_PREP_SLICE_DONE_KEY] = True
        state['step'] = return_step
        state['phase'] = return_phase
        state.pop(self.ZANI_PRE_R_RETURN_STEP_KEY, None)
        state.pop(self.ZANI_PRE_R_RETURN_PHASE_KEY, None)
        state.pop(self.ZANI_PRE_R_PREP_SOURCE_KEY, None)

        self.logger.info(
            f'ZFG V4.6 {tag}: PREP_SLICE RETURN Phoebe success '
            f'elapsed={elapsed:.3f}s '
            f'enhanced_ready_seen={bool(state.get(self.ZANI_PRE_R_EFORTE_READY_KEY, False))} '
            f'-> resume={return_step}/{return_phase}'
        )
        return True

    def _finish_pre_r_return_after_switch(self, state, tag, elapsed, reason):
        """_switch_to(Phoebe)成功后的FSM续接；只改route，不重复角色bookkeeping。"""
        return_step = state.get(self.ZANI_PRE_R_RETURN_STEP_KEY)
        return_phase = state.get(self.ZANI_PRE_R_RETURN_PHASE_KEY)
        if not return_step or not return_phase:
            self.logger.error(
                f'ZFG V4.6 {tag}: missing return route after {reason}; '
                'route to recovery instead of guessing'
            )
            self._route_broken_state_to_recovery(
                state,
                reason=f'{tag}-missing-prep-return-{reason}',
            )
            return False

        state[self.ZANI_PRE_R_PREP_SLICE_DONE_KEY] = True
        state['step'] = return_step
        state['phase'] = return_phase
        state.pop(self.ZANI_PRE_R_RETURN_STEP_KEY, None)
        state.pop(self.ZANI_PRE_R_RETURN_PHASE_KEY, None)
        state.pop(self.ZANI_PRE_R_PREP_SOURCE_KEY, None)
        self.logger.info(
            f'ZFG V4.6 {tag}: return Phoebe success reason={reason} '
            f'elapsed={elapsed:.3f}s '
            f'normal_e_casts={state.get(self.ZANI_PRE_R_PRECAST_NORMAL_E_CASTS_KEY, 0)} '
            f'special_e_attempted={bool(state.get(self.ZANI_PRE_R_PRECAST_E_ATTEMPTED_KEY, False))} '
            f'special_e_consumed={bool(state.get(self.ZANI_PRE_R_PRECAST_E_CONSUMED_KEY, False))} '
            f'-> resume={return_step}/{return_phase}'
        )
        return True

    def _mark_pre_r_special_e_consumed(self, state, tag, first_send_time, reason, clear_for=0.0):
        """记录第一次Z后quick-swap的强化E已确认释放；只服务PRECAST阶段。"""
        state[self.ZANI_PRE_R_PRECAST_E_CONSUMED_KEY] = True
        state[self.ZANI_PRE_R_EFORTE_READY_KEY] = False
        try:
            self.record_resonance_use()
        except Exception:
            pass
        now = time.time()
        self.crisis_time = first_send_time if first_send_time is not None else now
        self.logger.info(
            f'ZFG V4.6 {tag}: pre-cast special E CONSUMED CONFIRMED '
            f'via={reason} clear_stable={clear_for:.3f}s; '
            'PRECAST release-confirm passed -> allow return Phoebe'
        )
        return True

    def _cast_pre_r_enhanced_e_quick(self, state, tag, timeout=None):
        """P1/P2 quick-swap中的特殊E强提交。

        V4.4仅修改第一次Z后的PRECAST确认：特殊E已实际发送(sent=True)后，
        READY稳定消失或特殊E专属Buff连续两帧识别成功，任一条件成功都记为 consumed=True。
        后续P1/P2 EFORTE_PREP与R1流程保持V4.3_rev1原样。
        """
        if not self.is_e_forte_full():
            return False

        state[self.ZANI_PRE_R_PRECAST_E_ATTEMPTED_KEY] = True
        confirm_timeout = (
            self.P1_PRE_R_PRECAST_E_CONFIRM_TIMEOUT
            if timeout is None else max(0.1, float(timeout))
        )
        start = time.time()
        last_send = -100.0
        sent = False
        first_send_time = None
        clear_since = None
        buff_visible_frames = 0

        while time.time() - start < confirm_timeout:
            self.task.next_frame()
            now = time.time()
            forte_now = bool(self.is_e_forte_full())

            if forte_now:
                clear_since = None
                if now - last_send >= self.P1_PRE_R_PRECAST_E_RETRY_INTERVAL:
                    self.send_resonance_key()
                    last_send = now
                    if not sent:
                        sent = True
                        first_send_time = now
                        self.logger.info(
                            f'ZFG V4.6 {tag}: pre-cast special E COMMIT START; '
                            f'confirm_timeout={confirm_timeout:.2f}s; '
                            'keep E priority until consumption is confirmed'
                        )
            elif sent:
                if clear_since is None:
                    clear_since = now
                    self.logger.info(
                        f'ZFG V4.6 {tag}: pre-cast special E READY disappeared; '
                        'start stable-consume confirmation'
                    )
                clear_for = now - clear_since
                if clear_for >= self.P1_PRE_R_PRECAST_E_CLEAR_STABLE_SECONDS:
                    return self._mark_pre_r_special_e_consumed(
                        state,
                        tag,
                        first_send_time,
                        reason='FORTE_STABLE_CLEAR',
                        clear_for=clear_for,
                    )

            # V4.4 PRECAST辅助判据：只有强化E已实际发送后，专属14s Buff连续两张新画面命中才确认释放。
            if sent:
                if self._zani_special_e_buff_visible(log=False):
                    buff_visible_frames += 1
                    if buff_visible_frames >= 2:
                        return self._mark_pre_r_special_e_consumed(
                            state,
                            tag,
                            first_send_time,
                            reason='SPECIAL_E_BUFF_VISIBLE_2F',
                            clear_for=0.0,
                        )
                else:
                    buff_visible_frames = 0

            self.sleep(self.POLL)

        # 超时后再做一个非常短的尾帧复核，防止刚好在窗口边界完成消费。
        tail_start = time.time()
        tail_clear_since = None
        while time.time() - tail_start < self.P1_PRE_R_PRECAST_E_CLEAR_STABLE_SECONDS + 0.08:
            self.task.next_frame()
            now = time.time()
            # 尾帧复核沿用同一规则：sent=True后，专属14s Buff连续两帧命中也可确认本次PRECAST强化E。
            if sent:
                if self._zani_special_e_buff_visible(log=False):
                    buff_visible_frames += 1
                    if buff_visible_frames >= 2:
                        return self._mark_pre_r_special_e_consumed(
                            state,
                            tag,
                            first_send_time,
                            reason='SPECIAL_E_BUFF_VISIBLE_2F',
                            clear_for=0.0,
                        )
                else:
                    buff_visible_frames = 0
            if self.is_e_forte_full():
                tail_clear_since = None
                break
            if sent:
                if tail_clear_since is None:
                    tail_clear_since = now
                clear_for = now - tail_clear_since
                if clear_for >= self.P1_PRE_R_PRECAST_E_CLEAR_STABLE_SECONDS:
                    return self._mark_pre_r_special_e_consumed(
                        state,
                        tag,
                        first_send_time,
                        reason='FORTE_DELAYED_STABLE_CLEAR',
                        clear_for=clear_for,
                    )
            self.sleep(self.POLL)

        self.logger.warning(
            f'ZFG V4.6 {tag}: pre-cast special E consumption NOT confirmed '
            f'within {confirm_timeout:.2f}s; READY-clear and PRECAST Buff both unconfirmed; '
            'keep consumed=False and preserve original downstream EFORTE behavior'
        )
        return False

    def _p1_precast_active_elapsed(self, start):
        """P1 PRECAST的有效执行时间：扣除框架登记的F/卡肉freeze。"""
        try:
            return max(0.0, float(self.time_elapsed_accounting_for_freeze(start)))
        except Exception:
            return max(0.0, time.time() - start)

    def _return_pre_r_to_phoebe(self, state, tag, elapsed, reason, allow_intro_detour=False):
        """PRECAST离场统一入口。

        P1仍坚持普通切菲比；P2若赞妮协奏已满，则不能再被expect_intro=False卡死，
        改走“正确特殊变奏目标 -> 菲比”的共享detour，并恢复原return_step/return_phase。
        """
        if not allow_intro_detour:
            if self._switch_to('Phoebe', expect_intro=False):
                return self._finish_pre_r_return_after_switch(state, tag, elapsed, reason)
            return False

        if not self._concerto_effectively_full():
            if self._switch_to('Phoebe', expect_intro=False):
                return self._finish_pre_r_return_after_switch(state, tag, elapsed, reason)
            return False

        return_step = state.get(self.ZANI_PRE_R_RETURN_STEP_KEY)
        return_phase = state.get(self.ZANI_PRE_R_RETURN_PHASE_KEY)
        if not return_step or not return_phase:
            self.logger.error(
                f'ZFG V4.6 {tag}: P2 safe-return missing route; route to recovery'
            )
            self._route_broken_state_to_recovery(state, reason=f'{tag}-safe-return-missing-route')
            return False

        special_target = self.SPECIAL_INTRO_TARGET.get(self.ACTOR)
        if not special_target:
            self.logger.error(f'ZFG V4.6 {tag}: no legal special-intro target for safe return')
            return False

        if special_target == 'Phoebe':
            if self._switch_to('Phoebe', expect_intro=True):
                return self._finish_pre_r_return_after_switch(state, tag, elapsed, reason + '-direct-intro')
            return False

        self.logger.warning(
            f'ZFG V4.6 {tag}: Zani concerto FULL blocks ordinary return Phoebe; '
            f'use SAFE DETOUR Zani->{special_target}->Phoebe and preserve '
            f'resume={return_step}/{return_phase}'
        )
        if not self._switch_to(special_target, expect_intro=True):
            return False

        state[self.ZANI_PRE_R_PREP_SLICE_DONE_KEY] = True
        state.pop(self.ZANI_PRE_R_RETURN_STEP_KEY, None)
        state.pop(self.ZANI_PRE_R_RETURN_PHASE_KEY, None)
        state.pop(self.ZANI_PRE_R_PREP_SOURCE_KEY, None)
        state['detour_active'] = True
        state['detour_actor'] = special_target
        state['detour_final_target'] = 'Phoebe'
        state['detour_next_step'] = return_step
        state['detour_next_phase'] = return_phase
        state['detour_resume_step'] = state.get('step')
        state['detour_resume_phase'] = state.get('phase')
        self.logger.info(
            f'ZFG V4.6 {tag}: SAFE DETOUR armed after {reason}; '
            f'special_e_consumed={bool(state.get(self.ZANI_PRE_R_PRECAST_E_CONSUMED_KEY, False))} '
            f'-> final Phoebe resumes {return_step}/{return_phase}'
        )
        return True

    def _pre_r_precast_slice_step(self, state, tag, active_cap=None, p2_soft_window=False):
        """第一发Z后的赞妮quick-swap。

        P1：11s内以“特殊E确认消费”为主目标；
        P2：只给Z1一个短收益窗口，承接上一轮R2尾巴的预充，普通E/A推进多少算多少。
        若特殊E在窗口内READY则立即强提交；若到点仍未READY，保留当前资源回菲比打Z2，
        最终Z2后的EFORTE只负责续跑剩余缺口。
        """
        target = self._find_target_char('Phoebe')
        if target is None:
            self.logger.error(f'ZFG V4.6 {tag}: Phoebe target missing')
            return False

        if active_cap is None:
            active_cap = self.P1_PRE_R_PRECAST_HARD_CAP
        allow_intro_detour = bool(p2_soft_window)

        if self.has_intro:
            self.logger.info(
                f'ZFG V4.6 {tag}: entered PRECAST via special intro; '
                'wait intro/action lock before starting active timer'
            )
            self.wait_intro(time_out=1.8, click=False)
            self.task.next_frame()

        start = time.time()
        last_attack = -100.0
        normal_e_casts = int(state.get(self.ZANI_PRE_R_PRECAST_NORMAL_E_CASTS_KEY, 0) or 0)

        self.logger.info(
            f'ZFG V4.6 {tag}: PRECAST_SLICE START; active_cap={active_cap:.2f}s '
            f'mode={"P2-SOFT-PROGRESS" if p2_soft_window else "P1-COMMIT"}; '
            'goal=normal-E once -> A/resource -> special-E if READY; F freeze excluded'
        )

        if state.get(self.ZANI_PRE_R_PRECAST_E_CONSUMED_KEY):
            elapsed = self._p1_precast_active_elapsed(start)
            self.logger.info(
                f'ZFG V4.6 {tag}: special-E already consumed from prior call -> return Phoebe ONLY'
            )
            return self._return_pre_r_to_phoebe(
                state, tag, elapsed, 'special-E-consumed-retry', allow_intro_detour
            )

        while self._p1_precast_active_elapsed(start) < active_cap:
            self.check_combat()
            self.task.next_frame()
            now = time.time()
            elapsed = self._p1_precast_active_elapsed(start)

            try:
                in_team, current_index, _ = self.task.in_team()
            except Exception:
                in_team, current_index = False, -1

            if in_team and current_index == target.index:
                return self._complete_pre_r_return_to_phoebe(state, target, tag, elapsed)

            if in_team and current_index != self.index:
                self.logger.warning(
                    f'ZFG V4.6 {tag}: unexpected current_index={current_index} during PRECAST; '
                    'keep FSM step and let actor recovery handle it'
                )
                return False

            # 特殊E一旦READY，永远高于F/普通E/A；READY后只做提交和消费确认。
            if self.is_e_forte_full():
                state[self.ZANI_PRE_R_EFORTE_READY_KEY] = True
                if self._cast_pre_r_enhanced_e_quick(state, tag):
                    elapsed = self._p1_precast_active_elapsed(start)
                    if self._return_pre_r_to_phoebe(
                        state, tag, elapsed, 'special-E-consumed', allow_intro_detour
                    ):
                        return True
                    self.logger.error(
                        f'ZFG V4.6 {tag}: special E consumed but return Phoebe failed; '
                        'keep PRECAST step for recovery, NEVER recast special E blindly'
                    )
                    return False
                self.sleep(self.POLL)
                continue

            if self._field_f_check(resume_label=f'{tag} PRECAST', allow_intro=True):
                last_attack = time.time()
                self.logger.info(
                    f'ZFG V4.6 {tag}: F handled inside PRECAST; '
                    f'active_elapsed={self._p1_precast_active_elapsed(start):.3f}s (freeze excluded)'
                )
                continue

            if normal_e_casts < 1 and self.resonance_available():
                if self._cast_normal_e_once():
                    normal_e_casts += 1
                    cast_at = time.time()
                    state[self.ZANI_PRE_R_PRECAST_NORMAL_E_CASTS_KEY] = normal_e_casts
                    state[self.ZANI_PRE_R_PRECAST_NORMAL_E_LAST_CAST_KEY] = cast_at
                    self.logger.info(
                        f'ZFG V4.6 {tag}: PRECAST normal-E CAST #1 at '
                        f'active+{self._p1_precast_active_elapsed(start):.3f}s; '
                        'continue resource progress toward special-E'
                    )
                    self.sleep(self.NORMAL_E_POST_CAST_SETTLE)
                    self.task.next_frame()
                    continue

            if now - last_attack >= self.P1_PRE_R_PRECAST_ATTACK_INTERVAL:
                self.task.click()
                last_attack = now

            self.sleep(self.POLL)

        elapsed = self._p1_precast_active_elapsed(start)
        wall_elapsed = max(0.0, time.time() - start)
        frozen = max(0.0, wall_elapsed - elapsed)

        # 窗口边界特殊E已经亮时，不再继续“攒能量”，只给一次提交确认窗口。
        if (
            not state.get(self.ZANI_PRE_R_PRECAST_E_CONSUMED_KEY, False)
            and self.is_e_forte_full()
        ):
            self.logger.warning(
                f'ZFG V4.6 {tag}: PRECAST cap reached with special-E READY; '
                f'grant commit-only grace={self.P1_PRE_R_PRECAST_E_FINAL_COMMIT_GRACE:.2f}s'
            )
            if self._cast_pre_r_enhanced_e_quick(
                state, tag, timeout=self.P1_PRE_R_PRECAST_E_FINAL_COMMIT_GRACE
            ):
                elapsed = self._p1_precast_active_elapsed(start)
                return self._return_pre_r_to_phoebe(
                    state, tag, elapsed, 'special-E-consumed-final-grace', allow_intro_detour
                )

        if p2_soft_window:
            self.logger.info(
                f'ZFG V4.6 {tag}: P2 Z1 progress window END '
                f'active={elapsed:.3f}s wall={wall_elapsed:.3f}s excluded_freeze={frozen:.3f}s; '
                f'normal_e_casts={normal_e_casts} '
                f'special_e_attempted={bool(state.get(self.ZANI_PRE_R_PRECAST_E_ATTEMPTED_KEY, False))} '
                f'special_e_consumed={bool(state.get(self.ZANI_PRE_R_PRECAST_E_CONSUMED_KEY, False))}; '
                'DO NOT grind longer here -> preserve live resource and return Phoebe for Z2'
            )
            if self._return_pre_r_to_phoebe(
                state, tag, elapsed, 'p2-soft-progress-window-end', allow_intro_detour=True
            ):
                return True
            self.logger.error(f'ZFG V4.6 {tag}: P2 safe return Phoebe pending/failed; keep step')
            return False

        self.logger.warning(
            f'ZFG V4.6 {tag}: P1 PRECAST safety hard-cap reached '
            f'active={elapsed:.3f}s wall={wall_elapsed:.3f}s excluded_freeze={frozen:.3f}s; '
            f'special_e_attempted={bool(state.get(self.ZANI_PRE_R_PRECAST_E_ATTEMPTED_KEY, False))} '
            f'special_e_consumed={bool(state.get(self.ZANI_PRE_R_PRECAST_E_CONSUMED_KEY, False))}; '
            'safety-return Phoebe; final EFORTE continues from live resource'
        )
        if self._return_pre_r_to_phoebe(
            state, tag, elapsed, 'p1-safety-hard-cap-unconfirmed', allow_intro_detour=False
        ):
            return True

        self.logger.error(f'ZFG V4.6 {tag}: could not return Phoebe after PRECAST; keep step')
        return False

    def _pre_r_prep_slice_step(self, state, tag):
        if tag.startswith('P2-'):
            return self._pre_r_precast_slice_step(
                state,
                tag,
                active_cap=self.P2_PRE_R_PRECAST_ACTIVE_BUDGET,
                p2_soft_window=True,
            )
        return self._pre_r_precast_slice_step(
            state,
            tag,
            active_cap=self.P1_PRE_R_PRECAST_HARD_CAP,
            p2_soft_window=False,
        )

    def _init_eforte_state(self, state, tag):
        """初始化一次新的强化E准备，不在重试时重复清零。"""
        state[self.EFORTE_NORMAL_E_LAST_CAST_KEY] = -1.0
        state[self.EFORTE_NORMAL_E_CASTS_KEY] = 0
        state[self.EFORTE_ENHANCED_READY_SEEN_KEY] = False
        state[self.EFORTE_COMMIT_LOCK_KEY] = False
        state[self.EFORTE_FIRST_INPUT_TIME_KEY] = 0.0
        state[self.EFORTE_COMMIT_ATTEMPTS_KEY] = 0
        self.logger.info(
            f'ZFG V4.6 {tag}: EFORTE state initialized; manual F/dodge recovery enabled'
        )

    def _clear_eforte_state(self, state):
        """强化E阶段完成后清理临时状态，避免污染下一轮P1/P2。"""
        for key in (
            self.EFORTE_NORMAL_E_LAST_CAST_KEY,
            self.EFORTE_NORMAL_E_CASTS_KEY,
            self.EFORTE_ENHANCED_READY_SEEN_KEY,
            self.EFORTE_COMMIT_LOCK_KEY,
            self.EFORTE_FIRST_INPUT_TIME_KEY,
            self.EFORTE_COMMIT_ATTEMPTS_KEY,
        ):
            state.pop(key, None)

    def _eforte_commit_locked(self, state):
        """仅在当前确实处于P1/P2 EFORTE阶段时启用提交锁。

        自动F在这个窗口必须让路。手动闪避/F无法被脚本物理禁止，
        但提交锁会保证被打断后只重试强化E，不回普通E。
        """
        if state.get('step') not in (
            self.STEP_P1_ZANI_EFORTE_PREP,
            self.STEP_P2_ZANI_EFORTE_PREP,
        ):
            return False
        if state.get('phase') not in ('prepare_e', 'buff_settle'):
            return False
        return bool(state.get(self.EFORTE_COMMIT_LOCK_KEY, False))

    def f_break(
        self,
        check_f_on_switch=False,
        force=False,
    ):
        if self._zfg_team_matches():
            return False
        return self._zfg_f_break_raw(
            check_f_on_switch=check_f_on_switch,
            force=force,
        )

    def _run_f_break_with_freeze(self, label):
        f_start = time.time()
        if not self._zfg_f_break_raw(check_f_on_switch=False, force=False):
            return False
        f_duration = max(0.0, time.time() - f_start)
        if self.F_POST_ACTION_SETTLE_TIME > 0:
            self.sleep(self.F_POST_ACTION_SETTLE_TIME)
            self.task.next_frame()
        blocked = max(0.0, time.time() - f_start)
        self.add_freeze_duration(f_start, blocked)
        self.logger.info(
            f'ZFG V4.6 Zani F execution outside liberation during {label}; '
            f'F={f_duration:.2f}s freeze={blocked:.2f}s'
        )
        return True

    def _field_f_check(self, force=False, resume_label='Zani on-field', allow_intro=False):
        if self.in_liberation or (self.has_intro and not allow_intro) or not self.is_current_char:
            return False
        now = time.time()
        last = getattr(self, '_zfg_last_f_check', -100.0)
        if not force and now - last < self.F_CHECK_INTERVAL:
            return False
        self._zfg_last_f_check = now
        self.task.next_frame()
        return self._run_f_break_with_freeze(resume_label)

    def do_perform(self):
        if not self._zfg_team_matches():
            return super().do_perform()

        self._zanfei_guang = True
        state = self._zfg_state()

        if self._run_detour_if_needed(state):
            return

        step = state.get('step')
        phase = state.get('phase')

        prep_slice_step = step in (
            self.STEP_P1_ZANI_PRE_R_PREP_SLICE,
            self.STEP_P2_ZANI_PRE_R_PREP_SLICE,
        )
        if not self.in_liberation:
            if prep_slice_step:
                # V4.3 P1/P2 PRECAST均在内部处理机会F，以便把F freeze准确排除出本地hard-cap。
                self.logger.debug(f'ZFG V4.6 Zani {step} -> F handled inside PRECAST slice')
            elif not self._eforte_commit_locked(state):
                if self._field_f_check(resume_label=f'step={step} phase={phase}'):
                    return
            else:
                self.logger.debug(
                    'ZFG V4.6 Zani E_COMMIT_LOCK active -> skip automatic F'
                )

        self.logger.info(
            f'ZFG V4.6 Zani step={step} phase={phase} '
            f'intro={self.has_intro} liber={self.in_liberation} '
            f'N={state.get("nightfall_count", 0)}'
        )

        if step == self.STEP_P1_ZANI_OPEN_EA_TO_PHOEBE:
            return self._p1_open_ea_to_phoebe(state)

        if step == self.STEP_P1_ZANI_PRE_R_PREP_SLICE:
            return self._pre_r_prep_slice_step(state, tag='P1-Z1-preR')

        if step == self.STEP_P1_ZANI_EFORTE_PREP:
            return self._enhanced_e_prep_step(
                state,
                self.STEP_P1_ZANI_R1_N1_TO_ROVER,
                tag='P1-EFORTE',
            )

        if step == self.STEP_P1_ZANI_R1_N1_TO_ROVER:
            return self._r1_n1_early_handoff(
                state,
                self.STEP_P1_ROVER_OPPORTUNITY_E_TO_PHOEBE,
                tag='P1-N1',
            )

        if step == self.STEP_P1_ZANI_N2_TO_ROVER_R:
            return self._nightfall_then_switch(
                state,
                nightfall_number=2,
                target='Rover',
                next_step=self.STEP_P1_ROVER_R_TO_ZANI,
                tag='P1-N2',
            )

        if step == self.STEP_P1_ZANI_N3_TO_PHOEBE:
            return self._nightfall_then_switch(
                state,
                nightfall_number=3,
                target='Phoebe',
                next_step=self.STEP_P1_PHOEBE_CONFESSION_R_TO_ZANI,
                tag='P1-N3',
                prehold_phoebe=True,
            )

        if step == self.STEP_P1_ZANI_N4_R2_EA_TO_PHOEBE:
            return self._final_nightfall_r2_e(
                state,
                nightfall_number=4,
                next_phoebe_step=self.STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI,
                tag='P1-N4',
                mark_new_cycle=True,
                r2_policy='p1_deadline',
            )

        if step == self.STEP_P2_ZANI_PRE_R_PREP_SLICE:
            return self._pre_r_prep_slice_step(state, tag='P2-Z1-preR')

        if step == self.STEP_P2_ZANI_EFORTE_PREP:
            return self._enhanced_e_prep_step(
                state,
                self.STEP_P2_ZANI_R1_N1_TO_ROVER,
                tag='P2-EFORTE',
            )

        if step == self.STEP_P2_ZANI_R1_N1_TO_ROVER:
            return self._r1_n1_early_handoff(
                state,
                self.STEP_P2_ROVER_SLOT_TO_ZANI,
                tag='P2-N1',
            )

        if step == self.STEP_P2_ZANI_N2_TO_PHOEBE:
            if state.get('phase') is None:
                state[self.P2_CONFESSION_AZ_USED_KEY] = False
                state[self.P2_CONFESSION_AZ_COUNT_KEY] = 0
                state.pop(self.P2_CONFESSION_AZ_TARGET_KEY, None)
                state.pop(self.P2_CONFESSION_RETRY_AFTER_KEY, None)
            return self._nightfall_then_switch(
                state,
                nightfall_number=2,
                target='Phoebe',
                next_step=self.STEP_P2_PHOEBE_CONFESSION_CHECK,
                tag='P2-N2',
                prehold_phoebe=False,
            )

        if step == self.STEP_P2_ZANI_N3_R2_EA_TO_PHOEBE:
            return self._final_nightfall_r2_e(
                state,
                nightfall_number=3,
                next_phoebe_step=self.STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI,
                tag='P2-N3',
                mark_new_cycle=True,
                r2_policy='p2_after_n3_or_deadline',
            )

        if step == self.STEP_RECOVER_ZANI_LIBERATION:
            return self._recover_liberation(state)

        return self._recover_wrong_actor(state)


    def _arm_phoebe_prehold(self, state, tag, require_zani_e_locked=True):
        if state.get(self.PHOEBE_PREHOLD_E_KEY):
            return True
        if require_zani_e_locked and self.resonance_available():
            self.logger.info(
                f'ZFG V4.6 {tag}: skip Phoebe-E prehold for now; Zani E still available'
            )
            return False
        self.task.send_key_down(self.get_resonance_key())
        state[self.PHOEBE_PREHOLD_E_KEY] = True
        state[self.PHOEBE_PREHOLD_SOURCE_KEY] = self.ACTOR
        self.logger.info(f'ZFG V4.6 {tag}: Phoebe-E PREHOLD armed')
        return True

    def _p1_open_ea_to_phoebe(self, state):
        """V4.3 P1 Zani opening handoff: normal E -> A commit -> Phoebe.

        Same deterministic 70ms/180ms EA contract as V4.2, but Rover R now happens
        before this step, so this EA returns directly to Phoebe instead of Rover.
        """
        phase = state.get('phase', 'e')

        if phase == 'e':
            if not self.resonance_available():
                self.sleep(0.03)
                self.task.next_frame()
                return

            clicked, _, _ = self.click_resonance(
                send_click=False, time_out=0.7,
            )
            if not clicked:
                return

            self.logger.info(
                f'ZFG V4.6 P1 Zani EA->Phoebe: normal E confirmed -> '
                f'wait {self.OPEN_E_TO_A_GAP:.2f}s for A input window'
            )
            state['phase'] = 'a_after_e'
            phase = 'a_after_e'

        if phase == 'a_after_e':
            self.sleep(self.OPEN_E_TO_A_GAP, check_combat=False)
            self.task.click()
            state['phase'] = 'a_commit'
            phase = 'a_commit'
            self.logger.info(
                f'ZFG V4.6 P1 Zani EA->Phoebe: A INPUT sent -> commit window '
                f'{self.OPEN_A_COMMIT_GAP:.2f}s; NO switch during this window'
            )

        if phase == 'a_commit':
            self.sleep(self.OPEN_A_COMMIT_GAP, check_combat=False)
            self.logger.info(
                'ZFG V4.6 P1 Zani EA->Phoebe: A commit window complete -> switch Phoebe'
            )
            state['phase'] = 'switch_phoebe'
            phase = 'switch_phoebe'

        if phase == 'switch_phoebe':
            self._switch_route(
                state, 'Phoebe', self.STEP_P1_PHOEBE_3A_STAR_SAVE_FILL_TO_ZANI,
            )

    def _cast_normal_e_once(self):
        """普通E：发送后必须看到“普通E进入不可用”或“强化E接管图标”才算成功。"""
        if self.is_e_forte_full():
            return False
        if not self.resonance_available():
            return False

        clicked, _, _ = self.click_resonance(
            send_click=False,
            time_out=0.7,
        )
        if not clicked:
            return False

        confirm_start = time.time()
        clear_frames = 0
        while time.time() - confirm_start < self.NORMAL_E_CONFIRM_TIMEOUT:
            self.task.next_frame()

            if self.is_e_forte_full():
                self.logger.info(
                    'ZFG V4.6 Zani normal E RELEASE confirmed -> enhanced-E became ready'
                )
                return True

            if not self.resonance_available():
                clear_frames += 1
                if clear_frames >= self.NORMAL_E_CLEAR_CONFIRM_FRAMES:
                    self.logger.info(
                        'ZFG V4.6 Zani normal E RELEASE confirmed -> E entered cooldown'
                    )
                    return True
            else:
                clear_frames = 0

            self.sleep(self.POLL)

        self.logger.warning(
            'ZFG V4.6 Zani normal E input sent but release NOT confirmed; do not start 5s CD lock'
        )
        return False

    def _cast_enhanced_e_release(self, state=None, tag='EFORTE'):
        """强化E提交：图标持续消失才算成功，并记录跨轮次的提交进度。

        手动F/手动闪避/受击都可能让E输入被延迟或取消。这里不把“按键已发送”
        当成功；失败后由 E_COMMIT_LOCK 继续重试强化E，绝不回普通E。
        """
        if not self.is_e_forte_full():
            return False

        start = time.time()
        last_send = 0.0
        sent = False
        first_send_time = None
        clear_since = None

        if state is not None:
            state[self.EFORTE_COMMIT_LOCK_KEY] = True
            state[self.EFORTE_ENHANCED_READY_SEEN_KEY] = True
            state[self.EFORTE_COMMIT_ATTEMPTS_KEY] = int(
                state.get(self.EFORTE_COMMIT_ATTEMPTS_KEY, 0) or 0
            ) + 1
            self.logger.info(
                f'ZFG V4.6 {tag}: E_COMMIT_LOCK attempt='
                f'{state[self.EFORTE_COMMIT_ATTEMPTS_KEY]} '
                '-> NO auto-F / NO normal-E fallback'
            )

        while time.time() - start < self.ENHANCED_E_CONFIRM_TIMEOUT:
            self.task.next_frame()
            forte_now = bool(self.is_e_forte_full())

            if forte_now:
                clear_since = None
                now = time.time()
                if now - last_send >= 0.06:
                    self.send_resonance_key()
                    last_send = now
                    if not sent:
                        sent = True
                        first_send_time = now
                        if state is not None and not state.get(
                            self.EFORTE_FIRST_INPUT_TIME_KEY
                        ):
                            state[self.EFORTE_FIRST_INPUT_TIME_KEY] = now
                        self.logger.info(
                            'ZFG V4.6 Zani enhanced E input started'
                        )
            elif sent:
                if clear_since is None:
                    clear_since = time.time()
                clear_for = time.time() - clear_since
                if clear_for >= self.ENHANCED_E_CLEAR_STABLE_SECONDS:
                    try:
                        self.record_resonance_use()
                    except Exception:
                        pass

                    self.crisis_time = (
                        first_send_time
                        if first_send_time is not None
                        else time.time()
                    )
                    self.logger.info(
                        f'ZFG V4.6 Zani enhanced E RELEASE confirmed; '
                        f'icon-clear-stable={clear_for:.2f}s hit/blazes NOT required'
                    )
                    return True

            self.sleep(self.POLL)

        self.logger.warning(
            'ZFG V4.6 Zani enhanced E release not confirmed; '
            'enter ambiguous settle under E_COMMIT_LOCK'
        )
        return False

    def _confirm_ambiguous_enhanced_e_release(self, state, tag):
        """强化E确认超时后的恢复观察窗。

        - 图标重新稳定出现：说明大概率没放出去，下一轮只重试强化E。
        - 图标持续消失：说明可能被手动F/闪避/动作锁延迟后才真正释放，按成功处理。
        - 无论哪种情况，都不回普通E/A准备链。
        """
        start = time.time()
        clear_since = None

        while time.time() - start < self.ENHANCED_E_AMBIGUOUS_SETTLE_TIMEOUT:
            self.task.next_frame()
            if self.is_e_forte_full():
                self.logger.warning(
                    f'ZFG V4.6 {tag}: enhanced-E icon returned during ambiguous settle '
                    '-> keep E_COMMIT_LOCK and retry enhanced-E only'
                )
                return False

            if clear_since is None:
                clear_since = time.time()
            clear_for = time.time() - clear_since
            if clear_for >= self.ENHANCED_E_CLEAR_STABLE_SECONDS:
                try:
                    self.record_resonance_use()
                except Exception:
                    pass
                first_input = float(
                    state.get(self.EFORTE_FIRST_INPUT_TIME_KEY, 0.0) or 0.0
                )
                self.crisis_time = first_input if first_input > 0 else time.time()
                self.logger.info(
                    f'ZFG V4.6 {tag}: delayed enhanced-E RELEASE confirmed '
                    f'after interruption; icon-clear-stable={clear_for:.2f}s'
                )
                return True

            self.sleep(self.POLL)

        self.logger.warning(
            f'ZFG V4.6 {tag}: enhanced-E state still ambiguous; '
            'keep E_COMMIT_LOCK, no normal-E fallback'
        )
        return False

    def _prepare_and_cast_enhanced_e(self, state, tag):
        """V4.3：EFORTE资源准备 + 持久化提交锁。

        正常优先级仍是：强化E > 真正转好的普通E > A。

        关键恢复规则：
        1) 普通E最后释放时间和次数写入共享 state，不会因 do_perform() 重进而清零；
        2) 一旦任何一帧看到强化E READY，就进入 E_COMMIT_LOCK；
        3) 提交锁期间禁止自动F、禁止普通E、禁止A补资源，只处理强化E；
        4) 手动F/闪避若打断强化E，下一轮只重试强化E；若图标延迟消失则按延迟成功处理。
        """
        start = time.time()
        last_attack = -100.0

        normal_e_cast_count = int(
            state.get(self.EFORTE_NORMAL_E_CASTS_KEY, 0) or 0
        )
        last_normal_e_cast_at = float(
            state.get(self.EFORTE_NORMAL_E_LAST_CAST_KEY, -1.0) or -1.0
        )
        ready_seen = bool(
            state.get(self.EFORTE_ENHANCED_READY_SEEN_KEY, False)
        )

        self.logger.info(
            f'ZFG V4.6 {tag}: enhanced-E prep RESUME '
            f'ready_seen={ready_seen} normal_e_casts={normal_e_cast_count} '
            f'commit_lock={bool(state.get(self.EFORTE_COMMIT_LOCK_KEY, False))}'
        )

        while time.time() - start < self.ENHANCED_E_PREP_TIMEOUT:
            self.task.next_frame()

            if state.get(self.EFORTE_ENHANCED_READY_SEEN_KEY, False):
                state[self.EFORTE_COMMIT_LOCK_KEY] = True

                if self.is_e_forte_full():
                    if self._cast_enhanced_e_release(state=state, tag=tag):
                        return True
                    if self._confirm_ambiguous_enhanced_e_release(state, tag):
                        return True
                    return False

                if self._confirm_ambiguous_enhanced_e_release(state, tag):
                    return True
                return False

            if self.is_e_forte_full():
                state[self.EFORTE_ENHANCED_READY_SEEN_KEY] = True
                state[self.EFORTE_COMMIT_LOCK_KEY] = True
                self.logger.info(
                    f'ZFG V4.6 {tag}: enhanced-E READY -> E_COMMIT_LOCK '
                    f'elapsed={time.time()-start:.2f}s '
                    f'normal_e_casts={normal_e_cast_count}'
                )
                if self._cast_enhanced_e_release(state=state, tag=tag):
                    return True
                if self._confirm_ambiguous_enhanced_e_release(state, tag):
                    return True
                return False

            if self._field_f_check(resume_label='enhanced-E prep'):
                last_attack = time.time()
                continue

            normal_ready = bool(self.resonance_available())
            last_normal_e_cast_at = float(
                state.get(self.EFORTE_NORMAL_E_LAST_CAST_KEY, -1.0) or -1.0
            )
            normal_e_cast_count = int(
                state.get(self.EFORTE_NORMAL_E_CASTS_KEY, 0) or 0
            )

            if last_normal_e_cast_at < 0:
                normal_recast_allowed = True
                normal_elapsed = 999.0
            else:
                normal_elapsed = self.time_elapsed_accounting_for_freeze(
                    last_normal_e_cast_at
                )
                normal_recast_allowed = (
                    normal_elapsed >= self.NORMAL_E_RECAST_MIN_ELAPSED
                )

            if normal_ready and normal_recast_allowed:
                if self._cast_normal_e_once():
                    normal_e_cast_count += 1
                    last_normal_e_cast_at = time.time()
                    state[self.EFORTE_NORMAL_E_CASTS_KEY] = normal_e_cast_count
                    state[self.EFORTE_NORMAL_E_LAST_CAST_KEY] = last_normal_e_cast_at
                    self.logger.info(
                        f'ZFG V4.6 {tag}: normal-E CAST #{normal_e_cast_count}; '
                        'state persisted, immediately re-sample enhanced-E'
                    )
                    self.sleep(self.NORMAL_E_POST_CAST_SETTLE)
                    self.task.next_frame()
                    continue
            elif normal_ready and last_normal_e_cast_at >= 0:
                if int(normal_elapsed * 10) % 10 == 0:
                    self.logger.debug(
                        f'ZFG V4.6 {tag}: normal-E UI ready ignored during real CD '
                        f'elapsed={normal_elapsed:.2f}/{self.NORMAL_E_REAL_CD:.2f}s'
                    )

            now = time.time()
            if now - last_attack >= self.NORMAL_E_ATTACK_INTERVAL:
                self.task.click()
                last_attack = now
            self.sleep(self.POLL)

        self.logger.warning(
            f'ZFG V4.6 {tag}: enhanced-E prepare timeout '
            f'normal_e_casts={state.get(self.EFORTE_NORMAL_E_CASTS_KEY, 0)} '
            f'ready_seen={state.get(self.EFORTE_ENHANCED_READY_SEEN_KEY, False)}; '
            'keep EFORTE step with persistent state'
        )
        return False

    def _zani_special_e_buff_visible(self, log=False):
        """识别赞妮血条上方单独一行的14s特殊E专属Buff。

        这个图标只在赞妮登场时显示，所以只在菲比特殊变奏赞妮后的现有入场等待结束时读取。
        使用“橄榄色主体 + 中央亮白箭头”双特征，阈值按用户提供的三张1600x900实机截图标定；
        false-negative只会回落旧EFORTE，false-positive才危险，因此阈值偏保守。
        """
        try:
            x1, y1, x2, y2 = self.SPECIAL_E_BUFF_BOX
            box = self.task.box_of_screen_scaled(
                2560, 1440,
                x1, y1, x2, y2,
                name='zani_special_e_buff',
                hcenter=True,
            )
            self.task.draw_boxes(box.name, box)
            cropped = box.crop_frame(self.task.frame)
            if cropped is None or cropped.size == 0:
                return False

            olive_low, olive_high = color_range_to_bound(
                self.SPECIAL_E_BUFF_OLIVE_COLOR
            )
            white_low, white_high = color_range_to_bound(
                self.SPECIAL_E_BUFF_WHITE_COLOR
            )
            olive_mask = cv2.inRange(cropped, olive_low, olive_high)
            white_mask = cv2.inRange(cropped, white_low, white_high)

            total = float(max(1, olive_mask.size))
            olive_ratio = cv2.countNonZero(olive_mask) / total

            component_ratio = 0.0
            count, _, stats, _ = cv2.connectedComponentsWithStats(
                olive_mask, connectivity=8
            )
            if count > 1:
                largest = max(
                    int(stats[i, cv2.CC_STAT_AREA])
                    for i in range(1, count)
                )
                component_ratio = largest / total

            h, w = white_mask.shape[:2]
            cx1 = max(0, int(w * 0.34))
            cx2 = min(w, int(w * 0.72))
            cy1 = max(0, int(h * 0.18))
            cy2 = min(h, int(h * 0.68))
            center = white_mask[cy1:cy2, cx1:cx2]
            center_total = float(max(1, center.size))
            center_white_ratio = cv2.countNonZero(center) / center_total

            visible = (
                olive_ratio >= self.SPECIAL_E_BUFF_MIN_OLIVE_RATIO
                and component_ratio >= self.SPECIAL_E_BUFF_MIN_COMPONENT_RATIO
                and center_white_ratio >= self.SPECIAL_E_BUFF_MIN_CENTER_WHITE_RATIO
            )

            if log:
                self.logger.info(
                    f'ZFG V4.6 Zani special-E 14s Buff probe visible={visible} '
                    f'olive={olive_ratio:.3f}/{self.SPECIAL_E_BUFF_MIN_OLIVE_RATIO:.3f} '
                    f'component={component_ratio:.3f}/{self.SPECIAL_E_BUFF_MIN_COMPONENT_RATIO:.3f} '
                    f'center_white={center_white_ratio:.3f}/'
                    f'{self.SPECIAL_E_BUFF_MIN_CENTER_WHITE_RATIO:.3f}'
                )
            return visible
        except Exception as exc:
            self.logger.warning(
                f'ZFG V4.6 Zani special-E Buff probe failed {exc}; '
                'fall back to original EFORTE path'
            )
            return False

    def _zani_special_e_buff_slot_occupied(self, log=False):
        """V4.3 loose truth gate: any clear icon content in the fixed buff slot counts.

        The goal is only to answer whether the special-E buff slot is occupied, not
        to classify the exact buff artwork. This deliberately tolerates color/shape
        variation that caused false negatives in the V4.2 dedicated-icon probe.
        """
        try:
            x1, y1, x2, y2 = self.SPECIAL_E_BUFF_BOX
            box = self.task.box_of_screen_scaled(
                2560, 1440, x1, y1, x2, y2,
                name='zani_special_e_buff_slot', hcenter=True,
            )
            cropped = box.crop_frame(self.task.frame)
            if cropped is None or getattr(cropped, 'size', 0) == 0:
                return False

            gray = cv2.cvtColor(cropped, cv2.COLOR_BGR2GRAY)
            hsv = cv2.cvtColor(cropped, cv2.COLOR_BGR2HSV)
            bright = (gray >= 145).astype('uint8') * 255
            saturated = (
                (hsv[:, :, 1] >= 45) & (hsv[:, :, 2] >= 70)
            ).astype('uint8') * 255
            content = cv2.bitwise_or(bright, saturated)

            total = float(max(1, content.size))
            bright_ratio = cv2.countNonZero(bright) / total
            content_ratio = cv2.countNonZero(content) / total

            count, _, stats, _ = cv2.connectedComponentsWithStats(content, connectivity=8)
            largest_ratio = 0.0
            if count > 1:
                largest = max(int(stats[i, cv2.CC_STAT_AREA]) for i in range(1, count))
                largest_ratio = largest / total

            edges = cv2.Canny(gray, 55, 135)
            edge_ratio = cv2.countNonZero(edges) / total

            occupied = bool(
                (
                    bright_ratio >= self.SPECIAL_E_BUFF_SLOT_MIN_BRIGHT_RATIO
                    and largest_ratio >= self.SPECIAL_E_BUFF_SLOT_MIN_COMPONENT_RATIO
                )
                or (
                    content_ratio >= self.SPECIAL_E_BUFF_SLOT_MIN_CONTENT_RATIO
                    and edge_ratio >= self.SPECIAL_E_BUFF_SLOT_MIN_EDGE_RATIO
                )
            )
            if log:
                self.logger.info(
                    f'ZFG V4.6 Zani special-E BUFF-SLOT occupied={occupied} '
                    f'bright={bright_ratio:.3f}/{self.SPECIAL_E_BUFF_SLOT_MIN_BRIGHT_RATIO:.3f} '
                    f'content={content_ratio:.3f}/{self.SPECIAL_E_BUFF_SLOT_MIN_CONTENT_RATIO:.3f} '
                    f'component={largest_ratio:.3f}/{self.SPECIAL_E_BUFF_SLOT_MIN_COMPONENT_RATIO:.3f} '
                    f'edge={edge_ratio:.3f}/{self.SPECIAL_E_BUFF_SLOT_MIN_EDGE_RATIO:.3f}'
                )
            return occupied
        except Exception as exc:
            self.logger.warning(
                f'ZFG V4.6 Zani special-E BUFF-SLOT probe failed {exc}; continue live EFORTE logic'
            )
            return False

    def _wait_enhanced_e_buff_window(self):
        self.logger.info(
            'ZFG V4.6 Zani wait enhanced-E action/buff window; '
            'damage hit is irrelevant'
        )
        self.wait_crisis_protocol_end()
        self.logger.info(
            'ZFG V4.6 Zani enhanced-E buff window ready -> allow R1'
        )
        return True

    def _try_pre_r1_normal_e_opportunity(self, tag):
        """R1前普通E：有则放且必须确认成功；没有则零等待直接R1。

        Return None when unavailable (safe to continue), True on confirmed cast,
        False when an available E was attempted but not confirmed (caller should retry).
        """
        self.task.next_frame()
        if self.is_e_forte_full():
            self.logger.info(
                f'ZFG V4.6 {tag}: pre-R1 normal-E SKIP because special-E UI is READY'
            )
            return None
        if not self.resonance_available():
            self.logger.info(
                f'ZFG V4.6 {tag}: pre-R1 normal-E unavailable NOW -> R1 without wait'
            )
            return None

        confirmed = bool(self._cast_normal_e_once())
        if confirmed:
            self.logger.info(
                f'ZFG V4.6 {tag}: HARD_CONFIRM pre-R1 NORMAL_E RELEASED -> allow R1'
            )
            return True

        self.logger.warning(
            f'ZFG V4.6 {tag}: pre-R1 NORMAL_E was available but release unconfirmed -> keep phase / retry'
        )
        return False

    def _enhanced_e_prep_step(self, state, next_step, tag):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.5, click=False)

            # V4.3 P1/P2主真值门：quick-swap阶段的“特殊E消费确认”是唯一主判据。
            # 14s Buff只作辅助诊断：Buff单独命中绝不能把未确认消费的precast判成成功。
            precast_route = tag in ('P1-EFORTE', 'P2-EFORTE')
            if precast_route:
                # V4.3: fixed-slot occupancy is sufficient evidence that special E was already released.
                # This is intentionally looser than exact artwork recognition.
                slot_occupied = self._zani_special_e_buff_slot_occupied(log=True)
                if slot_occupied:
                    self.logger.info(
                        f'ZFG V4.6 {tag}: special-E BUFF-SLOT OCCUPIED -> treat special E as already released; '
                        'skip EFORTE prep and only check confirmed normal-E before R1'
                    )
                    e_result = self._try_pre_r1_normal_e_opportunity(tag)
                    if e_result is False:
                        return
                    self._clear_eforte_state(state)
                    self._clear_pre_r_prep_markers(state)
                    self._advance_step(state, next_step)
                    return

                precast_attempted = bool(
                    state.get(self.ZANI_PRE_R_PRECAST_E_ATTEMPTED_KEY, False)
                )
                precast_consumed = bool(
                    state.get(self.ZANI_PRE_R_PRECAST_E_CONSUMED_KEY, False)
                )

                if precast_consumed:
                    buff_visible = self._zani_special_e_buff_visible(log=True)
                    self.logger.info(
                        f'ZFG V4.6 {tag}: quick-swap special-E CONSUMED flag=True '
                        f'(PRIMARY); Buff={buff_visible} (AUX only) '
                        '-> SKIP EFORTE_PREP; check one soft normal-E then R1'
                    )
                    e_result = self._try_pre_r1_normal_e_opportunity(tag)
                    if e_result is False:
                        return
                    self._clear_eforte_state(state)
                    self._clear_pre_r_prep_markers(state)
                    self._advance_step(state, next_step)
                    return

                if precast_attempted:
                    buff_visible = self._zani_special_e_buff_visible(log=True)
                    if buff_visible:
                        self.logger.warning(
                            f'ZFG V4.6 {tag}: Buff PRESENT but quick-swap consumption was NOT confirmed; '
                            'Buff is AUX only -> DO NOT skip EFORTE, re-verify/recast special E from live UI'
                        )
                    else:
                        self.logger.info(
                            f'ZFG V4.6 {tag}: quick-swap special-E attempted but consumption unconfirmed '
                            'and Buff absent -> use live EFORTE fallback'
                        )
                else:
                    self.logger.info(
                        f'ZFG V4.6 {tag}: no earlier special-E pre-cast attempt '
                        '-> use original live EFORTE prep'
                    )

            prep_slice_done = bool(state.get(self.ZANI_PRE_R_PREP_SLICE_DONE_KEY, False))
            ready_hint = bool(state.get(self.ZANI_PRE_R_EFORTE_READY_KEY, False))
            precast_normal_e_casts = int(
                state.get(self.ZANI_PRE_R_PRECAST_NORMAL_E_CASTS_KEY, 0) or 0
            )
            precast_normal_e_last = float(
                state.get(self.ZANI_PRE_R_PRECAST_NORMAL_E_LAST_CAST_KEY, -1.0) or -1.0
            )

            self._init_eforte_state(state, tag)

            # 若P1/P2 quick-swap已经成功放过普通E，而Buff最终没命中，需要保留真实5s CD时间戳。
            # 这样fallback只从当前资源继续，不会把前面的普通E当作“没发生过”。
            if precast_route and precast_normal_e_casts > 0 and precast_normal_e_last > 0:
                state[self.EFORTE_NORMAL_E_CASTS_KEY] = precast_normal_e_casts
                state[self.EFORTE_NORMAL_E_LAST_CAST_KEY] = precast_normal_e_last
                self.logger.info(
                    f'ZFG V4.6 {tag}: preserve pre-cast normal-E history '
                    f'casts={precast_normal_e_casts} '
                    f'elapsed={self.time_elapsed_accounting_for_freeze(precast_normal_e_last):.2f}s/5.00s'
                )

            # P1/P2 PRECAST若未确认consumed，则Buff不得单独放行；fallback从当前live UI继续。
            current_ready = bool(self.is_e_forte_full())
            if not precast_route and ready_hint and current_ready:
                state[self.EFORTE_ENHANCED_READY_SEEN_KEY] = True
                self.logger.info(
                    f'ZFG V4.6 {tag}: pre-R READY hint REVERIFIED after intro '
                    '-> enhanced-E can commit immediately'
                )
            elif not precast_route and ready_hint and not current_ready:
                self.logger.warning(
                    f'ZFG V4.6 {tag}: pre-R READY hint stale after intro '
                    '-> trust live UI and resume prep from current resource'
                )
            elif prep_slice_done:
                self.logger.info(
                    f'ZFG V4.6 {tag}: PREP slice history preserved; '
                    'resume from current live resource'
                )

            state['phase'] = 'prepare_e'
            phase = 'prepare_e'

        if phase == 'prepare_e':
            if not self._prepare_and_cast_enhanced_e(state, tag):
                return
            state['phase'] = 'buff_settle'
            phase = 'buff_settle'

        if phase == 'buff_settle':
            self._wait_enhanced_e_buff_window()
            e_result = self._try_pre_r1_normal_e_opportunity(tag)
            if e_result is False:
                return
            self.logger.info(f'ZFG V4.6 {tag}: enhanced-E step complete -> confirmed normal-E checked -> R1 step')
            self._clear_eforte_state(state)
            self._clear_pre_r_prep_markers(state)
            self._advance_step(state, next_step)


    def _try_liber_echo_soft(self, tag, force=False):
        """R1~R2期间的Q机会监听：有就尝试，不形成phase硬门。"""
        if not self.in_liberation or not self.is_current_char:
            return False
        now = time.time()
        last = getattr(self, '_zfg_last_liber_echo_watch', -100.0)
        if not force and now - last < self.LIBER_ECHO_WATCH_INTERVAL:
            return False
        self._zfg_last_liber_echo_watch = now
        if not self.echo_available():
            return False
        result = self.click_echo(time_out=0)
        self.logger.info(
            f'ZFG V4.6 {tag}: SOFT_COMMIT R-window Q INPUT_COMMITTED '
            f'api_result={bool(result)}; NON-BLOCKING'
        )
        return bool(result)

    def _cast_r1(self):
        start = time.time()

        while time.time() - start < self.LIBERATION_READY_TIMEOUT:
            if self._field_f_check(resume_label='R1 pre-cast wait'):
                continue

            if self.liberation_available():
                if self.click_liberation(send_click=True):
                    self._start_liberation()
                    self._liber_phase = 1
                    self.logger.info(
                        'ZFG V4.6 Zani R1 confirmed -> liberation state'
                    )
                    return True

            self.task.click()
            self.sleep(self.POLL)
            self.task.next_frame()

        self.logger.warning(
            'ZFG V4.6 Zani R1 unavailable/failed; keep phase'
        )
        return False

    def _clear_nightfall_commit_ctx(self, state, tag=None):
        ctx = state.get(self.NIGHTFALL_COMMIT_CTX_KEY)
        if tag is None or not isinstance(ctx, dict) or ctx.get('tag') == tag:
            state.pop(self.NIGHTFALL_COMMIT_CTX_KEY, None)

    def _nightfall_e_white_ratio(self):
        """直接读取E图标白色比例。终夜期间“暂时变灰但不进CD”必须靠这个值捕捉。"""
        try:
            return max(0.0, float(self.current_resonance()))
        except Exception:
            return -1.0

    def _sample_nightfall_e_gray(self, ctx):
        e_white = self._nightfall_e_white_ratio()
        if e_white < 0:
            ctx['e_gray_frames'] = 0
            return False, e_white, None

        baseline = float(ctx.get('e_white_baseline', -1.0) or -1.0)
        # 触发后的最初几帧仍允许把更亮的值纳入baseline，避免取样恰逢UI刷新低谷。
        if e_white > baseline:
            baseline = e_white
            ctx['e_white_baseline'] = baseline
        ctx['e_white_min'] = min(float(ctx.get('e_white_min', e_white)), e_white)

        armed = baseline >= self.NIGHTFALL_E_BRIGHT_MIN
        gray_threshold = None
        if armed:
            gray_threshold = min(
                self.NIGHTFALL_E_GRAY_ABS_MAX,
                baseline * self.NIGHTFALL_E_GRAY_RELATIVE,
            )
            if e_white <= gray_threshold:
                ctx['e_gray_frames'] = int(ctx.get('e_gray_frames', 0)) + 1
            else:
                ctx['e_gray_frames'] = 0
        else:
            ctx['e_gray_frames'] = 0

        return (
            armed and int(ctx.get('e_gray_frames', 0)) >= self.NIGHTFALL_E_GRAY_CONFIRM_FRAMES,
            e_white,
            gray_threshold,
        )

    def _nightfall_attack_input(self, state, tag):
        """Send one Nightfall attack; P1-N1 first A holds W for 0.20s to suppress backstep."""
        if tag == 'P1-N1' and state.pop(self.P1_N1_FORWARD_A_PENDING_KEY, False):
            try:
                self.task.send_key_down('w')
                self.task.click()
                self.logger.info(
                    f'ZFG V4.6 {tag}: first A + W HOLD {self.P1_N1_FORWARD_HOLD:.2f}s -> suppress backstep'
                )
                self.sleep(self.P1_N1_FORWARD_HOLD, check_combat=False)
            finally:
                try:
                    self.task.send_key_up('w')
                except Exception:
                    pass
            return
        self.task.click()

    def _continue_nightfall_commit(self, state, tag, prehold_phoebe=False, final=False):
        """续接终夜提交。V4.3以E图标亮->灰为最快主判据，Nightfall图标消失只作fallback。"""
        ctx = state.get(self.NIGHTFALL_COMMIT_CTX_KEY)
        if not isinstance(ctx, dict) or ctx.get('tag') != tag:
            return self.NIGHTFALL_FAILED

        slice_start = time.time()
        while time.time() - slice_start < self.NIGHTFALL_COMMIT_TIMEOUT:
            if not self.in_liberation:
                self._clear_nightfall_commit_ctx(state, tag)
                return self.NIGHTFALL_LIBERATION_ENDED

            if final and self._r2_deadline_reached(state):
                self.logger.warning(
                    f'ZFG {tag}: R2 hard deadline preempts Nightfall confirm '
                    f'R_elapsed={self._r1_elapsed(state):.2f}s'
                )
                self._clear_nightfall_commit_ctx(state, tag)
                return self.NIGHTFALL_R2_DEADLINE

            now = time.time()
            if now - float(ctx.get('last_attack', -100.0)) >= 0.045:
                self._nightfall_attack_input(state, tag)
                ctx['last_attack'] = time.time()

            protected_for = now - float(ctx.get('trigger_start', now))
            if (
                prehold_phoebe
                and protected_for >= self.NIGHTFALL_COMMIT_MIN_AFTER_TRIGGER
                and not state.get(self.PHOEBE_PREHOLD_E_KEY)
            ):
                self._arm_phoebe_prehold(
                    state,
                    tag,
                    require_zani_e_locked=False,
                )

            self.sleep(0.015)
            self.task.next_frame()

            # V4.3主判据：直接读E图标白色比例，捕捉“灰但未进入CD”的动作锁。
            e_gray_done, e_white, e_gray_threshold = self._sample_nightfall_e_gray(ctx)

            # 旧available下降沿只留作诊断/次级证据；它看不到部分“仅变灰、不进CD”的状态。
            e_now = bool(self.resonance_available())
            if e_now:
                ctx['e_ready_seen'] = True
                ctx['e_fall_frames'] = 0
            elif ctx.get('e_ready_seen'):
                ctx['e_fall_frames'] = int(ctx.get('e_fall_frames', 0)) + 1

            icon_cleared = not self.is_nightfall_ready(threshold=0.035)
            if icon_cleared:
                ctx['icon_clear_frames'] = int(ctx.get('icon_clear_frames', 0)) + 1
            else:
                ctx['icon_clear_frames'] = 0

            protected_for = time.time() - float(ctx.get('trigger_start', time.time()))
            e_fall_frames = int(ctx.get('e_fall_frames', 0))
            icon_clear_frames = int(ctx.get('icon_clear_frames', 0))
            e_ready_seen = bool(ctx.get('e_ready_seen', False))

            if protected_for >= self.NIGHTFALL_COMMIT_MIN_AFTER_TRIGGER and e_gray_done:
                self.logger.info(
                    f'ZFG {tag}: Nightfall COMMIT signal=E_GRAY_FALL '
                    f'white={e_white:.4f} baseline={float(ctx.get("e_white_baseline", -1)):.4f} '
                    f'threshold={-1.0 if e_gray_threshold is None else e_gray_threshold:.4f} '
                    f'gray_frames={int(ctx.get("e_gray_frames", 0))} '
                    f'after_trigger={protected_for:.3f}s'
                )
                self._clear_nightfall_commit_ctx(state, tag)
                self.sleep(0.02, check_combat=False)
                return self.NIGHTFALL_DONE

            if (
                protected_for >= self.NIGHTFALL_COMMIT_MIN_AFTER_TRIGGER
                and e_ready_seen
                and e_fall_frames >= self.NIGHTFALL_E_FALL_CONFIRM_FRAMES
            ):
                self.logger.info(
                    f'ZFG {tag}: Nightfall COMMIT signal=E_AVAILABLE_FALL_AUX '
                    f'E_locked={e_fall_frames}frames icon_clear={icon_clear_frames} '
                    f'after_trigger={protected_for:.3f}s'
                )
                self._clear_nightfall_commit_ctx(state, tag)
                self.sleep(0.02, check_combat=False)
                return self.NIGHTFALL_DONE

            if (
                protected_for >= self.NIGHTFALL_ICON_AUX_MIN_AFTER_TRIGGER
                and icon_clear_frames >= self.NIGHTFALL_ICON_CLEAR_CONFIRM_FRAMES
            ):
                self.logger.info(
                    f'ZFG {tag}: Nightfall COMMIT signal=ICON_CLEAR_FALLBACK '
                    f'icon_clear={icon_clear_frames}frames e_white={e_white:.4f} '
                    f'after_trigger={protected_for:.3f}s'
                )
                self._clear_nightfall_commit_ctx(state, tag)
                self.sleep(0.02, check_combat=False)
                return self.NIGHTFALL_DONE

            if (
                protected_for >= self.NIGHTFALL_TIME_AUX_AFTER_TRIGGER
                and icon_cleared
            ):
                self.logger.info(
                    f'ZFG {tag}: Nightfall COMMIT signal=TIME_PLUS_ICON_FALLBACK '
                    f'after_trigger={protected_for:.3f}s e_white={e_white:.4f}'
                )
                self._clear_nightfall_commit_ctx(state, tag)
                self.sleep(0.02, check_combat=False)
                return self.NIGHTFALL_DONE

        # 短最终复核：仍优先看E灰度，再看Nightfall图标fallback。
        final_clear = 0
        final_e_white = self._nightfall_e_white_ratio()
        final_gray_threshold = None
        for _ in range(2):
            self.task.next_frame()
            e_gray_done, final_e_white, final_gray_threshold = self._sample_nightfall_e_gray(ctx)
            if e_gray_done:
                protected_for = time.time() - float(ctx.get('trigger_start', time.time()))
                if protected_for >= self.NIGHTFALL_COMMIT_MIN_AFTER_TRIGGER:
                    self.logger.info(
                        f'ZFG {tag}: Nightfall COMMIT signal=E_GRAY_FALL_FINAL '
                        f'white={final_e_white:.4f} baseline={float(ctx.get("e_white_baseline", -1)):.4f} '
                        f'after_trigger={protected_for:.3f}s'
                    )
                    self._clear_nightfall_commit_ctx(state, tag)
                    return self.NIGHTFALL_DONE

            icon_cleared = not self.is_nightfall_ready(threshold=0.035)
            if icon_cleared:
                final_clear += 1
                ctx['icon_clear_frames'] = int(ctx.get('icon_clear_frames', 0)) + 1
            else:
                final_clear = 0
                ctx['icon_clear_frames'] = 0
            if final_clear < 2:
                self.sleep(0.02)

        protected_for = time.time() - float(ctx.get('trigger_start', time.time()))
        if (
            protected_for >= self.NIGHTFALL_ICON_AUX_MIN_AFTER_TRIGGER
            and final_clear >= 2
        ):
            self.logger.info(
                f'ZFG {tag}: Nightfall COMMIT signal=TIMEOUT_FINAL_ICON_FALLBACK '
                f'e_white={final_e_white:.4f} after_trigger={protected_for:.3f}s'
            )
            self._clear_nightfall_commit_ctx(state, tag)
            return self.NIGHTFALL_DONE

        self.logger.warning(
            f'ZFG {tag}: Nightfall commit slice timeout '
            f'{self.NIGHTFALL_COMMIT_TIMEOUT:.2f}s; preserve COMMITTING context '
            f'e_white={final_e_white:.4f} baseline={float(ctx.get("e_white_baseline", -1)):.4f}'
        )
        return self.NIGHTFALL_FAILED

    def _trigger_nightfall_commit(
        self,
        state,
        tag,
        acquire_timeout,
        min_acquire_time=0.0,
        prehold_phoebe=False,
        final=False,
    ):
        """统一终夜确认：READY -> COMMITTING -> DONE；E图标灰度下降沿主判据，Nightfall图标消失辅助。"""
        if not self.in_liberation:
            self._clear_nightfall_commit_ctx(state)
            return self.NIGHTFALL_LIBERATION_ENDED

        ctx = state.get(self.NIGHTFALL_COMMIT_CTX_KEY)
        if isinstance(ctx, dict):
            if ctx.get('tag') == tag:
                return self._continue_nightfall_commit(
                    state,
                    tag,
                    prehold_phoebe=prehold_phoebe,
                    final=final,
                )
            self.logger.warning(
                f'ZFG {tag}: discard stale Nightfall COMMITTING context tag={ctx.get("tag")}'
            )
            self._clear_nightfall_commit_ctx(state)

        start = time.time()
        while time.time() - start < acquire_timeout:
            if not self.in_liberation:
                return self.NIGHTFALL_LIBERATION_ENDED

            if final and self._r2_deadline_reached(state):
                self.logger.warning(
                    f'ZFG {tag}: R2 hard deadline reached before Nightfall commit '
                    f'R_elapsed={self._r1_elapsed(state):.2f}s'
                )
                return self.NIGHTFALL_R2_DEADLINE

            if not final or (
                self.R2_HARD_DEADLINE - self._r1_elapsed(state)
                > self.LIBER_ECHO_DEADLINE_GUARD
            ):
                self._try_liber_echo_soft(f'{tag}-wait-Nightfall')

            elapsed = time.time() - start
            if bool(self.is_nightfall_ready()) and elapsed >= min_acquire_time:
                label = 'FINAL Nightfall' if final else 'Nightfall'
                trigger_start = time.time()
                self.nightfall_time = trigger_start
                e_white_baseline = self._nightfall_e_white_ratio()
                state[self.NIGHTFALL_COMMIT_CTX_KEY] = {
                    'tag': tag,
                    'trigger_start': trigger_start,
                    'last_attack': -100.0,
                    'e_ready_seen': bool(self.resonance_available()),
                    'e_fall_frames': 0,
                    'e_white_baseline': e_white_baseline,
                    'e_white_min': e_white_baseline if e_white_baseline >= 0 else 999.0,
                    'e_gray_frames': 0,
                    'icon_clear_frames': 0,
                }
                self.logger.info(
                    f'ZFG {tag}: {label} icon detected elapsed={elapsed:.2f}s '
                    f'E_white_baseline={e_white_baseline:.4f} -> COMMITTING'
                )
                return self._continue_nightfall_commit(
                    state,
                    tag,
                    prehold_phoebe=prehold_phoebe,
                    final=final,
                )

            self._nightfall_attack_input(state, tag)
            self.sleep(0.025)
            self.task.next_frame()

            if not final and self.should_end_liberation(time_only=True):
                r2_result = self.click_liber2()
                self.logger.warning(
                    f'ZFG {tag}: time guard triggered R2 result={r2_result}'
                )
                self._clear_nightfall_commit_ctx(state, tag)
                return self.NIGHTFALL_R2_TRIGGERED

        self.logger.warning(
            f'ZFG {tag}: Nightfall icon acquire timeout {acquire_timeout:.2f}s'
        )
        return self.NIGHTFALL_FAILED

    def _run_nightfall_step(
        self,
        state,
        tag,
        cancel_last_smash=False,
        acquire_timeout=7.0,
        cancel_with_dodge=True,
        prehold_phoebe=False,
    ):
        result = self._trigger_nightfall_commit(
            state,
            tag,
            acquire_timeout=acquire_timeout,
            min_acquire_time=0.0,
            prehold_phoebe=prehold_phoebe,
            final=False,
        )
        if result != self.NIGHTFALL_DONE:
            return result

        if cancel_last_smash:
            self.sleep(0.25, check_combat=False)
            if cancel_with_dodge:
                self.continues_right_click(0.1)

        self.check_liber()
        if not self.in_liberation:
            return self.NIGHTFALL_LIBERATION_ENDED

        self.logger.info(f'ZFG {tag}: Nightfall result=DONE')
        return self.NIGHTFALL_DONE

    def _handle_nightfall_failure(self, state, result, tag):
        if result == self.NIGHTFALL_DONE:
            return False

        if result == self.NIGHTFALL_FAILED:
            self.logger.warning(
                f'ZFG {tag}: Nightfall failed -> keep current phase for retry'
            )
            return True

        self.logger.warning(
            f'ZFG {tag}: abnormal result={result} -> RECOVER_P2_PHOEBE'
        )
        state['step'] = self.STEP_RECOVER_P2_PHOEBE
        state.pop('phase', None)
        return True

    def _r1_n1_early_handoff(self, state, rover_step, tag):
        phase = state.get('phase', 'r1')

        if phase == 'r1':
            if not self._cast_r1():
                return
            state['nightfall_count'] = 0
            state['zani_r1_timer_start'] = float(getattr(self, 'liberation_time', 0) or time.time())
            self.logger.info(
                f'ZFG V4.6 {tag}: R1 TIMER armed -> R2 hard deadline T+{self.R2_HARD_DEADLINE:.2f}s'
            )
            self._try_liber_echo_soft(f'{tag}-after-R1')
            if tag == 'P1-N1':
                state[self.P1_N1_FORWARD_A_PENDING_KEY] = True
                self.logger.info(
                    f'ZFG V4.6 {tag}: arm first-A forward hold W={self.P1_N1_FORWARD_HOLD:.2f}s'
                )
            state['phase'] = 'nightfall1_trigger'
            phase = 'nightfall1_trigger'

        if phase == 'nightfall1_trigger':
            self._liber_phase = 1
            result = self._trigger_nightfall_commit(
                state,
                tag,
                acquire_timeout=self.N1_ICON_ACQUIRE_TIMEOUT,
                min_acquire_time=0.0,
                final=False,
            )
            if self._handle_nightfall_failure(state, result, tag):
                return
            state['nightfall_count'] = 1
            if tag == 'P1-N1':
                state.pop(self.P1_N1_FORWARD_A_PENDING_KEY, None)
            state['phase'] = 'switch_rover'
            phase = 'switch_rover'

        if phase == 'switch_rover':
            self._switch_route(
                state,
                'Rover',
                rover_step,
            )

    def _nightfall_then_switch(
        self,
        state,
        nightfall_number,
        target,
        next_step,
        tag,
        prehold_phoebe=False,
    ):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            self._try_liber_echo_soft(f'{tag}-entry')
            state['phase'] = 'nightfall'
            phase = 'nightfall'

        if phase == 'nightfall':
            if not self.in_liberation:
                state['step'] = self.STEP_RECOVER_P2_PHOEBE
                state.pop('phase', None)
                return

            self._liber_phase = min(3, max(1, int(nightfall_number)))
            result = self._run_nightfall_step(state, tag, prehold_phoebe=prehold_phoebe)

            if self._handle_nightfall_failure(state, result, tag):
                return

            state['nightfall_count'] = nightfall_number
            state['phase'] = 'switch'
            phase = 'switch'
            self.logger.info(
                f'ZFG V4.6 Zani Nightfall #{nightfall_number} complete'
            )

        if phase == 'switch':
            self._switch_route(
                state,
                target,
                next_step,
            )


    def _cast_post_r2_e_required(self):
        """P1/P2统一R2收尾：严格E -> 70ms -> A -> 180ms commit。

        V4.3与P1开场EA使用同一提交节奏，确保这一下A真正参与下一轮
        特殊E资源预充，而不是A刚发出就被切人吞掉。
        """
        start = time.time()

        while time.time() - start < self.POST_R2_E_TIMEOUT:
            self.task.next_frame()
            if self.resonance_available():
                clicked, _, _ = self.click_resonance(
                    send_click=False, time_out=0.8,
                )
                if clicked:
                    self.sleep(self.POST_R2_E_TO_A_GAP, check_combat=False)
                    self.task.click()
                    self.logger.info(
                        f'ZFG V4.6 Zani post-R2 EA: E confirmed -> A sent after '
                        f'{self.POST_R2_E_TO_A_GAP:.2f}s -> commit '
                        f'{self.POST_R2_A_COMMIT_GAP:.2f}s'
                    )
                    self.sleep(self.POST_R2_A_COMMIT_GAP, check_combat=False)
                    self.logger.info(
                        'ZFG V4.6 Zani post-R2 EA COMMITTED -> allow switch Phoebe'
                    )
                    return True
            self.sleep(self.POLL)

        self.logger.warning(
            'ZFG V4.6 Zani post-R2 E not ready/confirmed -> keep phase'
        )
        return False

    def _r1_elapsed(self, state):
        start = float(state.get('zani_r1_timer_start', 0) or 0)
        if start <= 0:
            start = float(getattr(self, 'liberation_time', 0) or 0)
        if start <= 0:
            return 0.0
        return max(0.0, float(self.time_elapsed_accounting_for_freeze(start)))

    def _r2_deadline_reached(self, state):
        return self._r1_elapsed(state) >= self.R2_HARD_DEADLINE

    def _trigger_final_nightfall_fast(self, state, tag):
        return self._trigger_nightfall_commit(
            state,
            tag,
            acquire_timeout=self.FINAL_N_ICON_TIMEOUT,
            min_acquire_time=0.0,
            final=True,
        )

    def _wait_final_damage_settle(self, state, tag, requested, latest_r_elapsed=None):
        """V4.3 rev1：用freeze-aware的R1有效时间给最终终夜伤害留落地窗口。"""
        start_elapsed = self._r1_elapsed(state)
        requested = max(0.0, float(requested))
        target_elapsed = start_elapsed + requested
        if latest_r_elapsed is not None:
            target_elapsed = min(target_elapsed, float(latest_r_elapsed))

        actual_budget = max(0.0, target_elapsed - start_elapsed)
        if actual_budget <= 0.0:
            self.logger.info(
                f'ZFG V4.6 rev1 {tag}: FINAL damage settle skipped '
                f'R_elapsed={start_elapsed:.2f}s latest={latest_r_elapsed}'
            )
            return 0.0

        self.logger.info(
            f'ZFG V4.6 rev1 {tag}: FINAL damage settle START '
            f'requested={requested:.2f}s actual_budget={actual_budget:.2f}s '
            f'R_elapsed={start_elapsed:.2f}->{target_elapsed:.2f}'
        )
        while self.in_liberation and self._r1_elapsed(state) < target_elapsed:
            self.sleep(0.02)
            self.task.next_frame()

        end_elapsed = self._r1_elapsed(state)
        waited = max(0.0, end_elapsed - start_elapsed)
        self.logger.info(
            f'ZFG V4.6 rev1 {tag}: FINAL damage settle END '
            f'waited={waited:.2f}s R_elapsed={end_elapsed:.2f}s'
        )
        return waited

    def _wait_final_nightfall_r2_gate(self, state, tag, policy):
        """
        V4.3 rev1：
        - P1：先保留原T+19.50s R2门；到门后再按剩余预算追加最终伤害落地保护，最晚不超过19.90s。
        - P2：N3完整下砸后额外等待0.50s让最后伤害落地；若N3迟迟未完成且撞到19.50s硬截止，仍立即保R2。
        """
        while self.in_liberation:
            r_elapsed = self._r1_elapsed(state)
            if self.R2_HARD_DEADLINE - r_elapsed > self.LIBER_ECHO_DEADLINE_GUARD:
                self._try_liber_echo_soft(f'{tag}-R2-buffer')
            smash_left = max(0.0, float(self.nightfall_time_left()))
            deadline = r_elapsed >= self.R2_HARD_DEADLINE
            smash_done = smash_left <= self.FINAL_N_SMASH_DONE_LEFT

            if policy == 'p1_deadline':
                if deadline:
                    self.logger.info(
                        f'ZFG {tag}: R2 gate=P1_DEADLINE '
                        f'R_elapsed={r_elapsed:.2f}s smash_left={smash_left:.2f}s'
                    )
                    self._wait_final_damage_settle(
                        state,
                        tag,
                        self.P1_FINAL_N_DAMAGE_SETTLE,
                        latest_r_elapsed=self.P1_R2_SAFE_LATEST,
                    )
                    return True
            else:
                if smash_done:
                    self.logger.info(
                        f'ZFG {tag}: R2 gate=N3_DONE '
                        f'R_elapsed={r_elapsed:.2f}s smash_left={smash_left:.2f}s'
                    )
                    self._wait_final_damage_settle(
                        state,
                        tag,
                        self.P2_FINAL_N_DAMAGE_SETTLE,
                    )
                    return True
                if deadline:
                    self.logger.info(
                        f'ZFG {tag}: R2 gate=HARD_DEADLINE '
                        f'R_elapsed={r_elapsed:.2f}s smash_left={smash_left:.2f}s; '
                        'skip extra settle to protect R2'
                    )
                    return True

            self.sleep(0.02)
            self.task.next_frame()

        return True

    def _final_nightfall_r2_e(
        self,
        state,
        nightfall_number,
        next_phoebe_step,
        tag,
        mark_new_cycle,
        r2_policy,
    ):
        phase = state.get('phase', 'entry')

        if phase == 'entry':
            if self.has_intro:
                self.wait_intro(time_out=2.0, click=False)
            state['phase'] = 'final_nightfall'
            phase = 'final_nightfall'

        if phase == 'final_nightfall':
            result = self._trigger_final_nightfall_fast(state, tag)
            if result == self.NIGHTFALL_FAILED:
                return
            if result == self.NIGHTFALL_R2_DEADLINE:
                self.logger.warning(
                    f'ZFG {tag}: skip unfinished final Nightfall and protect R2 at hard deadline'
                )
                state['phase'] = 'r2'
                phase = 'r2'
            elif result != self.NIGHTFALL_DONE:
                self.logger.warning(
                    f'ZFG {tag}: final Nightfall lost liberation result={result} '
                    '-> recovery'
                )
                state['step'] = self.STEP_RECOVER_P2_PHOEBE
                state.pop('phase', None)
                return
            else:
                state['nightfall_count'] = nightfall_number
                state['phase'] = 'r2_buffer'
                phase = 'r2_buffer'

        if phase == 'r2_buffer':
            self._wait_final_nightfall_r2_gate(state, tag, r2_policy)
            state['phase'] = 'r2'
            phase = 'r2'

        if phase == 'r2':
            result = self.click_liber2()
            self.task.next_frame()
            still_liber = bool(self.check_liber())
            if not result and still_liber:
                self.logger.warning(
                    f'ZFG V4.6 {tag}: R2 not confirmed -> keep R2 phase'
                )
                return

            self.in_liberation = False
            self._liber_phase = 0
            self.logger.info(
                f'ZFG V4.6 {tag}: R2 complete result={result} still_liber={still_liber}'
            )
            state['phase'] = 'post_r2_e'
            phase = 'post_r2_e'

        if phase == 'post_r2_e':
            if not self._cast_post_r2_e_required():
                return
            if mark_new_cycle:
                state['new_cycle_pending'] = True
                state[self.P2_ZANI_PRECHARGE_SEEDED_KEY] = True
                self.logger.info(
                    f'ZFG V4.6 {tag}: post-R2 E->A seeded next P2 Zani special-E resource; '
                    'treat as PRECHARGE stage-1'
                )
            state['phase'] = 'switch_phoebe'
            phase = 'switch_phoebe'

        if phase == 'switch_phoebe':
            self._switch_route(
                state,
                'Phoebe',
                next_phoebe_step,
            )


    def _recover_liberation(self, state):
        phase = state.get('phase', 'safe_finish')

        if not self.in_liberation:
            state['step'] = self.STEP_RECOVER_P2_PHOEBE
            state.pop('phase', None)
            return

        if phase == 'safe_finish':
            self.logger.warning(
                'ZFG V4.6 RECOVER_ZANI_LIBERATION: '
                'attempt one safe Nightfall then R2'
            )
            self._liber_phase = 3

            if (
                self.is_nightfall_ready()
                or self.liberation_time_left() > 2.5
            ):
                result = self._run_nightfall_step(state, 'RECOVER-N')
                if result in (
                    self.NIGHTFALL_LIBERATION_ENDED,
                    self.NIGHTFALL_R2_TRIGGERED,
                ):
                    state['phase'] = 'switch_phoebe'
                    phase = 'switch_phoebe'
                else:
                    state['phase'] = 'q_r2'
                    phase = 'q_r2'
            else:
                state['phase'] = 'q_r2'
                phase = 'q_r2'

        if phase == 'q_r2':
            if self.in_liberation:
                self.should_end_liberation(force_finish=True)
                if self.echo_available():
                    self.click_echo(time_out=0)
                self.click_liber2()

            self.in_liberation = False
            self._liber_phase = 0
            state['phase'] = 'post_r2_e'
            phase = 'post_r2_e'

        if phase == 'post_r2_e':
            if not self._cast_post_r2_e_required():
                return
            state['phase'] = 'switch_phoebe'
            phase = 'switch_phoebe'

        if phase == 'switch_phoebe':
            self._switch_route(
                state,
                'Phoebe',
                self.STEP_P2_PHOEBE_DOUBLE_STAR_FILL_TO_ZANI,
            )
